import { Color4 } from '@babylonjs/core/Maths/math.color';
import { Vector3 } from '@babylonjs/core/Maths/math.vector';
import { DynamicTexture } from '@babylonjs/core/Materials/Textures/dynamicTexture';
import { ParticleSystem } from '@babylonjs/core/Particles/particleSystem';
import { PointLight } from '@babylonjs/core/Lights/pointLight';
import { Color3 } from '@babylonjs/core/Maths/math.color';
import type { Scene } from '@babylonjs/core/scene';
import type { VoxelWorld } from '../world/World';
import { volcanoNear } from '../world/structures';
import { surfaceHeight } from '../world/generator';
import type { GameAudio } from '../audio/Audio';

export class VolcanoSystem {
  private smoke: ParticleSystem;
  private glow: PointLight;
  private erupting = 0;
  private nextCheck = 20;
  onToast?: (message: string) => void;
  constructor(scene: Scene, private world: VoxelWorld, private audio: GameAudio) {
    const tex = new DynamicTexture('volcano-ash', 32, scene, false), ctx = tex.getContext();
    const grad = ctx.createRadialGradient(16, 16, 2, 16, 16, 15);
    grad.addColorStop(0, 'rgba(255,255,255,1)'); grad.addColorStop(1, 'rgba(255,255,255,0)');
    ctx.fillStyle = grad; ctx.fillRect(0, 0, 32, 32); tex.update(); tex.hasAlpha = true;
    this.smoke = new ParticleSystem('volcano-plume', 400, scene);
    this.smoke.particleTexture = tex; this.smoke.emitter = Vector3.Zero();
    this.smoke.minEmitBox = new Vector3(-3, 0, -3); this.smoke.maxEmitBox = new Vector3(3, 2, 3);
    this.smoke.direction1 = new Vector3(-2, 9, -2); this.smoke.direction2 = new Vector3(2, 16, 2);
    this.smoke.minSize = 2; this.smoke.maxSize = 7; this.smoke.minLifeTime = 2.5; this.smoke.maxLifeTime = 6;
    this.smoke.color1 = new Color4(0.25, 0.22, 0.2, 0.75); this.smoke.color2 = new Color4(1, 0.4, 0.1, 0.9); this.smoke.colorDead = new Color4(0.2, 0.2, 0.2, 0);
    this.smoke.emitRate = 0; this.smoke.start();
    this.glow = new PointLight('volcano-glow', Vector3.Zero(), scene);
    this.glow.diffuse = new Color3(1, 0.35, 0.08); this.glow.range = 46; this.glow.intensity = 0;
  }
  update(dt: number, player: Vector3) {
    this.nextCheck -= dt;
    if (this.erupting > 0) {
      this.erupting -= dt;
      this.smoke.emitRate = 90;
      this.glow.intensity = 5 + Math.sin(this.erupting * 9) * 1.5;
      if (Vector3.Distance(player, this.glow.position) < 14 && Math.random() < dt * 0.8) this.onToast?.('The eruption scorches the air. Fall back!');
      if (this.erupting <= 0) { this.smoke.emitRate = 0; this.glow.intensity = 0; this.nextCheck = 240 + Math.random() * 360; }
      return;
    }
    this.smoke.emitRate = 0; this.glow.intensity = Math.max(0, this.glow.intensity - dt * 4);
    if (this.nextCheck > 0 || this.world.config.dimension !== 'overworld') return;
    this.nextCheck = 12;
    const vent = volcanoNear(player.x, player.z, this.world.config.seed, 170);
    if (!vent || !this.world.isLoaded(vent.x, vent.z)) return;
    if (Math.random() > 0.2) return;
    const y = surfaceHeight(vent.x, vent.z, this.world.config) + 24;
    this.smoke.emitter = new Vector3(vent.x, y, vent.z);
    this.glow.position.set(vent.x, y + 2, vent.z);
    this.erupting = 22;
    this.audio.thunder(0.4, 0.9);
    this.onToast?.('The volcano stirs. Ash rises on the horizon.');
  }
  dispose() { this.smoke.dispose(); this.glow.dispose(); }
}
