import { PostProcess } from '@babylonjs/core/PostProcesses/postProcess';
import { Effect } from '@babylonjs/core/Materials/effect';
import { Texture } from '@babylonjs/core/Materials/Textures/texture';
import type { FreeCamera } from '@babylonjs/core/Cameras/freeCamera';
import type { Scene } from '@babylonjs/core/scene';
import type { DepthRenderer } from '@babylonjs/core/Rendering/depthRenderer';
import '@babylonjs/core/Rendering/depthRendererSceneComponent';
import { DIMENSIONS, type DimensionId } from '../core/types';

Effect.ShadersStore['aetherUnderwaterFragmentShader']=`precision highp float;varying vec2 vUV;uniform sampler2D textureSampler;uniform sampler2D depthSampler;uniform float time;uniform float immersion;uniform float farPlane;uniform float toxic;
void main(){vec2 uv=vUV;uv+=vec2(sin(uv.y*23.+time*1.7),cos(uv.x*19.+time*1.3))*.0018*immersion;vec3 color=texture2D(textureSampler,uv).rgb;float distance=texture2D(depthSampler,uv).r*farPlane;vec3 absorption=exp(-min(distance,60.)*vec3(.06,.022,.016)*immersion);vec3 water=mix(vec3(.012,.2,.27),vec3(.19,.12,.28),toxic);color=color*absorption+water*(1.-absorption);float beam=pow(max(0.,sin((uv.x+uv.y*.22)*37.+sin(time*.17)*.7)),18.);color+=vec3(.1,.24,.24)*beam*(1.-uv.y)*.18*immersion;float up=smoothstep(.42,.78,vUV.y);vec3 skyReflect=mix(vec3(.42,.78,.84),vec3(.55,.34,.62),toxic);float shimmer=sin(vUV.x*90.+time*2.2)*sin(vUV.y*64.-time*1.6);vec3 surface=skyReflect*(.62+shimmer*.22);float waveBand=smoothstep(.35,.6,vUV.y)*(1.-smoothstep(.75,.98,vUV.y));color=mix(color,surface,clamp(up*.5+waveBand*.35,0.,.72)*immersion);float vignette=1.-smoothstep(.18,.9,length(vUV-.5));color*=mix(1.,.73+.27*vignette,immersion);gl_FragColor=vec4(color,1.);}`;
export class Underwater {
  private pass: PostProcess;
  private attached=false;
  private clock=0;
  private immersion=0;
  private dimension: DimensionId='overworld';
  private depth:DepthRenderer;
  constructor(private scene:Scene,private camera:FreeCamera){
    const depth=scene.enableDepthRenderer(camera,false,true);
    this.depth=depth;depth.enabled=false;
    this.pass=new PostProcess('underwater-absorption','aetherUnderwater',['time','immersion','farPlane','toxic'],['depthSampler'],1,null,Texture.BILINEAR_SAMPLINGMODE,scene.getEngine());
    this.pass.onApply=effect=>{effect.setTexture('depthSampler',depth.getDepthMap());effect.setFloat('time',this.clock);effect.setFloat('immersion',this.immersion);effect.setFloat('farPlane',camera.maxZ);effect.setFloat('toxic',this.dimension==='sift'?1:0);};
  }
  update(dt:number,dimension:DimensionId,submergedOverride?:boolean){
    this.clock+=dt;this.dimension=dimension;
    const submerged=dimension!=='nether'&&(submergedOverride??this.camera.position.y<DIMENSIONS[dimension].water+.05);
    this.depth.enabled=submerged||this.immersion>.01;
    this.immersion+=(Number(submerged)-this.immersion)*Math.min(1,dt*7);
    if(submerged&&!this.attached){this.camera.attachPostProcess(this.pass);this.attached=true;}
    if(!submerged&&this.attached&&this.immersion<.01){this.camera.detachPostProcess(this.pass);this.attached=false;}
  }
  dispose(){this.pass.dispose(this.camera);this.scene.disableDepthRenderer(this.camera);}
}