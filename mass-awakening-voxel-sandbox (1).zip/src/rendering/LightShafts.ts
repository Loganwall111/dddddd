import { ShaderMaterial } from '@babylonjs/core/Materials/shaderMaterial';
import { TransformNode } from '@babylonjs/core/Meshes/transformNode';
import { Mesh } from '@babylonjs/core/Meshes/mesh';
import { MeshBuilder } from '@babylonjs/core/Meshes/meshBuilder';
import { Vector3 } from '@babylonjs/core/Maths/math.vector';
import { Color3 } from '@babylonjs/core/Maths/math.color';
import type { Scene } from '@babylonjs/core/scene';
import type { Weather } from '../core/types';

const vertex = `precision highp float;attribute vec3 position;attribute vec2 uv;uniform mat4 worldViewProjection;varying vec2 vUV;void main(){vUV=uv;gl_Position=worldViewProjection*vec4(position,1.);}`;
const fragment = `precision highp float;varying vec2 vUV;uniform float time;uniform float strength;uniform vec3 tint;
void main(){
  float across = sin(vUV.x*3.14159);
  float along = pow(1.0-vUV.y, 1.6);
  float shimmer = 0.72+0.28*sin(vUV.y*14.0-time*0.7+vUV.x*5.0);
  float a = across*along*shimmer*strength;
  gl_FragColor = vec4(tint*a, a);
}`;

export class LightShafts {
  private root: TransformNode;
  private material: ShaderMaterial;
  private clock = 0;
  constructor(scene: Scene) {
    this.root = new TransformNode('true-sun-shafts', scene);
    this.material = new ShaderMaterial('shaft-gradient', scene, { vertexSource: vertex, fragmentSource: fragment }, { attributes: ['position', 'uv'], uniforms: ['worldViewProjection', 'time', 'strength', 'tint'], needAlphaBlending: true });
    this.material.backFaceCulling = false; this.material.disableDepthWrite = true;
    this.material.setFloat('strength', 0); this.material.setColor3('tint', new Color3(1, 0.9, 0.7));
    for (let i = 0; i < 9; i++) {
      const angle = (i / 9) * Math.PI * 2;
      const w = 3 + (i % 3) * 2.2;
      const mesh = MeshBuilder.CreateCylinder(`sun-beam-${i}`, { diameterTop: w * 0.55, diameterBottom: w, height: 85, tessellation: 10, cap: Mesh.NO_CAP }, scene);
      mesh.parent = this.root; mesh.position.set(Math.cos(angle) * 24, 18, Math.sin(angle) * 24);
      mesh.material = this.material; mesh.isPickable = false; mesh.renderingGroupId = 1;
    }
  }
  update(dt: number, camera: Vector3, sunDir: Vector3, day: number, weather: Weather, submerged: boolean, alien: boolean) {
    this.clock += dt;
    this.root.position.copyFrom(camera);
    if (!submerged) {
      const azimuth = Math.atan2(-sunDir.x, -sunDir.z);
      const elevation = Math.max(0, -sunDir.y);
      this.root.rotation.set((1 - Math.min(1, elevation * 1.6)) * 0.85, azimuth, 0);
    } else this.root.rotation.set(0, this.clock * 0.02, 0);
    let strength = 0;
    let tint = new Color3(1, 0.88, 0.66);
    if (submerged && !alien) { strength = 0.34; tint = new Color3(0.45, 0.85, 0.9); }
    else if (!alien && day > 0.03) {
      const lowSun = day < 0.42 ? 1.6 : 1.0;
      const weatherMul = weather === 'clear' ? 1 : weather === 'rain' ? 0.3 : 0.12;
      strength = Math.min(0.4, day * 0.5 * lowSun * weatherMul);
      if (day < 0.35) tint = new Color3(1, 0.62, 0.34);
    }
    this.material.setFloat('time', this.clock); this.material.setFloat('strength', strength); this.material.setColor3('tint', tint);
    this.root.setEnabled(strength > 0.005);
  }
  dispose() { this.root.dispose(); this.material.dispose(); }
}
