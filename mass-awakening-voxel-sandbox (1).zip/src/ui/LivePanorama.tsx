import { useEffect,useRef,useState } from 'react';
import type { Panorama } from '../rendering/Panorama';
export function LivePanorama({reducedMotion}:{reducedMotion:boolean}){
  const canvas=useRef<HTMLCanvasElement>(null),view=useRef<Panorama|null>(null),[ready,setReady]=useState(false),motion=useRef(reducedMotion);motion.current=reducedMotion;
  useEffect(()=>{
    let disposed=false;let instance:Panorama|undefined;
    const timer=setTimeout(()=>{
      void import('../rendering/Panorama').then(async({Panorama:Renderer})=>{
        if(disposed||!canvas.current)return;
        instance=await Renderer.create(canvas.current,motion.current,()=>{if(!disposed)setReady(true);});
        if(disposed)instance.dispose();else{instance.reducedMotion=motion.current;view.current=instance;}
      }).catch(error=>console.warn('Live panorama unavailable; original title artwork remains visible.',error));
    },700);
    return()=>{disposed=true;clearTimeout(timer);instance?.dispose();view.current=null;};
  },[]);
  useEffect(()=>{if(view.current)view.current.reducedMotion=reducedMotion;},[reducedMotion]);
  return <canvas ref={canvas} className={`live-panorama ${ready?'ready':''}`} aria-hidden="true"/>;
}