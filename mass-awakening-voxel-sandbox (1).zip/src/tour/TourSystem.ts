import { Vector3 } from '@babylonjs/core/Maths/math.vector';
import type { FreeCamera } from '@babylonjs/core/Cameras/freeCamera';
import type { VoxelWorld } from '../world/World';
import { biomeAt } from '../world/biomes';
import { surfaceHeight } from '../world/generator';

export interface TourStop { title: string; subtitle: string; position: Vector3; lookAt: Vector3 }

export class TourSystem {
  active = false;
  private stops: TourStop[] = [];
  private index = 0;
  private timer = 0;
  private fromPos = Vector3.Zero();
  private fromLook = Vector3.Zero();
  onCaption?: (title: string, subtitle: string, index: number, total: number) => void;
  onEnd?: () => void;
  constructor(private camera: FreeCamera, private world: VoxelWorld) {}
  private findBiome(ids: string[], maxRadius = 1200): { x: number; z: number } | null {
    const seed = this.world.config.seed;
    for (let r = 200; r <= maxRadius; r += 64) {
      for (let a = 0; a < 12; a++) {
        const x = Math.round(Math.cos(a / 12 * Math.PI * 2) * r), z = Math.round(Math.sin(a / 12 * Math.PI * 2) * r);
        const h = surfaceHeight(x, z, this.world.config);
        if (ids.includes(biomeAt(x, z, seed, 'overworld', h).id)) return { x, z };
      }
    }
    return null;
  }
  private stop(title: string, subtitle: string, x: number, z: number, height = 15, dist = 18): TourStop {
    const ground = this.world.isLoaded(x, z) ? this.world.ground(x, z) : surfaceHeight(x, z, this.world.config) + 1;
    return { title, subtitle, position: new Vector3(x + dist * 0.6, ground + height, z - dist * 0.7), lookAt: new Vector3(x, ground + 1, z) };
  }
  start() {
    const desert = this.findBiome(['desert', 'bones', 'badlands']);
    const mushroom = this.findBiome(['mushroom', 'toxic', 'jungle']);
    const snow = this.findBiome(['snow', 'taiga', 'glacier']);
    const volcanic = this.findBiome(['volcanic']);
    this.stops = [
      this.stop('Spawn Meadows', 'Every journey begins with a single step.', 2, -4, 13, 16),
      this.stop('Riverside Village', 'Trade, rest, and hear the old songs.', 21, 6, 16, 22),
      this.stop('The Rolling Wilds', 'Forests, valleys, and hidden clearings.', 120, 80, 22, 26),
    ];
    if (desert) this.stops.push(this.stop('Golden Dunes', 'Pyramids sleep beneath the sand.', desert.x, desert.z, 26, 30));
    if (mushroom) this.stops.push(this.stop('Strange Growths', 'Not everything glowing is safe.', mushroom.x, mushroom.z, 18, 24));
    if (snow) this.stops.push(this.stop('Frozen Reaches', 'Winter never truly leaves.', snow.x, snow.z, 24, 28));
    if (volcanic) this.stops.push(this.stop('Volcanic Wastes', 'The mountain breathes. Keep your distance.', volcanic.x, volcanic.z, 30, 34));
    this.stops.push(this.stop('Ancient Stairs', 'C, G, E, B, C. The deep gate listens.', 42, -52, 14, 18));
    this.active = true; this.index = 0; this.timer = 0;
    this.fromPos.copyFrom(this.camera.position);
    this.fromLook.copyFrom(this.camera.position.add(this.camera.getForwardRay().direction.scale(10)));
    this.onCaption?.(this.stops[0].title, this.stops[0].subtitle, 1, this.stops.length);
  }
  stopTour() { if (!this.active) return; this.active = false; this.stops = []; this.onEnd?.(); }
  next() {
    if (!this.active) return;
    this.index++;
    if (this.index >= this.stops.length) { this.stopTour(); return; }
    this.timer = 0;
    this.fromPos.copyFrom(this.camera.position);
    this.fromLook.copyFrom(this.camera.position.add(this.camera.getForwardRay().direction.scale(10)));
    this.onCaption?.(this.stops[this.index].title, this.stops[this.index].subtitle, this.index + 1, this.stops.length);
  }
  update(dt: number) {
    if (!this.active || !this.stops.length) return;
    this.timer += dt;
    const stop = this.stops[this.index];
    const blend = Math.min(1, this.timer / 3.2);
    const smooth = blend * blend * (3 - 2 * blend);
    const idle = Math.min(1, Math.max(0, (this.timer - 3.2) / 3.4));
    const drift = Math.sin(this.timer * 0.5) * 1.6 * idle;
    this.camera.position.copyFrom(Vector3.Lerp(this.fromPos, stop.position, smooth));
    this.camera.position.x += drift * 0.4;
    const look = Vector3.Lerp(this.fromLook, stop.lookAt, smooth);
    this.camera.setTarget(look);
    if (this.timer > 7.4) this.next();
  }
}
