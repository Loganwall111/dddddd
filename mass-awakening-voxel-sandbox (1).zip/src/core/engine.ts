import type { AbstractEngine } from '@babylonjs/core/Engines/abstractEngine';
import { Engine } from '@babylonjs/core/Engines/engine';
import { WebGPUEngine } from '@babylonjs/core/Engines/webgpuEngine';

export async function initializeEngine(canvas:HTMLCanvasElement):Promise<AbstractEngine>{
  if('gpu'in navigator&&new URLSearchParams(location.search).get('renderer')!=='webgl'){
    let gpu:WebGPUEngine|undefined;
    try{if(await WebGPUEngine.IsSupportedAsync){gpu=new WebGPUEngine(canvas,{antialias:true,stencil:true});await gpu.initAsync();return gpu;}}
    catch(error){gpu?.dispose();console.info('Using the WebGL fallback for this device.',error);}
  }
  return new Engine(canvas,true,{stencil:true,preserveDrawingBuffer:false,powerPreference:'high-performance'});
}