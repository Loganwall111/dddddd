// Persistent user settings. Every field is consumed by the engine or UI (no dead toggles).

export type GraphicsPreset = "low" | "medium" | "high" | "ultra";

export interface Settings {
  graphics: GraphicsPreset;
  renderDistance: number; // chunks
  fov: number; // degrees
  sensitivity: number; // 0.2 - 3
  invertY: boolean;
  viewBobbing: boolean;
  shadows: boolean;
  shadowMapSize: 512 | 1024 | 2048;
  waterReflections: boolean;
  waterQuality: 0 | 1 | 2; // 0 off, 1 reflections, 2 reflections + refraction
  volumetricClouds: boolean;
  godRays: boolean;
  bloom: boolean;
  ssao: boolean;
  antialias: boolean;
  aurora: boolean;
  stars: boolean;
  particles: boolean;
  renderScale: number; // 0.5 - 1
  maxFps: number; // 30..240 or 0 = unlimited
  dayLengthMinutes: number; // real minutes per in-game day
  weatherEnabled: boolean;
  seasonsEnabled: boolean;
  volumeMaster: number; // 0-1
  volumeMusic: number;
  volumeSfx: number;
  volumeAmbient: number;
  // accessibility
  reducedMotion: boolean;
  screenShake: number; // 0-1
  highContrast: boolean;
  subtitles: boolean;
  hudScale: number; // 1-3
  crouchToggle: boolean;
  colorblindFriendlyTints: boolean;
}

export const DEFAULT_SETTINGS: Settings = {
  graphics: "high",
  renderDistance: 6,
  fov: 70,
  sensitivity: 1,
  invertY: false,
  viewBobbing: true,
  shadows: true,
  shadowMapSize: 1024,
  waterReflections: true,
  waterQuality: 2,
  volumetricClouds: true,
  godRays: true,
  bloom: true,
  ssao: false,
  antialias: true,
  aurora: true,
  stars: true,
  particles: true,
  renderScale: 1,
  maxFps: 0,
  dayLengthMinutes: 12,
  weatherEnabled: true,
  seasonsEnabled: true,
  volumeMaster: 0.8,
  volumeMusic: 0.35,
  volumeSfx: 0.8,
  volumeAmbient: 0.6,
  reducedMotion: false,
  screenShake: 1,
  highContrast: false,
  subtitles: false,
  hudScale: 2,
  crouchToggle: false,
  colorblindFriendlyTints: false,
};

export const GRAPHICS_PRESETS: Record<GraphicsPreset, Partial<Settings>> = {
  low: {
    renderDistance: 4, shadows: false, shadowMapSize: 512, waterReflections: false, waterQuality: 0,
    volumetricClouds: false, godRays: false, bloom: false, ssao: false, antialias: false, aurora: false,
    particles: false, renderScale: 0.75,
  },
  medium: {
    renderDistance: 6, shadows: true, shadowMapSize: 512, waterReflections: true, waterQuality: 1,
    volumetricClouds: true, godRays: false, bloom: false, ssao: false, antialias: false, aurora: true,
    particles: true, renderScale: 1,
  },
  high: {
    renderDistance: 8, shadows: true, shadowMapSize: 1024, waterReflections: true, waterQuality: 2,
    volumetricClouds: true, godRays: true, bloom: true, ssao: false, antialias: true, aurora: true,
    particles: true, renderScale: 1,
  },
  ultra: {
    renderDistance: 12, shadows: true, shadowMapSize: 2048, waterReflections: true, waterQuality: 2,
    volumetricClouds: true, godRays: true, bloom: true, ssao: true, antialias: true, aurora: true,
    particles: true, renderScale: 1,
  },
};

const KEY = "aetherforged.settings.v1";

export function loadSettings(): Settings {
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return { ...DEFAULT_SETTINGS };
    const parsed = JSON.parse(raw) as Partial<Settings>;
    return { ...DEFAULT_SETTINGS, ...parsed };
  } catch {
    return { ...DEFAULT_SETTINGS };
  }
}

export function saveSettings(s: Settings): void {
  try {
    localStorage.setItem(KEY, JSON.stringify(s));
  } catch {
    /* storage may be unavailable; settings simply won't persist */
  }
}

export function applyPreset(s: Settings, preset: GraphicsPreset): Settings {
  return { ...s, graphics: preset, ...GRAPHICS_PRESETS[preset] };
}
