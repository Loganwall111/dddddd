// Visual/physical effects: block-break particles, explosion debris, falling blocks (sand/gravel),
// rain puddles and volcano eruptions. Kept separate from Game so each effect is self-contained.

import { Color3, Color4, Mesh, MeshBuilder, ParticleSystem, Scene, StandardMaterial, Texture, Vector3, Vector4 } from "../rendering/babylon";
import { BLOCKS, BID, isSolidId } from "../blocks/blocks";
import { tileUV, type Atlas, TILE } from "../blocks/textures";
import type { World } from "../world/world";
import type { MaterialLib } from "../rendering/materials";
import { audio } from "../audio/audio";

interface Debris {
  mesh: Mesh;
  pos: Vector3;
  vel: Vector3;
  spin: Vector3;
  life: number;
  max: number;
  size: number;
  /** if set, the debris becomes this block when it lands (falling sand / lava bombs) */
  placeId: number;
}

export class Effects {
  private debris: Debris[] = [];
  private particleTex: Texture;
  private smokeTex: Texture;
  private avgColor = new Map<number, Color3>();
  private puddles: Mesh[] = [];
  private puddleTimer = 0;
  private eruptions: { ps: ParticleSystem[]; t: number; x: number; y: number; z: number; bombTimer: number }[] = [];
  private lavaMat: StandardMaterial;

  constructor(private scene: Scene, private mats: MaterialLib, private atlas: Atlas) {
    this.particleTex = new Texture(squareUrl(), scene, false, false, Texture.NEAREST_NEAREST);
    this.smokeTex = new Texture(softUrl(), scene);
    this.lavaMat = new StandardMaterial("lavaBombMat", scene);
    this.lavaMat.emissiveColor = new Color3(1, 0.45, 0.1);
    this.lavaMat.disableLighting = true;
  }

  /** Average colour of a block's side tile (for tinted particles). */
  colorOf(id: number): Color3 {
    let c = this.avgColor.get(id);
    if (c) return c;
    const def = BLOCKS[id];
    c = new Color3(0.6, 0.6, 0.6);
    if (def) {
      const [u0, v0] = tileUV(def.side);
      const g = this.atlas.color.getContext("2d");
      if (g) {
        const px = g.getImageData(Math.round(u0 * this.atlas.size), Math.round(v0 * this.atlas.size), TILE, TILE).data;
        let r = 0, gg = 0, b = 0, n = 0;
        for (let i = 0; i < px.length; i += 4) if (px[i + 3] > 40) { r += px[i]; gg += px[i + 1]; b += px[i + 2]; n++; }
        if (n) c = new Color3(r / n / 255, gg / n / 255, b / n / 255);
      }
    }
    this.avgColor.set(id, c);
    return c;
  }

  /** Burst of block-coloured fragments when a block is broken. */
  blockBreak(x: number, y: number, z: number, id: number, enabled: boolean): void {
    if (!enabled) return;
    const c = this.colorOf(id);
    const ps = new ParticleSystem("break", 40, this.scene);
    ps.particleTexture = this.particleTex;
    ps.emitter = new Vector3(x + 0.5, y + 0.5, z + 0.5);
    ps.minEmitBox = new Vector3(-0.4, -0.4, -0.4);
    ps.maxEmitBox = new Vector3(0.4, 0.4, 0.4);
    ps.color1 = new Color4(c.r, c.g, c.b, 1);
    ps.color2 = new Color4(c.r * 0.75, c.g * 0.75, c.b * 0.75, 1);
    ps.colorDead = new Color4(c.r * 0.5, c.g * 0.5, c.b * 0.5, 0);
    ps.minSize = 0.07;
    ps.maxSize = 0.14;
    ps.minLifeTime = 0.4;
    ps.maxLifeTime = 0.9;
    ps.direction1 = new Vector3(-2, 2.5, -2);
    ps.direction2 = new Vector3(2, 4.5, 2);
    ps.gravity = new Vector3(0, -16, 0);
    ps.manualEmitCount = 30;
    ps.emitRate = 0;
    ps.blendMode = ParticleSystem.BLENDMODE_STANDARD;
    ps.disposeOnStop = true;
    ps.targetStopDuration = 1.0;
    ps.start();
  }

  private makeCube(id: number, size: number): Mesh {
    const def = BLOCKS[id];
    const uv = tileUV(def?.side ?? "stone");
    const faceUV = new Array(6).fill(0).map(() => new Vector4(uv[0], uv[1], uv[2], uv[3]));
    const m = MeshBuilder.CreateBox("debris", { size, faceUV }, this.scene);
    m.material = def && (def.render === "emissive" || def.render === "lava") ? this.mats.emissive : this.mats.solid;
    m.isPickable = false;
    return m;
  }

  /** Explosion debris: chunks of the destroyed blocks fly out, bounce and fade. */
  explosionDebris(center: Vector3, ids: { id: number; x: number; y: number; z: number }[], power: number): void {
    const budget = Math.max(0, 90 - this.debris.length);
    const pick = ids.filter(() => Math.random() < 0.5).slice(0, Math.min(36, budget));
    for (const b of pick) {
      const size = 0.25 + Math.random() * 0.3;
      const mesh = this.makeCube(b.id, size);
      const pos = new Vector3(b.x + 0.5, b.y + 0.5, b.z + 0.5);
      const dir = pos.subtract(center).normalize();
      const speed = (6 + Math.random() * 10) * (power / 3);
      const vel = dir.scale(speed).add(new Vector3(0, 4 + Math.random() * 6, 0));
      mesh.position.copyFrom(pos);
      this.debris.push({ mesh, pos, vel, spin: new Vector3(Math.random() * 8, Math.random() * 8, Math.random() * 8), life: 0, max: 3 + Math.random() * 2, size, placeId: 0 });
    }
  }

  /** A gravity block (sand/gravel) detaches and falls; it re-solidifies where it lands. */
  fallingBlock(x: number, y: number, z: number, id: number): void {
    const mesh = this.makeCube(id, 0.98);
    const pos = new Vector3(x + 0.5, y + 0.5, z + 0.5);
    mesh.position.copyFrom(pos);
    this.debris.push({ mesh, pos, vel: new Vector3(0, 0, 0), spin: new Vector3(0, 0, 0), life: 0, max: 20, size: 0.98, placeId: id });
  }

  /** Checks a column above (x,y,z) for unsupported gravity blocks and drops them. */
  settleColumn(world: World, x: number, y: number, z: number): void {
    for (let yy = y; yy < Math.min(255, y + 24); yy++) {
      const id = world.getBlock(x, yy, z);
      if (id <= 0 || !BLOCKS[id]?.gravity) break;
      const below = world.getBlock(x, yy - 1, z);
      if (below !== 0 && below !== -1 && isSolidId(below)) break;
      world.setBlock(x, yy, z, 0);
      this.fallingBlock(x, yy, z, id);
    }
  }

  /** Starts a volcano eruption at a crater position (lava fountain, smoke column, lava bombs). */
  eruption(x: number, y: number, z: number, particles: boolean): void {
    const ps: ParticleSystem[] = [];
    if (particles) {
      const lava = new ParticleSystem("eruptLava", 1500, this.scene);
      lava.particleTexture = this.smokeTex;
      lava.emitter = new Vector3(x, y + 1, z);
      lava.minEmitBox = new Vector3(-2, 0, -2);
      lava.maxEmitBox = new Vector3(2, 0, 2);
      lava.color1 = new Color4(1, 0.55, 0.1, 1);
      lava.color2 = new Color4(1, 0.25, 0.05, 1);
      lava.colorDead = new Color4(0.2, 0.05, 0, 0);
      lava.minSize = 0.6; lava.maxSize = 1.6;
      lava.minLifeTime = 1.5; lava.maxLifeTime = 3;
      lava.emitRate = 450;
      lava.direction1 = new Vector3(-6, 28, -6);
      lava.direction2 = new Vector3(6, 40, 6);
      lava.gravity = new Vector3(0, -22, 0);
      lava.blendMode = ParticleSystem.BLENDMODE_ADD;
      lava.start();
      const smoke = new ParticleSystem("eruptSmoke", 900, this.scene);
      smoke.particleTexture = this.smokeTex;
      smoke.emitter = new Vector3(x, y + 4, z);
      smoke.minEmitBox = new Vector3(-4, 0, -4);
      smoke.maxEmitBox = new Vector3(4, 4, 4);
      smoke.color1 = new Color4(0.25, 0.22, 0.2, 0.7);
      smoke.color2 = new Color4(0.12, 0.1, 0.1, 0.6);
      smoke.colorDead = new Color4(0.1, 0.1, 0.1, 0);
      smoke.minSize = 6; smoke.maxSize = 14;
      smoke.minLifeTime = 6; smoke.maxLifeTime = 10;
      smoke.emitRate = 60;
      smoke.direction1 = new Vector3(-2, 8, -2);
      smoke.direction2 = new Vector3(2, 14, 2);
      smoke.gravity = new Vector3(0.6, 0.5, 0);
      smoke.start();
      ps.push(lava, smoke);
    }
    this.eruptions.push({ ps, t: 0, x, y, z, bombTimer: 0 });
    audio.play("eruption", { pos: { x, y, z }, volume: 1.4 });
  }

  /** Places glossy puddles on open ground around the player while it's wet. */
  private updatePuddles(dt: number, world: World, px: number, pz: number, wet: number): void {
    this.puddleTimer -= dt;
    if (wet < 0.05) {
      for (const p of this.puddles) p.setEnabled(false);
      return;
    }
    if (this.puddles.length === 0) {
      for (let i = 0; i < 28; i++) {
        const m = MeshBuilder.CreateGround(`puddle${i}`, { width: 1, height: 1 }, this.scene);
        m.material = this.mats.puddle;
        m.isPickable = false;
        m.setEnabled(false);
        this.puddles.push(m);
      }
    }
    if (this.puddleTimer > 0) return;
    this.puddleTimer = 2.5;
    for (const m of this.puddles) {
      if (m.isEnabled() && Math.hypot(m.position.x - px, m.position.z - pz) < 26) continue;
      const x = Math.floor(px + (Math.random() - 0.5) * 44), z = Math.floor(pz + (Math.random() - 0.5) * 44);
      const y = world.surfaceY(x, z);
      if (y < 1) continue;
      const top = world.getBlock(x, y, z);
      const def = BLOCKS[top];
      if (!def || def.render !== "solid" || def.fluid || world.getBlock(x, y + 1, z) !== 0) continue;
      const s = 1 + Math.random() * 2.2;
      m.scaling.set(s, 1, s * (0.6 + Math.random() * 0.6));
      m.rotation.y = Math.random() * Math.PI;
      m.position.set(x + 0.5, y + 1.02, z + 0.5);
      m.setEnabled(true);
    }
  }

  update(dt: number, world: World | null, player: Vector3, wet: number, shake: (v: number) => void): void {
    if (world) this.updatePuddles(dt, world, player.x, player.z, wet);
    // debris & falling blocks
    for (const d of this.debris) {
      d.life += dt;
      d.vel.y -= 26 * dt;
      const next = d.pos.add(d.vel.scale(dt));
      if (world) {
        const below = world.getBlock(Math.floor(next.x), Math.floor(next.y - d.size / 2), Math.floor(next.z));
        if (below !== 0 && below !== -1 && isSolidId(below) && d.vel.y < 0) {
          if (d.placeId) {
            const lx = Math.floor(next.x), ly = Math.floor(next.y - d.size / 2) + 1, lz = Math.floor(next.z);
            if (world.getBlock(lx, ly, lz) === 0) world.setBlock(lx, ly, lz, d.placeId);
            d.life = d.max + 1;
            continue;
          }
          next.y = Math.floor(next.y - d.size / 2) + 1 + d.size / 2;
          d.vel.y = -d.vel.y * 0.3;
          d.vel.x *= 0.6; d.vel.z *= 0.6;
          d.spin.scaleInPlace(0.6);
        }
        const side = world.getBlock(Math.floor(next.x), Math.floor(next.y), Math.floor(next.z));
        if (side !== 0 && side !== -1 && isSolidId(side) && !d.placeId) { d.vel.x *= -0.3; d.vel.z *= -0.3; next.x = d.pos.x; next.z = d.pos.z; }
      }
      d.pos.copyFrom(next);
      d.mesh.position.copyFrom(d.pos);
      d.mesh.rotation.addInPlace(d.spin.scale(dt));
      if (!d.placeId && d.life > d.max - 0.6) d.mesh.scaling.setAll(Math.max(0.01, (d.max - d.life) / 0.6));
      if (d.pos.y < -10) d.life = d.max + 1;
    }
    for (const d of this.debris) if (d.life > d.max) d.mesh.dispose();
    this.debris = this.debris.filter((d) => d.life <= d.max);
    // eruptions: lava bombs + shake, then stop after ~12 s
    for (const e of this.eruptions) {
      e.t += dt;
      e.bombTimer -= dt;
      const dist = Math.hypot(player.x - e.x, player.z - e.z);
      if (dist < 140) shake(Math.max(0, 0.5 - dist / 300));
      if (e.bombTimer <= 0 && e.t < 10 && this.debris.length < 90) {
        e.bombTimer = 0.35;
        const mesh = MeshBuilder.CreateBox("lavaBomb", { size: 0.7 }, this.scene);
        mesh.material = this.lavaMat;
        mesh.isPickable = false;
        const ang = Math.random() * Math.PI * 2, sp = 6 + Math.random() * 10;
        const pos = new Vector3(e.x, e.y + 2, e.z);
        this.debris.push({ mesh, pos, vel: new Vector3(Math.cos(ang) * sp, 22 + Math.random() * 14, Math.sin(ang) * sp), spin: new Vector3(3, 2, 4), life: 0, max: 12, size: 0.7, placeId: BID.magma });
      }
      if (e.t > 12) for (const p of e.ps) p.stop();
    }
    for (const e of this.eruptions) if (e.t > 22) for (const p of e.ps) p.dispose();
    this.eruptions = this.eruptions.filter((e) => e.t <= 22);
  }

  clear(): void {
    for (const d of this.debris) d.mesh.dispose();
    this.debris = [];
    for (const p of this.puddles) p.setEnabled(false);
    for (const e of this.eruptions) for (const p of e.ps) p.dispose();
    this.eruptions = [];
  }
}

function squareUrl(): string {
  const c = document.createElement("canvas");
  c.width = 4; c.height = 4;
  const g = c.getContext("2d")!;
  g.fillStyle = "#fff";
  g.fillRect(0, 0, 4, 4);
  return c.toDataURL("image/png");
}

function softUrl(): string {
  const c = document.createElement("canvas");
  c.width = 32; c.height = 32;
  const g = c.getContext("2d")!;
  const grd = g.createRadialGradient(16, 16, 0, 16, 16, 16);
  grd.addColorStop(0, "rgba(255,255,255,1)");
  grd.addColorStop(1, "rgba(255,255,255,0)");
  g.fillStyle = grd;
  g.fillRect(0, 0, 32, 32);
  return c.toDataURL("image/png");
}
