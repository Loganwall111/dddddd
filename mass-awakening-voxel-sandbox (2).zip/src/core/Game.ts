// Game: the orchestrator. Owns the Babylon engine/scene, environment, world streaming, player, entities,
// inventory & containers, crafting, survival rules, TNT/explosions, dimensions/portals, saving and the UI snapshot.

import {
  Color3, Color4, Engine, Mesh, MeshBuilder, ParticleSystem, Scene, StandardMaterial, Texture, Vector3, Vector4, Material,
} from "../rendering/babylon";
import { BLOCKS, BID, blockDef, blockIdByKey, isFluidId, isReplaceable, isSolidId } from "../blocks/blocks";
import { buildAtlas, buildCrackFrames, tileUV, type Atlas, TILE } from "../blocks/textures";
import { ITEM_BY_KEY, itemDef, maxStackOf, durabilityOf, type ItemDef, CREATIVE_TABS, ITEMS, itemName } from "../items/items";
import {
  type ItemStack, type Slot, addToSlots, clickSlot, shiftMove, countItem, removeItem, damageStack, makeStack, newSlots, cloneSlot,
  HOTBAR_START, MAIN_START, ARMOR_START, OFFHAND_INDEX, PLAYER_SLOTS,
} from "../inventory/inventory";
import { matchRecipe, fuelTime, smeltFor, type Recipe } from "../crafting/recipes";
import { World } from "../world/world";
import { CHUNK_SIZE, SEA_LEVEL, type DimId, type GenParams, WORLD_HEIGHT } from "../world/generator";
import { DIMENSIONS, findFrameInterior, mapCoordinates, portalDestination, tryIgnitePortal, type DimensionDef } from "../dimensions/dimensions";
import { db, type WorldMeta, type ContainerRecord, type PlayerSave } from "../persistence/db";
import { Environment, type Weather } from "../rendering/environment";
import { createMaterials, createCrackMaterials, applyWaterQuality, setPortalTime, setWetness, type MaterialLib } from "../rendering/materials";
import { Effects } from "./effects";
import { volcanoesNear, tourStops } from "../world/generator";

export interface TutorialStep { text: string; key: string; }
export const TUTORIAL_STEPS: TutorialStep[] = [
  { key: "moved", text: "Move with W A S D and look around with the mouse." },
  { key: "broken", text: "Hold left click on a block to break it." },
  { key: "placed", text: "Right click to place the block in your hand." },
  { key: "opened", text: "Press E to open your inventory and crafting grid." },
  { key: "light", text: "Place a torch or coloured lamp — lights tint the world around them." },
  { key: "talked", text: "Right click a villager to talk to them." },
  { key: "portal", text: "Light the obsidian frame east of the plaza (z = -22) with Flint and Steel." },
  { key: "tour", text: "Open the pause menu (Esc) and take the World Tour." },
];
import { EntityManager, type EntityHooks, DEFAULT_CHARACTER, type CharacterOpts, MOBS, type Mob } from "../entities/entities";
import { Player, raycastBlocks, type InputState, type RayHit } from "../player/player";
import { audio } from "../audio/audio";
import type { Settings } from "./settings";
import { seedToInt } from "../world/noise";

export type Screen = "none" | "inventory" | "crafting" | "furnace" | "chest" | "pause" | "dead" | "dialogue" | "creative" | "controls" | "debug";

export interface UiMessage {
  id: number;
  text: string;
  t: number;
}

export interface Snapshot {
  ready: boolean;
  mode: "menu" | "world";
  creative: boolean;
  difficulty: string;
  hp: number;
  maxHp: number;
  hunger: number;
  saturation: number;
  air: number;
  xp: number;
  level: number;
  armor: number;
  selected: number;
  hotbar: Slot[];
  inv: Slot[];
  cursor: Slot;
  craftGrid: Slot[];
  craftSize: number;
  craftOut: Slot;
  container: { kind: "chest" | "furnace"; slots: Slot[]; burn: number; burnMax: number; cook: number; cookMax: number } | null;
  screen: Screen;
  dimension: DimId;
  dimName: string;
  timeText: string;
  dayFrac: number;
  season: string;
  weather: Weather;
  fps: number;
  pos: { x: number; y: number; z: number };
  biome: string;
  messages: UiMessage[];
  dialogue: { name: string; text: string } | null;
  loading: { ready: number; total: number; text: string } | null;
  thirdPerson: boolean;
  flying: boolean;
  debug: boolean;
  worldName: string;
  portalProgress: number;
  underwater: string | null;
  sprinting: boolean;
  cracks: number;
  targetName: string;
  pointerLocked: boolean;
  seedText: string;
  seed: number;
  dayNumber: number;
  hostileCount: number;
  dead: boolean;
  dimStatus: string;
  hudScale: number;
  tour: { label: string; fade: number; idx: number; total: number } | null;
  tutorial: { step: number; total: number; text: string; done: boolean } | null;
}

const SEASON_NAMES = ["Spring", "Summer", "Autumn", "Winter"];
const REACH_SURVIVAL = 5.0;
const REACH_CREATIVE = 6.0;

// ---- Icons (procedural pixel-art artwork generated from item specs) ---------
let atlasRef: Atlas | null = null;
const iconCache = new Map<string, string>();

function drawTileTo(g: CanvasRenderingContext2D, name: string, x: number, y: number, w: number, h: number, tint?: string): void {
  if (!atlasRef) return;
  const [u0, v0] = tileUV(name);
  const sx = Math.round(u0 * atlasRef.size), sy = Math.round(v0 * atlasRef.size);
  g.drawImage(atlasRef.color, sx, sy, TILE, TILE, x, y, w, h);
  if (tint) {
    g.globalAlpha = 0.3;
    g.fillStyle = tint;
    g.fillRect(x, y, w, h);
    g.globalAlpha = 1;
  }
}

/** Generates a 32x32 pixel icon for an item key (blocks are drawn as isometric cubes from the atlas). */
export function iconDataUrl(key: string): string {
  const cached = iconCache.get(key);
  if (cached) return cached;
  const cv = document.createElement("canvas");
  cv.width = 32;
  cv.height = 32;
  const g = cv.getContext("2d")!;
  g.imageSmoothingEnabled = false;
  const def = itemDef(key);
  const spec = def?.icon ?? { t: "misc", shape: "ball", color: "#888" };
  if (spec.t === "block") {
    const b = BLOCKS.find((x) => x.key === key);
    if (b && b.render !== "plant" && b.render !== "torch") {
      // iso cube: top, left, right faces
      const top = b.top, side = b.side;
      g.save();
      g.setTransform(1, 0.5, -1, 0.5, 16, 6);
      drawTileTo(g, top, 0, 0, 16, 16);
      g.restore();
      g.save();
      g.setTransform(1, 0.5, 0, 1, 1, 14);
      drawTileTo(g, side, 0, 0, 15, 16, "#000");
      g.restore();
      g.save();
      g.setTransform(1, -0.5, 0, 1, 16, 14);
      drawTileTo(g, side, 0, 0, 15, 16, "#000");
      g.restore();
      g.fillStyle = "rgba(0,0,0,0.12)";
    } else {
      const shape = b?.render === "plant" ? "plant" : "torch";
      g.fillStyle = shape === "plant" ? "#4f9a2f" : "#f0b040";
      if (b?.key === "torch") { g.fillStyle = "#7a5232"; g.fillRect(14, 12, 4, 18); g.fillStyle = "#ffd060"; g.fillRect(12, 6, 8, 8); }
      else if (b) drawTileTo(g, b.side, 6, 6, 20, 20);
    }
  } else if (spec.t === "tool") {
    g.strokeStyle = spec.handle ?? "#8a5a34";
    g.lineWidth = 3;
    g.beginPath(); g.moveTo(6, 26); g.lineTo(22, 10); g.stroke();
    g.fillStyle = spec.head;
    g.strokeStyle = "#202020";
    g.lineWidth = 1;
    const tool = spec.tool;
    if (tool === "pickaxe") { g.beginPath(); g.moveTo(14, 6); g.quadraticCurveTo(28, 6, 28, 16); g.lineTo(24, 14); g.quadraticCurveTo(18, 10, 14, 10); g.closePath(); g.fill(); g.stroke(); }
    else if (tool === "axe") { g.fillRect(16, 5, 10, 9); g.strokeRect(16, 5, 10, 9); }
    else if (tool === "shovel") { g.beginPath(); g.ellipse(22, 9, 5, 6, 0.6, 0, Math.PI * 2); g.fill(); g.stroke(); }
    else if (tool === "hoe") { g.fillRect(16, 5, 4, 9); g.fillRect(12, 5, 12, 3); }
    else if (tool === "flint") { g.fillStyle = "#7a7a7a"; g.beginPath(); g.arc(20, 10, 5, 0, Math.PI * 2); g.fill(); g.fillStyle = "#e89a30"; g.fillRect(6, 6, 6, 4); }
    else if (tool === "shears") { g.strokeStyle = spec.head; g.lineWidth = 2; g.beginPath(); g.moveTo(8, 8); g.lineTo(24, 24); g.moveTo(24, 8); g.lineTo(8, 24); g.stroke(); }
    else { g.beginPath(); g.moveTo(20, 4); g.lineTo(28, 8); g.lineTo(14, 22); g.lineTo(10, 18); g.closePath(); g.fill(); g.stroke(); }
  } else if (spec.t === "armor") {
    g.fillStyle = spec.color;
    g.strokeStyle = "#202020";
    const s = spec.slot;
    if (s === "head") { g.fillRect(8, 6, 16, 12); g.strokeRect(8, 6, 16, 12); g.fillStyle = "#101010"; g.fillRect(11, 12, 10, 3); }
    else if (s === "chest") { g.beginPath(); g.moveTo(6, 6); g.lineTo(12, 4); g.lineTo(20, 4); g.lineTo(26, 6); g.lineTo(24, 26); g.lineTo(8, 26); g.closePath(); g.fill(); g.stroke(); }
    else if (s === "legs") { g.fillRect(8, 6, 16, 6); g.fillRect(8, 12, 6, 14); g.fillRect(18, 12, 6, 14); }
    else { g.fillRect(7, 12, 8, 14); g.fillRect(17, 12, 8, 14); }
  } else if (spec.t === "food") {
    g.fillStyle = spec.color;
    g.strokeStyle = "#202020";
    if (spec.shape === "round") { g.beginPath(); g.arc(16, 17, 10, 0, Math.PI * 2); g.fill(); g.stroke(); g.fillStyle = spec.accent ?? "#3f8a29"; g.fillRect(16, 4, 4, 5); }
    else if (spec.shape === "bread") { g.beginPath(); g.ellipse(16, 17, 12, 8, 0, 0, Math.PI * 2); g.fill(); g.stroke(); }
    else { g.beginPath(); g.ellipse(16, 16, 11, 8, -0.4, 0, Math.PI * 2); g.fill(); g.stroke(); g.fillStyle = "#f4e6d0"; g.fillRect(22, 8, 3, 3); }
  } else if (spec.t === "ingot") {
    g.fillStyle = spec.color;
    g.strokeStyle = "#303030";
    g.beginPath(); g.moveTo(6, 22); g.lineTo(10, 10); g.lineTo(26, 10); g.lineTo(28, 22); g.closePath(); g.fill(); g.stroke();
    g.fillStyle = spec.shine ?? "#fff"; g.fillRect(12, 12, 8, 2);
  } else if (spec.t === "gem") {
    g.fillStyle = spec.color;
    g.strokeStyle = "#101010";
    g.beginPath();
    if (spec.shape === "diamond") { g.moveTo(16, 4); g.lineTo(26, 13); g.lineTo(16, 28); g.lineTo(6, 13); }
    else if (spec.shape === "pearl") { g.arc(16, 16, 9, 0, Math.PI * 2); }
    else if (spec.shape === "cluster") { g.moveTo(10, 26); g.lineTo(12, 8); g.lineTo(16, 20); g.lineTo(20, 6); g.lineTo(22, 26); }
    else { g.moveTo(10, 26); g.lineTo(16, 4); g.lineTo(24, 24); }
    g.closePath(); g.fill(); g.stroke();
    g.fillStyle = "rgba(255,255,255,0.5)"; g.fillRect(13, 9, 3, 3);
  } else if (spec.t === "raw") {
    g.fillStyle = spec.color; g.strokeStyle = "#303030";
    g.beginPath(); g.ellipse(16, 16, 11, 9, 0.2, 0, Math.PI * 2); g.fill(); g.stroke();
    g.fillStyle = spec.accent; g.fillRect(10, 11, 6, 4); g.fillRect(18, 17, 5, 4);
  } else if (spec.t === "egg") {
    g.fillStyle = spec.a; g.strokeStyle = "#202020";
    g.beginPath(); g.ellipse(16, 17, 8, 11, 0, 0, Math.PI * 2); g.fill(); g.stroke();
    g.fillStyle = spec.b; g.fillRect(11, 12, 4, 4); g.fillRect(18, 18, 5, 5); g.fillRect(12, 21, 3, 3);
  } else {
    const shape = spec.shape;
    g.fillStyle = spec.color; g.strokeStyle = "#202020";
    if (shape === "stick") { g.strokeStyle = spec.color; g.lineWidth = 4; g.beginPath(); g.moveTo(8, 24); g.lineTo(24, 8); g.stroke(); }
    else if (shape === "ball") { g.beginPath(); g.arc(16, 16, 9, 0, Math.PI * 2); g.fill(); g.stroke(); }
    else if (shape === "string") { g.strokeStyle = spec.color; g.lineWidth = 2; g.beginPath(); g.moveTo(6, 10); g.bezierCurveTo(16, 24, 18, 4, 26, 22); g.stroke(); }
    else if (shape === "feather") { g.fillStyle = spec.color; g.beginPath(); g.ellipse(16, 16, 5, 12, 0.5, 0, Math.PI * 2); g.fill(); g.fillStyle = spec.accent ?? "#9ab8d8"; g.fillRect(14, 6, 2, 20); }
    else if (shape === "bone") { g.fillRect(8, 14, 16, 4); g.beginPath(); g.arc(7, 12, 4, 0, Math.PI * 2); g.arc(7, 20, 4, 0, Math.PI * 2); g.arc(25, 12, 4, 0, Math.PI * 2); g.arc(25, 20, 4, 0, Math.PI * 2); g.fill(); }
    else if (shape === "powder") { g.beginPath(); g.arc(12, 20, 4, 0, Math.PI * 2); g.arc(20, 14, 5, 0, Math.PI * 2); g.arc(18, 24, 3, 0, Math.PI * 2); g.fill(); }
    else if (shape === "arrow") { g.strokeStyle = spec.color; g.lineWidth = 2; g.beginPath(); g.moveTo(6, 26); g.lineTo(24, 8); g.stroke(); g.fillStyle = spec.accent ?? "#eee"; g.beginPath(); g.moveTo(24, 6); g.lineTo(28, 8); g.lineTo(24, 12); g.fill(); }
    else if (shape === "book") { g.fillRect(7, 6, 18, 22); g.strokeRect(7, 6, 18, 22); g.fillStyle = "#e8d8b8"; g.fillRect(9, 8, 14, 18); }
    else if (shape === "compass" || shape === "seed" || shape === "hide" || shape === "meat") { g.beginPath(); g.arc(16, 16, 9, 0, Math.PI * 2); g.fill(); g.stroke(); if (spec.accent) { g.fillStyle = spec.accent; g.fillRect(15, 8, 2, 8); } }
    else { g.fillRect(8, 8, 16, 16); g.strokeRect(8, 8, 16, 16); }
  }
  const url = cv.toDataURL("image/png");
  iconCache.set(key, url);
  return url;
}

// ---- Game -------------------------------------------------------------------------
type Listener = (s: Snapshot) => void;

interface TntEntity {
  x: number;
  y: number;
  z: number;
  fuse: number;
  mesh: Mesh;
  id: number;
}

interface Furnace {
  slots: Slot[];
  burn: number;
  burnMax: number;
  cook: number;
}

const DIM_TO_INDEX: Record<DimId, number> = { overworld: 0, nether: 1, end: 2, sift: 3 };

export class Game {
  readonly canvas: HTMLCanvasElement;
  readonly engine: Engine;
  readonly scene: Scene;
  env!: Environment;
  settings: Settings;
  mats!: MaterialLib;
  crackMats: StandardMaterial[] = [];
  private atlas!: Atlas;
  private outline!: Mesh;
  private crack: Mesh | null = null;
  private crackStage = -1;
  private crackPos: [number, number, number] | null = null;
  world: World | null = null;
  player!: Player;
  entities!: EntityManager;
  meta: WorldMeta | null = null;
  mode: "menu" | "world" = "menu";
  dimDef: DimensionDef = DIMENSIONS.overworld;
  private listeners = new Set<Listener>();
  private input: InputState = { keys: new Set(), mouseDX: 0, mouseDY: 0, leftDown: false, rightDown: false, wheel: 0 };
  private characterOpts: CharacterOpts = { ...DEFAULT_CHARACTER };
  private cursor: Slot = null;
  private craftGrid: Slot[] = newSlots(9);
  private craftSize = 2;
  private craftOut: Slot = null;
  private inv: Slot[] = newSlots(PLAYER_SLOTS);
  private selected = 0;
  private screen: Screen = "none";
  private openContainer: { kind: "chest" | "furnace" | "crafting"; key: string | null; slots: Slot[] } | null = null;
  private furnaces = new Map<string, Furnace>();
  private chests = new Map<string, Slot[]>();
  private messages: UiMessage[] = [];
  private msgId = 1;
  private hp = 20;
  private hunger = 20;
  private saturation = 5;
  private air = 300;
  private xp = 0;
  private hurtCooldown = 0;
  private regenTimer = 0;
  private starveTimer = 0;
  private exhaustion = 0;
  private breakProgress = 0;
  private breakTarget: RayHit | null = null;
  private attackCd = 0;
  private placeCd = 0;
  private useCd = 0;
  private worldTime = 0;
  private weather: Weather = "clear";
  private weatherTimer = 240;
  private shake = 0;
  private portalTimer = 0;
  private portalCooldown = 0;
  private pendingArrival: { dim: DimId; x: number; z: number; frame: string | null; fromDim: DimId } | null = null;
  private tnts: TntEntity[] = [];
  private tntId = 1;
  private dialogue: { name: string; text: string; t: number } | null = null;
  private dead = false;
  private loading: { ready: number; total: number; text: string } | null = null;
  private running = false;
  private lastFrame = 0;
  private autosaveTimer = 0;
  private snapTimer = 0;
  private fps = 0;
  private debug = false;
  private paused = false;
  private targetName = "";
  private seasonIdx = 1;
  private lastDayNum = -1;
  private blastFlash: Mesh | null = null;
  private particles: ParticleSystem[] = [];
  private reflectionTick = 0;
  private shadowTick = 0;
  private sessionStart = performance.now();
  private hotbarWarnedFull = false;
  private worldRadius = 6;
  private panoramaAngle = 0;
  private iconTextures = new Map<string, Texture>();
  private heldKey = "";
  private sectionNames = ["inv", "craft", "container", "creative"] as const;
  private subscribedVisibility = true;
  effects!: Effects;
  private tutorial: Record<string, boolean> = {};
  private tutorialMoved = 0;
  private eruptionTimer = 90;
  private tour: { stops: { x: number; z: number; y: number; label: string }[]; idx: number; t: number; fade: number; waiting: boolean; saved: { x: number; y: number; z: number; yaw: number; pitch: number } } | null = null;

  constructor(canvas: HTMLCanvasElement, settings: Settings) {
    this.canvas = canvas;
    this.settings = settings;
    this.engine = new Engine(canvas, settings.antialias, { preserveDrawingBuffer: false, stencil: true, adaptToDeviceRatio: true }, true);
    this.scene = new Scene(this.engine);
    this.scene.skipPointerMovePicking = true;
    this.scene.autoClear = true;
    this.atlas = buildAtlas();
    atlasRef = this.atlas;
    this.mats = createMaterials(this.scene, this.atlas, { shadows: settings.shadows, waterQuality: settings.waterQuality });
    this.crackMats = createCrackMaterials(this.scene, buildCrackFrames());
    this.player = new Player(this.scene, this.characterOpts);
    this.env = new Environment(this.scene, this.engine, this.player.camera, settings);
    this.outline = MeshBuilder.CreateBox("outline", { size: 1.004 }, this.scene);
    this.outline.enableEdgesRendering();
    this.outline.edgesWidth = 2.5;
    this.outline.edgesColor = new Color4(0, 0, 0, 0.9);
    this.outline.isPickable = false;
    this.outline.setEnabled(false);
    this.entities = new EntityManager(this.scene, this.makeDummyWorld(), this.makeHooks());
    this.effects = new Effects(this.scene, this.mats, this.atlas);
    this.env.onLightning = (_pos, dist) => {
      audio.thunder(dist);
      this.shake = Math.max(this.shake, Math.max(0, 0.4 - dist / 400) * this.settings.screenShake);
    };
    this.setupInput();
    this.engine.setSize(canvas.clientWidth, canvas.clientHeight);
    window.addEventListener("resize", this.onResize);
    this.engine.runRenderLoop(this.frame);
    this.running = true;
    this.lastFrame = performance.now();
    this.applySettings(settings);
  }

  private makeDummyWorld(): World {
    return new World({
      scene: this.scene, dim: "overworld", params: { seed: 0, dim: "overworld", type: "flat" }, store: this.dummyStore(),
      materials: this.mats as unknown as Record<string, StandardMaterial>, workerCount: 0,
    });
  }

  private dummyStore() {
    return { load: async () => null, save: async () => undefined, keys: async () => new Set<string>() };
  }

  private onResize = () => {
    this.engine.resize();
  };

  // ---- Public API ------------------------------------------------------------------
  subscribe(fn: Listener): () => void {
    this.listeners.add(fn);
    fn(this.snapshot());
    return () => this.listeners.delete(fn);
  }

  setCharacter(opts: CharacterOpts): void {
    this.characterOpts = opts;
  }

  /** Panorama: orbit camera around a generated landscape behind the main menu. */
  async startPanorama(): Promise<void> {
    if (this.mode === "menu" && this.world) return;
    await this.teardownWorld(false);
    this.mode = "menu";
    this.meta = null;
    this.env.applySettings(this.settings);
    const params: GenParams = { seed: seedToInt("aetherforged-panorama"), dim: "overworld", type: "default" };
    this.world = new World({
      scene: this.scene, dim: "overworld", params, store: this.dummyStore(), materials: this.mats as unknown as Record<string, StandardMaterial>,
      workerCount: 2, onChunkSpawns: () => undefined,
    });
    this.worldTime = 0.22 * (this.settings.dayLengthMinutes * 60);
    this.player.camera.position.set(0, 110, 0);
    this.player.camera.rotation.set(0.25, 0, 0);
    this.screen = "none";
    this.emit();
  }

  /** Enters a saved world. Loads chunks around spawn while reporting progress. */
  async enterWorld(meta: WorldMeta, onProgress?: (p: { ready: number; total: number }) => void): Promise<void> {
    await this.teardownWorld(true);
    this.mode = "world";
    this.meta = meta;
    this.dead = false;
    this.hp = 20; this.hunger = 20; this.saturation = 5; this.air = 300; this.xp = 0;
    this.dimDef = DIMENSIONS[(meta.player?.dimension ?? "overworld") as DimId];
    const dim = this.dimDef.id;
    this.worldTime = meta.worldTime ?? 0;
    this.weatherTimer = 200;
    this.weather = "clear";
    this.inv = newSlots(PLAYER_SLOTS);
    this.craftGrid = newSlots(9);
    this.cursor = null;
    this.screen = "none";
    this.messages = [];
    this.dialogue = null;
    this.furnaces.clear();
    this.chests.clear();
    this.player.creative = meta.mode === "creative";
    this.player.flying = false;
    this.player.thirdPerson = meta.player?.thirdPerson ?? false;
    this.player.fov = this.settings.fov;
    const pl = meta.player;
    if (pl) {
      this.inv = pl.inventory.slice(0, PLAYER_SLOTS).concat(newSlots(Math.max(0, PLAYER_SLOTS - pl.inventory.length)));
      this.hp = pl.hp; this.hunger = pl.hunger; this.saturation = pl.saturation; this.xp = pl.xp; this.air = pl.air;
      this.selected = pl.hotbar;
    }
    this.tutorial = {};
    this.tutorialMoved = 0;
    this.tour = null;
    if (!pl && meta.type === "tutorial") this.giveTutorialKit();
    this.enterDimensionWorld(dim, meta);
    const startPos = pl?.dimPos?.[dim] ?? pl?.pos ?? null;
    if (startPos && pl) {
      this.player.pos.set(startPos.x, startPos.y, startPos.z);
      this.player.yaw = pl.yaw;
      this.player.pitch = pl.pitch;
      this.player.flying = pl.flying && this.player.creative;
    } else {
      const sp = await this.findSpawn(0, 0, onProgress);
      this.player.pos.set(sp.x + 0.5, sp.y, sp.z + 0.5);
      this.player.yaw = 0;
      this.player.pitch = 0;
    }
    this.meta.spawn = this.meta.spawn ?? { x: this.player.pos.x, y: this.player.pos.y, z: this.player.pos.z };
    this.player.vel.set(0, 0, 0);
    this.player.fallStart = this.player.pos.y;
    this.wait(async () => {
      await this.waitForArea(this.player.pos.x, this.player.pos.z, 3, onProgress);
    });
    this.refreshHeld(true);
    this.addMessage(`Welcome to ${meta.name}`);
    this.autosaveTimer = 30;
    this.emit();
    await this.saveNow();
  }

  private wait(fn: () => Promise<void>): void {
    void fn();
  }

  private enterDimensionWorld(dim: DimId, meta: WorldMeta): void {
    this.dimDef = DIMENSIONS[dim];
    const store = db.chunkStore(meta.id);
    const params = db.genParamsFor(meta, dim);
    const workers = Math.max(2, Math.min(4, (navigator.hardwareConcurrency || 4) - 1));
    this.world = new World({
      scene: this.scene, dim, params, store, materials: this.mats as unknown as Record<string, StandardMaterial>,
      workerCount: workers,
      onChunkSpawns: (spawns) => this.entities.spawnFromRecords(spawns),
    });
    this.world.season = this.currentSeason();
    this.entities.setWorld(this.world);
    this.world.setSeason(this.currentSeason());
    this.env.applySettings(this.settings);
  }

  private async findSpawn(x: number, z: number, onProgress?: (p: { ready: number; total: number }) => void): Promise<{ x: number; y: number; z: number }> {
    const w = this.world!;
    // wait until spawn chunks are generated, then find the first standable spot
    for (let i = 0; i < 600; i++) {
      w.update(x, z, 8, 3);
      const r = w.readyAround(x, z, 2);
      onProgress?.(r);
      this.loading = { ready: r.ready, total: r.total, text: "Preparing spawn area" };
      if (r.ready >= r.total) break;
      await new Promise((res) => setTimeout(res, 16));
    }
    let y = this.dimDef.spawnFallbackY;
    for (let yy = WORLD_HEIGHT - 4; yy > 2; yy--) {
      const id = w.getBlock(x, yy, z);
      if (id > 0 && isSolidId(id) && w.getBlock(x, yy + 1, z) === 0 && w.getBlock(x, yy + 2, z) === 0) { y = yy + 1; break; }
    }
    if (this.dimDef.id === "overworld" && y < SEA_LEVEL) y = SEA_LEVEL + 1;
    this.loading = null;
    return { x, y, z };
  }

  private async waitForArea(x: number, z: number, radius: number, onProgress?: (p: { ready: number; total: number }) => void): Promise<void> {
    const w = this.world;
    if (!w) return;
    const start = performance.now();
    while (w === this.world && performance.now() - start < 15000) {
      const r = w.readyAround(x, z, radius);
      onProgress?.(r);
      if (r.ready >= r.total * 0.9) break;
      await new Promise((res) => setTimeout(res, 50));
    }
    this.loading = null;
  }

  /** Saves everything (world meta, player, chunks, containers). */
  async saveNow(): Promise<void> {
    if (!this.meta || this.mode !== "world") return;
    const pos = this.player.pos;
    const dimPos = { ...(this.meta.player?.dimPos ?? {}) } as PlayerSave["dimPos"];
    dimPos[this.dimDef.id] = { x: pos.x, y: pos.y, z: pos.z };
    const save: PlayerSave = {
      pos: { x: pos.x, y: pos.y, z: pos.z },
      yaw: this.player.yaw,
      pitch: this.player.pitch,
      hp: this.hp,
      hunger: this.hunger,
      saturation: this.saturation,
      xp: this.xp,
      air: this.air,
      hotbar: this.selected,
      inventory: this.inv.map((s) => cloneSlot(s)),
      dimension: this.dimDef.id,
      dimPos,
      flying: this.player.flying,
      thirdPerson: this.player.thirdPerson,
    };
    this.meta = { ...this.meta, player: save, worldTime: this.worldTime, lastPlayed: Date.now(), weatherSeed: this.meta.weatherSeed };
    try {
      await db.putWorld(this.meta);
      await this.world?.flush();
      for (const [k, slots] of this.chests) {
        const [dim, pos] = k.split("|");
        await db.putContainer(this.meta.id, dim as DimId, pos, { key: k, kind: "chest", slots: slots.map(cloneSlot) });
      }
      for (const [k, f] of this.furnaces) {
        const [dim, pos] = k.split("|");
        await db.putContainer(this.meta.id, dim as DimId, pos, { key: k, kind: "furnace", slots: f.slots.map(cloneSlot), burn: f.burn, burnMax: f.burnMax, cook: f.cook });
      }
      this.addMessage("World saved");
    } catch (err) {
      console.error("Save failed", err);
      this.addMessage("Save failed: storage unavailable");
    }
  }

  async exitToMenu(): Promise<void> {
    await this.saveNow();
    await this.teardownWorld(true);
    await this.startPanorama();
  }

  private async teardownWorld(save: boolean): Promise<void> {
    if (save && this.mode === "world") await this.saveNow();
    this.breakProgress = 0;
    this.clearCrack();
    this.tour = null;
    this.effects?.clear();
    for (const t of this.tnts) t.mesh.dispose();
    this.tnts = [];
    this.entities.dispose();
    this.entities = new EntityManager(this.scene, this.makeDummyWorld(), this.makeHooks());
    this.world?.dispose();
    this.world = null;
    this.player.thirdPerson = false;
    this.player.figure.root.setEnabled(false);
  }

  setScreen(s: Screen): void {
    if (s === "inventory") this.tutorial.opened = true;
    if (s !== "none" && this.screen === "none" && document.pointerLockElement === this.canvas) document.exitPointerLock();
    if (s === "none") this.closeContainer();
    this.screen = s;
    this.emit();
  }

  requestPointerLock(): void {
    if (this.mode !== "world" || this.screen !== "none" || this.dead) return;
    this.canvas.requestPointerLock?.();
  }

  closeScreen(): void {
    if (this.screen === "chest" || this.screen === "furnace" || this.screen === "crafting" || this.screen === "inventory") {
      // return cursor item to inventory
      if (this.cursor) {
        const rem = addToSlots(this.inv, this.cursor);
        if (rem) this.entities.spawnItem(rem, this.player.pos);
        this.cursor = null;
      }
      for (let i = 0; i < this.craftGrid.length; i++) {
        const s = this.craftGrid[i];
        if (s) {
          const rem = addToSlots(this.inv, s);
          if (rem) this.entities.spawnItem(rem, this.player.pos);
          this.craftGrid[i] = null;
        }
      }
      this.craftOut = null;
    }
    this.closeContainer();
    this.screen = "none";
    this.emit();
    this.requestPointerLock();
  }

  private closeContainer(): void {
    this.openContainer = null;
  }

  /** Opens a chest/furnace/crafting table at a block position (world coords). */
  openBlock(kind: "chest" | "furnace" | "crafting", x: number, y: number, z: number): void {
    const key = `${this.dimDef.id}|${x},${y},${z}`;
    if (kind === "crafting") {
      this.craftSize = 3;
      this.openContainer = { kind: "crafting", key: null, slots: [] };
      this.screen = "crafting";
    } else if (kind === "chest") {
      if (!this.chests.has(key)) this.chests.set(key, newSlots(27));
      this.openContainer = { kind: "chest", key, slots: this.chests.get(key)! };
      this.screen = "chest";
      audio.play("chest", { pos: { x, y, z } });
    } else {
      if (!this.furnaces.has(key)) this.furnaces.set(key, { slots: newSlots(3), burn: 0, burnMax: 0, cook: 0 });
      this.openContainer = { kind: "furnace", key, slots: this.furnaces.get(key)!.slots };
      this.screen = "furnace";
      audio.play("open", { pos: { x, y, z } });
    }
    this.craftSize = kind === "crafting" ? 3 : 2;
    this.player.camera.rotation.x = this.player.camera.rotation.x;
    if (document.pointerLockElement === this.canvas) document.exitPointerLock();
    this.emit();
  }

  /** Inventory click from the UI. section: 'inv' | 'craft' | 'container' | 'creative' */
  clickSlot(section: "inv" | "craft" | "container" | "creative", index: number, button: 0 | 2, shift: boolean): void {
    if (section === "creative") {
      const key = this.creativeKeys()[index];
      if (!key) return;
      const max = maxStackOf(key);
      if (shift) {
        addToSlots(this.inv, makeStack(key, max));
      } else if (!this.cursor) {
        this.cursor = makeStack(key, button === 2 ? 1 : max);
      } else if (this.cursor.key === key && this.cursor.count < max) {
        this.cursor.count = max;
      }
      this.emit();
      return;
    }
    if (section === "craft") {
      if (index === 0 && this.craftOut !== undefined) {
        // output slot
        this.takeCraftOutput(button, shift);
        return;
      }
      const slots = this.craftGrid;
      const i = index - 1;
      if (i < 0 || i >= slots.length) return;
      if (shift) this.shiftFrom(slots, i, "craft");
      else {
        const g2 = this;
        clickSlot({ get cursor() { return g2.cursor; }, set cursor(v) { g2.cursor = v; } } as { cursor: Slot }, slots, i, button);
      }
      this.recomputeCraft();
      this.emit();
      return;
    }
    if (section === "container") {
      const oc = this.openContainer;
      if (!oc) return;
      if (shift) this.shiftFrom(oc.slots, index, "container");
      else {
        const g = this;
        const acceptFurnace = oc.kind === "furnace" && index === 2 ? () => false : undefined;
        if (oc.kind === "furnace" && index === 2) {
          // output slot: take only
          if (!g.cursor && oc.slots[2]) { g.cursor = oc.slots[2]; oc.slots[2] = null; }
          else if (g.cursor && oc.slots[2] && canMerge(g.cursor, oc.slots[2])) {
            const room = maxStackOf(g.cursor.key) - g.cursor.count;
            const take = Math.min(room, oc.slots[2].count);
            g.cursor.count += take; oc.slots[2].count -= take; if (oc.slots[2].count <= 0) oc.slots[2] = null;
          }
        } else {
          clickSlot({ get cursor() { return g.cursor; }, set cursor(v) { g.cursor = v; } } as { cursor: Slot }, oc.slots, index, button, acceptFurnace);
        }
        void acceptFurnace;
      }
      this.emit();
      return;
    }
    // player inventory
    const g = this;
    const ctx = { get cursor() { return g.cursor; }, set cursor(v) { g.cursor = v; } } as { cursor: Slot };
    const armorAccept = index >= ARMOR_START && index < ARMOR_START + 4
      ? (s: ItemStack) => { const slot = ["head", "chest", "legs", "feet"][index - ARMOR_START]; return itemDef(s.key)?.armor?.slot === slot; }
      : undefined;
    if (shift) this.shiftFrom(this.inv, index, "inv");
    else clickSlot(ctx, this.inv, index, button, armorAccept);
    this.emit();
  }

  private takeCraftOutput(button: 0 | 2, shift: boolean): void {
    const out = this.craftOut;
    if (!out) return;
    if (shift) {
      // craft as many times as possible into the inventory
      let guard = 64;
      while (guard-- > 0) {
        const o = this.craftOut;
        if (!o) break;
        if (!canFitInInventory(this.inv, o)) break;
        addToSlots(this.inv, makeStack(o.key, o.count));
        this.consumeCraftGrid();
        this.recomputeCraft();
      }
      this.emit();
      return;
    }
    if (this.cursor && (!canMerge(this.cursor, out) || this.cursor.count + out.count > maxStackOf(out.key))) return;
    if (this.cursor) this.cursor.count += out.count;
    else this.cursor = { ...out };
    this.consumeCraftGrid();
    this.recomputeCraft();
    void button;
    this.emit();
  }

  private consumeCraftGrid(): void {
    for (let i = 0; i < this.craftGrid.length; i++) {
      const s = this.craftGrid[i];
      if (!s) continue;
      s.count -= 1;
      if (s.count <= 0) this.craftGrid[i] = null;
    }
    if (this.achievementOnCraft) this.achievementOnCraft = false;
  }

  private achievementOnCraft = false;

  recomputeCraft(): void {
    const size = this.craftSize === 3 ? 3 : 2;
    const grid = this.craftGrid.slice(0, size * size);
    const r = matchRecipe(grid, size);
    this.craftOut = r ? makeStack(r.result.key, r.result.count) : null;
    this.lastRecipe = r;
    this.xp += 0;
  }

  private lastRecipe: Recipe | null = null;

  private shiftFrom(from: Slot[], idx: number, section: "inv" | "craft" | "container"): void {
    const s = from[idx];
    if (!s) return;
    if (section === "inv") {
      if (idx >= HOTBAR_START && idx < MAIN_START) {
        if (this.openContainer && this.openContainer.kind !== "crafting") {
          if (shiftMove(from, idx, [{ slots: this.openContainer.slots }])) return;
        }
        shiftMove(from, idx, [{ slots: this.inv, start: MAIN_START, end: 35 }]);
      } else if (idx >= MAIN_START && idx < ARMOR_START) {
        shiftMove(from, idx, [{ slots: this.inv, start: 0, end: 8 }]);
      } else {
        shiftMove(from, idx, [{ slots: this.inv, start: 0, end: 35 }]);
      }
      return;
    }
    if (section === "craft") {
      if (!shiftMove(from, idx, [{ slots: this.inv, start: MAIN_START, end: 35 }, { slots: this.inv, start: 0, end: 8 }])) return;
      return;
    }
    // container -> inventory
    shiftMove(from, idx, [{ slots: this.inv, start: 0, end: 35 }]);
  }

  /** Items shown in the creative inventory (filtered by tab + search from the UI). */
  creativeKeys(tab: string = "all", search = ""): string[] {
    const q = search.trim().toLowerCase();
    return ITEMS.filter((d) => (tab === "all" || d.tab === tab) && (!q || d.name.toLowerCase().includes(q) || d.key.includes(q)) && d.key !== "air")
      .filter((d) => !d.key.startsWith("nether_portal"))
      .map((d) => d.key);
  }

  selectSlot(i: number): void {
    this.selected = ((i % 9) + 9) % 9;
    this.refreshHeld();
    this.emit();
  }

  dropSelected(all: boolean): void {
    const idx = this.selected;
    const s = this.inv[idx];
    if (!s) return;
    const count = all ? s.count : 1;
    const dropped = makeStack(s.key, count, s.damage);
    s.count -= count;
    if (s.count <= 0) this.inv[idx] = null;
    const dir = this.player.lookDir();
    this.entities.spawnItem(dropped, this.player.eyeY ? new Vector3(this.player.pos.x, this.player.eyeY - 0.3, this.player.pos.z).add(dir.scale(0.8)) : this.player.pos, dir.scale(4));
    this.refreshHeld();
    this.emit();
  }

  setCreative(on: boolean): void {
    if (!this.meta) return;
    this.meta = { ...this.meta, mode: on ? "creative" : "survival" };
    this.player.creative = on;
    if (!on) this.player.flying = false;
    this.addMessage(on ? "Creative mode enabled" : "Survival mode enabled");
    this.emit();
  }

  applySettings(s: Settings): void {
    this.settings = s;
    this.player.fov = s.fov;
    this.player.sensitivity = s.sensitivity;
    this.player.invertY = s.invertY;
    this.player.bobbing = s.viewBobbing && !s.reducedMotion;
    this.worldRadius = s.renderDistance;
    if (this.env) {
      this.env.applySettings(s);
    }
    applyWaterQuality(this.mats, s.waterQuality, s.waterReflections);
    audio.applySettings(s);
    this.engine.setHardwareScalingLevel(1 / Math.max(0.5, Math.min(1, s.renderScale)));
    this.emit();
  }

  setDebug(on: boolean): void {
    this.debug = on;
    this.emit();
  }

  toggleThirdPerson(): void {
    this.player.thirdPerson = !this.player.thirdPerson;
    this.emit();
  }

  eatFood(key: string): boolean {
    const d = itemDef(key);
    if (!d?.food) return false;
    if (this.hunger >= 20 && !d.food.heal) return false;
    this.hunger = Math.min(20, this.hunger + d.food.hunger);
    this.saturation = Math.min(20, this.saturation + d.food.saturation);
    if (d.food.heal) this.hp = Math.min(20, this.hp + d.food.heal);
    audio.play("eat", { pitch: 1 });
    return true;
  }

  respawn(): void {
    if (!this.meta || !this.world) return;
    this.dead = false;
    this.hp = 20; this.hunger = 20; this.saturation = 5; this.air = 300;
    const sp = this.meta.spawn ?? { x: 0, y: 90, z: 0 };
    this.player.pos.set(sp.x, sp.y + 1, sp.z);
    this.player.vel.set(0, 0, 0);
    this.screen = "none";
    this.addMessage("You respawned");
    this.emit();
  }

  /** Mounted once by the UI: keyboard/mouse/pointer events are routed here. */
  private setupInput(): void {
    const c = this.canvas;
    window.addEventListener("keydown", this.onKeyDown);
    window.addEventListener("keyup", this.onKeyUp);
    window.addEventListener("blur", () => this.input.keys.clear());
    window.addEventListener("mousemove", (e) => {
      if (document.pointerLockElement === c) {
        this.input.mouseDX += e.movementX;
        this.input.mouseDY += e.movementY;
      }
    });
    c.addEventListener("mousedown", (e) => {
      audio.ensure();
      if (this.mode !== "world") return;
      if (this.screen !== "none") return;
      if (document.pointerLockElement !== c) { this.requestPointerLock(); return; }
      if (e.button === 0) this.input.leftDown = true;
      if (e.button === 2) { this.input.rightDown = true; this.onUseClick(); }
      if (e.button === 1) this.onPickBlock();
    });
    window.addEventListener("mouseup", (e) => {
      if (e.button === 0) { this.input.leftDown = false; this.breakProgress = 0; }
      if (e.button === 2) this.input.rightDown = false;
    });
    c.addEventListener("contextmenu", (e) => e.preventDefault());
    c.addEventListener("wheel", (e) => {
      if (this.screen !== "none" || this.mode !== "world") return;
      this.selectSlot(this.selected + (e.deltaY > 0 ? 1 : -1));
    }, { passive: true });
    document.addEventListener("pointerlockchange", () => {
      if (document.pointerLockElement !== c && this.screen === "none" && this.mode === "world" && !this.dead && !this.tour) {
        this.screen = "pause";
        this.emit();
      }
    });
  }

  private onKeyDown = (e: KeyboardEvent) => {
    if (this.mode !== "world") return;
    if (this.tour) { if (e.code === "Escape") this.stopTour(); return; }
    if (e.repeat && e.code !== "KeyW") { /* allow repeat for movement keys only */ }
    if (["Space", "ShiftLeft", "ControlLeft", "Tab"].includes(e.code)) e.preventDefault();
    this.input.keys.add(e.code);
    if (this.dead) return;
    if (e.code === "Escape") {
      if (this.screen !== "none") this.closeScreen();
      else { this.setScreen("pause"); }
      return;
    }
    if (this.screen !== "none") {
      if ((e.code === "KeyE" || e.code === "KeyI") && this.screen !== "pause") this.closeScreen();
      return;
    }
    if (e.code === "KeyE") { this.setScreen("inventory"); return; }
    if (e.code === "KeyQ") { this.dropSelected(e.ctrlKey); return; }
    if (e.code === "KeyF") { this.toggleThirdPerson(); return; }
    if (e.code === "F3") { e.preventDefault(); this.setDebug(!this.debug); return; }
    if (e.code === "KeyG" && this.player.creative) { this.player.flying = !this.player.flying; return; }
    if (e.code.startsWith("Digit")) {
      const n = Number(e.code.slice(5));
      if (n >= 1 && n <= 9) this.selectSlot(n - 1);
    }
  };

  private onKeyUp = (e: KeyboardEvent) => {
    this.input.keys.delete(e.code);
  };

  private onPickBlock(): void {
    if (!this.world || !this.player.creative) return;
    const hit = this.castFromEye(REACH_CREATIVE, true);
    if (!hit) return;
    const key = BLOCKS[hit.id]?.key;
    if (!key || !itemDef(key)) return;
    this.inv[this.selected] = makeStack(key, maxStackOf(key));
    this.refreshHeld();
    this.emit();
  }

  private castFromEye(reach: number, includeFluids = false): RayHit | null {
    const look = this.player.lookDir();
    return raycastBlocks(this.world!, this.player.camera.position.x, this.player.camera.position.y, this.player.camera.position.z, look.x, look.y, look.z, reach, includeFluids);
  }

  /** Nearest mob hit along the view ray (within `reach`). */
  private mobTarget(reach: number): Mob | null {
    const eye = this.player.camera.position;
    const look = this.player.lookDir();
    let best: Mob | null = null;
    let bestT = reach;
    for (const m of this.entities.mobs) {
      if (m.dead) continue;
      const c = m.pos.add(new Vector3(0, m.def.height * 0.6, 0));
      const oc = c.subtract(eye);
      const t = Vector3.Dot(oc, look);
      if (t < 0 || t > bestT) continue;
      const d2 = Vector3.Dot(oc, oc) - t * t;
      if (d2 < 0.55) { best = m; bestT = t; }
    }
    return best;
  }

  private onUseClick(): void {
    if (this.placeCd > 0 || this.mode !== "world" || this.screen !== "none") return;
    this.placeCd = 0.2;
    const world = this.world!;
    const reach = this.player.creative ? REACH_CREATIVE : REACH_SURVIVAL;
    this.player.swingT = 1;
    const hit = this.castFromEye(reach, true);
    const sel = this.inv[this.selected];
    // interact first
    if (hit && !BLOCKS[hit.id].fluid) {
      const def = blockDef(hit.id);
      if (def.special === "chest") { this.openBlock("chest", hit.x, hit.y, hit.z); return; }
      if (def.special === "furnace") { this.openBlock("furnace", hit.x, hit.y, hit.z); return; }
      if (def.special === "crafting") { this.openBlock("crafting", hit.x, hit.y, hit.z); return; }
      if (def.special === "tnt" && (!sel || sel.key !== "tnt")) { this.primeTnt(hit.x, hit.y, hit.z, 4); return; }
    }
    const mob = this.mobTarget(3.5);
    if (mob && mob.def.key === "villager") {
      const line = this.entities.talkTo(mob);
      this.tutorial.talked = true;
      this.dialogue = { name: "Villager", text: line, t: 7 };
      this.screen = "dialogue";
      this.emit();
      setTimeout(() => { if (this.screen === "dialogue") { this.screen = "none"; this.dialogue = null; this.emit(); } }, 7000);
      return;
    }
    if (!sel) return;
    const def = itemDef(sel.key);
    if (!def) return;
    if (def.kind === "food" && this.eatFood(sel.key)) {
      if (!this.player.creative) this.consumeOne(this.selected);
      this.refreshHeld();
      this.emit();
      return;
    }
    if (def.kind === "spawn_egg") {
      const target = hit ? [hit.px, hit.py, hit.pz] as const : null;
      if (target) this.entities.spawnKind(def.mob!, target[0] + 0.5, target[1], target[2] + 0.5);
      if (!this.player.creative) this.consumeOne(this.selected);
      this.emit();
      return;
    }
    if (sel.key === "debug_wand") {
      const p = this.player.pos.add(this.player.lookDir().scale(3));
      this.entities.spawnKind("wisp", p.x, p.y, p.z);
      return;
    }
    if (def.kind === "flint") {
      if (!hit) return;
      const cells = tryIgnitePortal((x, y, z) => world.getBlock(x, y, z), hit.px, hit.py, hit.pz);
      const frameHit = tryIgnitePortal((x, y, z) => world.getBlock(x, y, z), hit.px, hit.py, hit.pz);
      void frameHit;
      if (cells) {
        for (const [x, y, z] of cells.cells) world.setBlock(x, y, z, BID.nether_portal);
        this.tutorial.portal = true;
        audio.play("portal", { volume: 0.7 });
        this.addMessage(`Portal lit: ${DIMENSIONS[cells.dim].name}`);
        this.damageTool(this.selected);
        return;
      }
      if (hit.id === BID.tnt) { this.primeTnt(hit.x, hit.y, hit.z, 4); this.damageTool(this.selected); return; }
      audio.play("flint");
      return;
    }
    if (!hit) return;
    const blockKey = def.blockKey ?? (def.kind === "tnt" ? "tnt" : null);
    if (!blockKey) return;
    const id = blockIdByKey(blockKey);
    if (!id) return;
    const px = hit.px, py = hit.py, pz = hit.pz;
    const target = world.getBlock(px, py, pz);
    if (!(target === 0 || isReplaceable(target))) return;
    // no placing inside the player body
    const feetY = this.player.pos.y;
    const hw = 0.3;
    if (px + 1 > this.player.pos.x - hw && px < this.player.pos.x + hw && pz + 1 > this.player.pos.z - hw && pz < this.player.pos.z + hw && py + 1 > feetY && py < feetY + this.player.height) return;
    if (blockKey === "tnt") {
      world.setBlock(px, py, pz, id);
      audio.play("place", { pos: { x: px, y: py, z: pz } });
      if (!this.player.creative) this.consumeOne(this.selected);
      return;
    }
    world.setBlock(px, py, pz, id);
    audio.play("place", { pos: { x: px, y: py, z: pz } });
    if (!this.player.creative) this.consumeOne(this.selected);
    this.tutorial.placed = true;
    if ((BLOCKS[id]?.light ?? 0) > 0) this.tutorial.light = true;
    if (BLOCKS[id]?.gravity) this.effects.settleColumn(world, px, py, pz);
    this.refreshHeld();
    this.emit();
  }

  private consumeOne(idx: number): void {
    const s = this.inv[idx];
    if (!s) return;
    s.count -= 1;
    if (s.count <= 0) this.inv[idx] = null;
  }

  private damageTool(idx: number): void {
    if (this.player.creative) return;
    const s = this.inv[idx];
    if (!s || !durabilityOf(s.key)) return;
    if (!damageStack(s, 1)) {
      this.inv[idx] = null;
      audio.play("break", { volume: 0.6 });
      this.addMessage("Your tool broke");
    }
  }

  // ---- TNT & explosions -----------------------------------------------------------
  primeTnt(x: number, y: number, z: number, fuse: number): void {
    if (!this.world) return;
    if (this.world.getBlock(x, y, z) !== BID.tnt) return;
    this.world.setBlock(x, y, z, 0);
    const mesh = MeshBuilder.CreateBox(`tnt_${this.tntId}`, { size: 0.98 }, this.scene);
    const mat = new StandardMaterial(`tntm_${this.tntId}`, this.scene);
    mat.diffuseTexture = this.mats.solid.diffuseTexture;
    mat.emissiveColor = new Color3(0.2, 0.05, 0.05);
    mesh.material = this.mats.solid;
    mesh.position.set(x + 0.5, y + 0.5, z + 0.5);
    mesh.isPickable = false;
    this.tnts.push({ x, y, z, fuse, mesh, id: this.tntId++ });
    audio.play("fuse", { pos: { x, y, z } });
  }

  private updateTnt(dt: number): void {
    const pulse = (t: TntEntity) => {
      const s = 1 + (Math.sin(t.fuse * (10 + (4 - t.fuse) * 4)) * 0.04);
      t.mesh.scaling.setAll(s);
    };
    for (const t of this.tnts) {
      t.fuse -= dt;
      pulse(t);
      if (t.fuse <= 0) {
        t.mesh.dispose();
        t.fuse = -999;
      }
    }
    const exploding = this.tnts.filter((t) => t.fuse < -100);
    this.tnts = this.tnts.filter((t) => t.fuse >= -100);
    // bounded: at most 12 chain explosions per frame; the rest are queued for the next frame
    for (const t of exploding.slice(0, 12)) this.explode(t.x + 0.5, t.y + 0.5, t.z + 0.5, 4, 3);
    if (exploding.length > 12) for (const t of exploding.slice(12)) this.tnts.push({ ...t, fuse: 0.05, mesh: t.mesh });
  }

  /** Explosion: radial ray-cast blast with per-material resistance, knockback, damage, particles and chain reactions. */
  explode(cx: number, cy: number, cz: number, radius: number, power: number): void {
    const world = this.world;
    if (!world) return;
    const r = Math.ceil(radius);
    const rays = 180;
    const destroyed = new Map<string, number>();
    const chained: [number, number, number][] = [];
    const seen = new Set<string>();
    const blastCells: [number, number, number][] = [];
    // Cast rays from the centre; each ray loses intensity as it breaks blocks.
    for (let i = 0; i < rays; i++) {
      const phi = Math.acos(1 - 2 * (i + 0.5) / rays);
      const theta = Math.PI * (1 + Math.sqrt(5)) * i;
      const dx = Math.sin(phi) * Math.cos(theta), dy = Math.cos(phi), dz = Math.sin(phi) * Math.sin(theta);
      let intensity = radius * (0.85 + Math.random() * 0.3) * (power / 3);
      let t = 0;
      let x = Math.floor(cx), y = Math.floor(cy), z = Math.floor(cz);
      while (intensity > 0 && t < radius * 1.25) {
        t += 0.3;
        const px = Math.floor(cx + dx * t), py = Math.floor(cy + dy * t), pz = Math.floor(cz + dz * t);
        if (px !== x || py !== y || pz !== z) { x = px; y = py; z = pz; }
        const id = world.getBlock(x, y, z);
        if (id === -1) break;
        if (id !== 0) {
          const def = blockDef(id);
          const key = `${x},${y},${z}`;
          if (!seen.has(key)) {
            seen.add(key);
            blastCells.push([x, y, z]);
          }
          intensity -= (def.blast + 0.3) * 0.3;
          if (def.special === "tnt" && !seen.has(`chain${key}`)) {
            seen.add(`chain${key}`);
            chained.push([x, y, z]);
          }
        }
        intensity -= 0.22;
      }
    }
    // Destroy the cells whose resistance was overcome (approximation with ray results)
    const flying: { id: number; x: number; y: number; z: number }[] = [];
    for (const [x, y, z] of blastCells) {
      const pre = world.getBlock(x, y, z);
      if (pre > 0 && !BLOCKS[pre].fluid && BLOCKS[pre].render !== "plant" && Math.hypot(x + 0.5 - cx, y + 0.5 - cy, z + 0.5 - cz) <= radius) flying.push({ id: pre, x, y, z });
    }
    this.effects.explosionDebris(new Vector3(cx, cy, cz), flying, power);
    for (const [x, y, z] of blastCells) {
      const id = world.getBlock(x, y, z);
      const dist = Math.hypot(x + 0.5 - cx, y + 0.5 - cy, z + 0.5 - cz);
      if (dist > radius) continue;
      const def = blockDef(id);
      if (def.blast >= 1000 || def.hardness < 0) continue;
      if (def.blast > 3 * power && Math.random() < 0.7) continue;
      if (def.special === "tnt") continue;
      if (world.setBlock(x, y, z, 0)) {
        destroyed.set(def.key, (destroyed.get(def.key) ?? 0) + 1);
        if (Math.random() < 0.28 && def.drop) this.entities.spawnItem(makeStack(def.drop, 1), new Vector3(x + 0.5, y + 0.5, z + 0.5));
      }
    }
    void r;
    // fluids pushed/destroyed near centre
    for (let x = -2; x <= 2; x++) for (let y = -2; y <= 2; y++) for (let z = -2; z <= 2; z++) {
      const wx = Math.floor(cx) + x, wy = Math.floor(cy) + y, wz = Math.floor(cz) + z;
      if (isFluidId(world.getBlock(wx, wy, wz)) && x * x + y * y + z * z <= 4) world.setBlock(wx, wy, wz, 0);
    }
    // unsupported sand/gravel above the crater falls in
    for (const [x, y, z] of blastCells) if (world.getBlock(x, y, z) === 0) this.effects.settleColumn(world, x, y + 1, z);
    // chain reactions with short fuses
    for (const [x, y, z] of chained) {
      const dist = Math.hypot(x - cx, y - cy, z - cz);
      if (dist < radius + 1.5) this.primeTnt(x, y, z, 0.25 + Math.random() * 0.4);
    }
    // entities & player
    this.entities.blastMobs(new Vector3(cx, cy, cz), radius * 1.6, 14 * (power / 3));
    const pp = this.player.pos.add(new Vector3(0, 0.9, 0));
    const dd = Vector3.Distance(pp, new Vector3(cx, cy, cz));
    if (dd < radius * 2) {
      const f = 1 - dd / (radius * 2);
      const dir = pp.subtract(new Vector3(cx, cy, cz)).normalize();
      this.player.vel.addInPlace(dir.scale(16 * f));
      this.player.vel.y += 6 * f;
      if (!this.player.creative) this.damagePlayer(Math.ceil(18 * f * (power / 3)), "explosion", new Vector3(cx, cy, cz));
    }
    this.shake = Math.max(this.shake, 1.2 * this.settings.screenShake);
    audio.play("explode", { pos: { x: cx, y: cy, z: cz }, pitch: 0.9 + Math.random() * 0.2, volume: 1.2 });
    this.spawnBlastVisuals(new Vector3(cx, cy, cz), radius);
    this.addMessage("BOOM");
  }

  private spawnBlastVisuals(center: Vector3, radius: number): void {
    // flash sphere
    const flash = MeshBuilder.CreateSphere("blastFlash", { diameter: radius * 2.4, segments: 12 }, this.scene);
    const m = new StandardMaterial("blastFlashMat", this.scene);
    m.emissiveColor = new Color3(1, 0.7, 0.3);
    m.disableLighting = true;
    m.alpha = 0.85;
    flash.material = m;
    flash.position.copyFrom(center);
    flash.isPickable = false;
    let life = 0.35;
    const obs = this.scene.onBeforeRenderObservable.add(() => {
      life -= this.engine.getDeltaTime() / 1000;
      const k = Math.max(0, life / 0.35);
      flash.scaling.setAll(1 + (1 - k) * 0.4);
      m.alpha = k * 0.85;
      if (life <= 0) {
        this.scene.onBeforeRenderObservable.remove(obs);
        flash.dispose();
      }
    });
    // debris & smoke particles
    if (this.settings.particles) {
      const ps = new ParticleSystem("blast", 220, this.scene);
      ps.particleTexture = new Texture(debrisTextureUrl(), this.scene);
      ps.emitter = center;
      ps.minEmitBox = new Vector3(-0.3, -0.3, -0.3);
      ps.maxEmitBox = new Vector3(0.3, 0.3, 0.3);
      ps.color1 = new Color4(1, 0.7, 0.3, 1);
      ps.color2 = new Color4(0.3, 0.3, 0.3, 1);
      ps.colorDead = new Color4(0.1, 0.1, 0.1, 0);
      ps.minSize = 0.25;
      ps.maxSize = 0.7;
      ps.minLifeTime = 0.6;
      ps.maxLifeTime = 1.4;
      ps.emitRate = 0;
      ps.manualEmitCount = 160;
      ps.direction1 = new Vector3(-1, 0.4, -1).scale(radius * 1.5);
      ps.direction2 = new Vector3(1, 1.2, 1).scale(radius * 1.5);
      ps.gravity = new Vector3(0, -9, 0);
      ps.start();
      this.particles.push(ps);
      setTimeout(() => { ps.stop(); ps.dispose(); this.particles = this.particles.filter((p) => p !== ps); }, 2200);
    }
    this.blastFlash = flash;
    void this.blastFlash;
  }

  // ---- Damage & survival ---------------------------------------------------------
  damagePlayer(amount: number, source: string, from: Vector3 | null): void {
    if (this.mode !== "world" || this.dead || this.player.creative) return;
    if (this.hurtCooldown > 0 && source !== "lava" && source !== "explosion") return;
    if (this.meta?.difficulty === "peaceful" && source !== "lava" && source !== "fall") return;
    const diff = this.meta?.difficulty === "easy" ? 0.6 : this.meta?.difficulty === "hard" ? 1.3 : 1;
    let armor = 0;
    for (let i = ARMOR_START; i < ARMOR_START + 4; i++) armor += itemDef(this.inv[i]?.key ?? "")?.armor?.defense ?? 0;
    const dmg = Math.max(1, Math.round(amount * diff * (1 - Math.min(0.8, armor * 0.04))));
    this.hp -= dmg;
    this.hurtCooldown = source === "lava" ? 0.5 : 0.5;
    this.player.hurtT = 0.4;
    this.shake = Math.max(this.shake, 0.5 * this.settings.screenShake);
    audio.play("hurt", { volume: 0.8 });
    if (from) {
      const d = this.player.pos.subtract(from);
      d.y = 0;
      const l = d.length() || 1;
      this.player.vel.addInPlace(new Vector3(d.x / l, 0, d.z / l).scale(3));
    }
    if (this.hp <= 0) this.die(source);
    this.emit();
  }

  private die(source: string): void {
    if (this.dead) return;
    this.dead = true;
    this.hp = 0;
    audio.play("death");
    // drop inventory at death position
    const pos = this.player.pos.clone();
    for (let i = 0; i < this.inv.length; i++) {
      const s = this.inv[i];
      if (s) this.entities.spawnItem(s, pos);
      this.inv[i] = null;
    }
    if (this.cursor) this.entities.spawnItem(this.cursor, pos);
    this.cursor = null;
    this.addMessage(`You died (${source})`);
    this.screen = "dead";
    if (document.pointerLockElement === this.canvas) document.exitPointerLock();
    this.emit();
  }

  private survivalTick(dt: number): void {
    if (this.player.creative) {
      this.hp = 20; this.hunger = 20; this.air = 300;
      return;
    }
    // breath
    if (this.player.feetInFluid(this.world!).head && this.player.feetInFluid(this.world!).kind === "water") this.air -= dt * 20;
    else this.air = Math.min(300, this.air + dt * 60);
    if (this.air < 0) {
      this.air = 0;
      this.damagePlayer(dt * 4, "drowning", null);
    }
    // lava
    const fl = this.player.feetInFluid(this.world!);
    if (fl.lava) this.damagePlayer(4 * dt + 0.0, "lava", null);
    // toxic/prismatic fluid stings
    if (fl.body && (fl.kind === "toxic_water" || fl.kind === "sift_water")) this.damagePlayer(2.5 * dt + 0.2, "fluid", null);
    // exhaustion & hunger
    if (this.player.sprinting && this.player.onGround) this.exhaustion += dt * 0.12;
    this.exhaustion += dt * 0.012;
    if (this.exhaustion >= 4) {
      this.exhaustion -= 4;
      if (this.saturation > 0) this.saturation = Math.max(0, this.saturation - 1);
      else this.hunger = Math.max(0, this.hunger - 1);
    }
    // regeneration
    if (this.hunger >= 18 && this.hp < 20) {
      this.regenTimer += dt;
      if (this.regenTimer > 4) { this.regenTimer = 0; this.hp = Math.min(20, this.hp + 1); this.exhaustion += 2; }
    } else if (this.hunger === 0) {
      this.starveTimer += dt;
      if (this.starveTimer > 4) { this.starveTimer = 0; this.damagePlayer(1, "starving", null); }
    }
    this.hurtCooldown = Math.max(0, this.hurtCooldown - dt);
  }

  // ---- Mining & placement per frame ---------------------------------------------------
  private updateMining(dt: number): void {
    const world = this.world!;
    if (this.screen !== "none" || this.dead || this.mode !== "world") {
      this.breakProgress = 0;
      this.clearCrack();
      this.outline.setEnabled(false);
      return;
    }
    const reach = this.player.creative ? REACH_CREATIVE : REACH_SURVIVAL;
    const hit = this.castFromEye(reach, false);
    const mob = this.mobTarget(3.2);
    const hitDist = hit ? hit.dist : Infinity;
    if (hit && !mob) {
      this.outline.setEnabled(true);
      this.outline.position.set(hit.x + 0.5, hit.y + 0.5, hit.z + 0.5);
      this.targetName = blockDef(hit.id).name;
    } else {
      this.outline.setEnabled(false);
      this.targetName = mob ? mob.def.name : "";
    }
    this.attackCd = Math.max(0, this.attackCd - dt);
    if (this.input.leftDown && this.attackCd <= 0) {
      if (mob && mob.dead === false) {
        // melee
        this.attackCd = 0.5;
        const sel = this.inv[this.selected];
        const dmg = (itemDef(sel?.key ?? "")?.tool?.damage ?? 1) * (this.player.creative ? 2 : 1);
        this.player.swingT = 1;
        this.entities.damageMob(mob, dmg, this.player.pos, 0.9);
        audio.play("hit", { volume: 0.6 });
        this.damageTool(this.selected);
        this.breakProgress = 0;
        return;
      }
    }
    if (!hit || hitDist > reach || !this.input.leftDown) {
      this.breakProgress = 0;
      this.clearCrack();
      return;
    }
    const def = blockDef(hit.id);
    if (def.hardness < 0 || def.id === 0) { this.breakProgress = 0; this.clearCrack(); return; }
    if (def.render === "none") return;
    const sameTarget = this.breakTarget && this.breakTarget.x === hit.x && this.breakTarget.y === hit.y && this.breakTarget.z === hit.z;
    if (!sameTarget) { this.breakProgress = 0; this.breakTarget = hit; }
    this.player.swingT = Math.max(this.player.swingT, 0.4);
    if (this.player.creative) {
      if (this.breakProgress >= 0.12) {
        this.breakBlock(hit, def);
        this.breakProgress = 0;
        return;
      }
      this.breakProgress += dt;
      return;
    }
    const sel = this.inv[this.selected];
    const tool = sel ? itemDef(sel.key)?.tool : undefined;
    let speed = 1;
    const correct = tool && (tool.type === def.tool || (def.tool === "hoe" && tool.type === "hoe"));
    if (correct && tool) speed = tool.speed;
    const canHarvest = !def.tool || def.tool === "none" || (correct ? (tool?.tier ?? 0) >= def.tier : def.tier === 0);
    const hardness = Math.max(0.05, def.hardness);
    const time = hardness * (canHarvest && correct ? 1.5 : 5) / speed;
    this.breakProgress += dt;
    const stage = Math.min(9, Math.floor((this.breakProgress / Math.max(0.05, time)) * 10));
    this.showCrack(hit, stage);
    if (this.breakProgress >= time) {
      this.breakBlock(hit, def, canHarvest, correct ? sel : null);
      this.breakProgress = 0;
    }
    void world;
  }

  private breakBlock(hit: RayHit, def: { key: string; drop: string | null; tool: string; tier: number; name: string; id: number; special?: string }, canHarvest = true, _tool: Slot = null): void {
    const world = this.world!;
    const id = world.getBlock(hit.x, hit.y, hit.z);
    if (id <= 0) return;
    if (!world.setBlock(hit.x, hit.y, hit.z, 0)) return;
    audio.play("break", { pos: { x: hit.x, y: hit.y, z: hit.z }, pitch: 1 });
    this.effects.blockBreak(hit.x, hit.y, hit.z, id, this.settings.particles);
    this.effects.settleColumn(world, hit.x, hit.y + 1, hit.z);
    this.tutorial.broken = true;
    if (def.special === "tnt") { this.primeTnt(hit.x, hit.y, hit.z, 0); }
    if (canHarvest && def.drop && !this.player.creative) {
      this.entities.spawnItem(makeStack(def.drop, 1), new Vector3(hit.x + 0.5, hit.y + 0.5, hit.z + 0.5));
    } else if (canHarvest && def.drop && this.player.creative) { /* creative: no drops */ }
    if (def.key.includes("ore")) this.xp += 1;
    if (!this.player.creative) this.damageTool(this.selected);
    this.clearCrack();
    this.emit();
  }

  private showCrack(hit: RayHit, stage: number): void {
    if (this.crackPos && this.crackPos[0] === hit.x && this.crackPos[1] === hit.y && this.crackPos[2] === hit.z && this.crackStage === stage && this.crack) return;
    if (!this.crack) {
      this.crack = MeshBuilder.CreateBox("crack", { size: 1.01 }, this.scene);
      this.crack.isPickable = false;
    }
    this.crack.position.set(hit.x + 0.5, hit.y + 0.5, hit.z + 0.5);
    this.crack.material = this.crackMats[stage];
    this.crackPos = [hit.x, hit.y, hit.z];
    this.crackStage = stage;
  }

  private clearCrack(): void {
    if (this.crack) { this.crack.dispose(); this.crack = null; }
    this.crackPos = null;
    this.crackStage = -1;
  }

  // ---- Furnaces --------------------------------------------------------------------
  private updateFurnaces(dt: number): void {
    for (const f of this.furnaces.values()) {
      const input = f.slots[0], fuel = f.slots[1], out = f.slots[2];
      const rec = input ? smeltFor(input.key) : undefined;
      if (f.burn > 0) f.burn = Math.max(0, f.burn - dt);
      if (!f.burn && rec && fuel && fuelTime(fuel.key) > 0 && (!out || (out.key === rec.output && out.count < maxStackOf(out.key)))) {
        f.burn = fuelTime(fuel.key);
        f.burnMax = f.burn;
        fuel.count -= 1;
        if (fuel.count <= 0) f.slots[1] = null;
      }
      if (f.burn > 0 && rec && (!out || (out.key === rec.output && out.count < maxStackOf(out.key)))) {
        f.cook += dt;
        if (f.cook >= rec.time) {
          f.cook = 0;
          input!.count -= 1;
          if (input!.count <= 0) f.slots[0] = null;
          if (!f.slots[2]) f.slots[2] = makeStack(rec.output, 1);
          else f.slots[2]!.count += 1;
        }
      } else if (!rec) f.cook = 0;
    }
  }

  // ---- Dimensions & portals -----------------------------------------------------------
  private checkPortal(dt: number): void {
    if (!this.world) return;
    if (this.portalCooldown > 0) { this.portalCooldown -= dt; return; }
    const p = this.player.pos;
    const id = this.world.getBlock(Math.floor(p.x), Math.floor(p.y + 0.9), Math.floor(p.z));
    if (id === BID.nether_portal) {
      this.portalTimer += dt;
      this.portalProgress = Math.min(1, this.portalTimer / (this.player.creative ? 0.5 : 3.5));
      if (this.portalTimer >= (this.player.creative ? 0.5 : 3.5)) {
        this.portalTimer = 0;
        const dest = portalDestination((x, y, z) => this.world!.getBlock(x, y, z), Math.floor(p.x), Math.floor(p.y + 0.9), Math.floor(p.z), this.dimDef.id);
        if (dest && dest !== this.dimDef.id) this.travel(dest);
        else this.portalCooldown = 3;
      }
    } else {
      this.portalTimer = Math.max(0, this.portalTimer - dt * 2);
      this.portalProgress = this.portalTimer / 3.5;
    }
  }

  private portalProgress = 0;

  /** Transitions to another dimension (saves current, loads target, places an arrival frame). */
  travel(to: DimId): void {
    if (!this.meta || !this.world) return;
    const from = this.dimDef.id;
    const mapped = mapCoordinates(from, to, this.player.pos.x, this.player.pos.z);
    audio.play("portal_done");
    this.saveDimPos();
    const meta = this.meta;
    this.world.dispose();
    this.world = null;
    this.entities.dispose();
    this.entities = new EntityManager(this.scene, this.makeDummyWorld(), this.makeHooks());
    this.tnts.forEach((t) => t.mesh.dispose());
    this.tnts = [];
    this.enterDimensionWorld(to, meta);
    const remembered = meta.player?.dimPos?.[to];
    const tx = remembered ? remembered.x : mapped.x;
    const tz = remembered ? remembered.z : mapped.z;
    this.pendingArrival = { dim: to, x: tx, z: tz, frame: from === "overworld" ? "obsidian" : to === "overworld" ? "obsidian" : to === "sift" ? "prism_glass" : to === "end" ? "portal_frame" : "obsidian", fromDim: from };
    this.player.vel.set(0, 0, 0);
    this.player.pos.set(tx, 200, tz);
    this.dimDef = DIMENSIONS[to];
    this.addMessage(`Entering ${DIMENSIONS[to].name}`);
    this.screen = "none";
    this.loading = { ready: 0, total: 1, text: `Entering ${DIMENSIONS[to].name}` };
    this.emit();
    void this.completeArrival();
  }

  private async completeArrival(): Promise<void> {
    const arr = this.pendingArrival;
    const w = this.world;
    if (!arr || !w) return;
    const start = performance.now();
    while (this.world === w && performance.now() - start < 20000) {
      w.update(arr.x, arr.z, 10, Math.min(this.worldRadius, 4));
      const r = w.readyAround(arr.x, arr.z, 2);
      this.loading = { ready: r.ready, total: r.total, text: `Entering ${DIMENSIONS[arr.dim].name}` };
      if (r.ready >= r.total) break;
      await new Promise((res) => setTimeout(res, 16));
    }
    if (this.world !== w) return;
    let y = -1;
    for (let yy = WORLD_HEIGHT - 4; yy > 2; yy--) {
      const id = w.getBlock(Math.floor(arr.x), yy, Math.floor(arr.z));
      if (id > 0 && isSolidId(id) && w.getBlock(Math.floor(arr.x), yy + 1, Math.floor(arr.z)) === 0 && w.getBlock(Math.floor(arr.x), yy + 2, Math.floor(arr.z)) === 0) { y = yy + 1; break; }
    }
    if (y < 0) y = this.dimDef.spawnFallbackY;
    const px = Math.floor(arr.x), pz = Math.floor(arr.z);
    if (arr.dim === "nether" || arr.dim === "sift" || arr.dim === "end") {
      this.buildArrivalFrame(px, y, pz, arr.frame ?? "obsidian");
      y = Math.max(y, y);
    }
    this.player.pos.set(arr.x + 0.5, y + 0.2, arr.z + 0.5);
    this.player.vel.set(0, 0, 0);
    this.player.fallStart = this.player.pos.y;
    this.portalCooldown = 4;
    this.pendingArrival = null;
    this.loading = null;
    this.saveDimPos();
    this.emit();
  }

  private buildArrivalFrame(x: number, y: number, z: number, frameKey: string): void {
    const w = this.world!;
    const frameId = blockIdByKey(frameKey);
    for (let dx = -1; dx <= 2; dx++) for (let dy = 0; dy <= 4; dy++) {
      const edge = dx === -1 || dx === 2 || dy === 0 || dy === 4;
      const bx = x + dx, by = y + dy, bz = z;
      if (edge) w.setBlock(bx, by, bz, frameId);
      else w.setBlock(bx, by, bz, BID.nether_portal);
    }
    // clear room for the player
    for (let dy = 1; dy <= 3; dy++) for (let dz = -1; dz <= 1; dz++) for (let dx = -1; dx <= 2; dx++) {
      if (dz !== 0 && dx >= 0 && dx <= 1 && dy >= 1) w.setBlock(x + dx, y + dy, z + dz, 0);
    }
    void findFrameInterior;
  }

  private saveDimPos(): void {
    if (!this.meta) return;
    const dimPos = { ...(this.meta.player?.dimPos ?? {}) } as PlayerSave["dimPos"];
    dimPos[this.dimDef.id] = { x: this.player.pos.x, y: this.player.pos.y, z: this.player.pos.z };
    this.meta = { ...this.meta, player: { ...(this.meta.player ?? this.defaultPlayerSave()), dimPos, dimension: this.dimDef.id } as PlayerSave };
  }

  private defaultPlayerSave(): PlayerSave {
    return { pos: { x: 0, y: 90, z: 0 }, yaw: 0, pitch: 0, hp: 20, hunger: 20, saturation: 5, xp: 0, air: 300, hotbar: 0, inventory: [], dimension: "overworld", dimPos: {}, flying: false, thirdPerson: false };
  }

  // ---- Held item ---------------------------------------------------------------------
  private refreshHeld(force = false): void {
    const s = this.inv[this.selected];
    const key = s ? s.key : "";
    if (!force && key === this.heldKey) return;
    this.heldKey = key;
    const def = s ? itemDef(s.key) : undefined;
    if (!s || !def) { this.player.setHeld("none", "", () => this.mats.solid, () => null); return; }
    if (def.kind === "block" || def.kind === "tnt") {
      this.player.setHeld("block", def.blockKey ?? def.key, () => this.mats.solid, () => null);
    } else {
      const tex = this.iconTextures.get(s.key) ?? new Texture(iconDataUrl(s.key), this.scene, false, false, Texture.NEAREST_NEAREST_MIPLINEAR);
      this.iconTextures.set(s.key, tex);
      this.player.setHeld("item", s.key, () => this.mats.solid, () => tex);
    }
  }

  // ---- Snapshot & messages --------------------------------------------------------------
  addMessage(text: string): void {
    this.messages.push({ id: this.msgId++, text, t: 6 });
    if (this.messages.length > 6) this.messages.shift();
    this.emit();
  }

  private currentSeason(): number {
    if (!this.settings.seasonsEnabled) return 1;
    const day = Math.floor(this.worldTime / (this.settings.dayLengthMinutes * 60));
    return Math.floor(day / 8) % 4;
  }

  snapshot(): Snapshot {
    const dayLen = this.settings.dayLengthMinutes * 60;
    const dayFrac = ((this.worldTime / dayLen) + 0.25) % 1;
    const hour = Math.floor(dayFrac * 24);
    const minute = Math.floor((dayFrac * 24 - hour) * 60);
    const cont = this.openContainer;
    let container: Snapshot["container"] = null;
    if (cont && (cont.kind === "chest" || cont.kind === "furnace")) {
      const f = cont.kind === "furnace" && cont.key ? this.furnaces.get(cont.key) : undefined;
      container = {
        kind: cont.kind,
        slots: cont.kind === "chest" ? cont.slots.map(cloneSlot) : (f?.slots ?? cont.slots).map(cloneSlot),
        burn: f?.burn ?? 0,
        burnMax: f?.burnMax ?? 1,
        cook: f?.cook ?? 0,
        cookMax: f && f.slots[0] ? (smeltFor(f.slots[0].key)?.time ?? 10) : 10,
      };
    }
    const armor = [0, 1, 2, 3].reduce((n, i) => n + (itemDef(this.inv[ARMOR_START + i]?.key ?? "")?.armor?.defense ?? 0), 0);
    let biome = "";
    if (this.world && this.mode === "world") biome = this.world.biomeName(Math.floor(this.player.pos.x), Math.floor(this.player.pos.z));
    return {
      ready: this.mode === "world" ? !!this.world : true,
      mode: this.mode,
      creative: this.player.creative,
      difficulty: this.meta?.difficulty ?? "normal",
      hp: Math.max(0, Math.round(this.hp * 10) / 10),
      maxHp: 20,
      hunger: Math.round(this.hunger),
      saturation: this.saturation,
      air: Math.round(this.air),
      xp: this.xp,
      level: Math.floor(Math.sqrt(this.xp)),
      armor,
      selected: this.selected,
      hotbar: this.inv.slice(0, 9).map(cloneSlot),
      inv: this.inv.map(cloneSlot),
      cursor: cloneSlot(this.cursor),
      craftGrid: this.craftGrid.map(cloneSlot),
      craftSize: this.craftSize,
      craftOut: cloneSlot(this.craftOut),
      container,
      screen: this.screen,
      dimension: this.dimDef.id,
      dimName: this.dimDef.name,
      timeText: `${String(hour).padStart(2, "0")}:${String(minute).padStart(2, "0")}`,
      dayFrac,
      season: SEASON_NAMES[this.currentSeason()],
      weather: this.weather,
      fps: this.fps,
      pos: { x: Math.round(this.player.pos.x * 10) / 10, y: Math.round(this.player.pos.y * 10) / 10, z: Math.round(this.player.pos.z * 10) / 10 },
      biome,
      messages: [...this.messages],
      dialogue: this.dialogue ? { name: this.dialogue.name, text: this.dialogue.text } : null,
      loading: this.loading,
      thirdPerson: this.player.thirdPerson,
      flying: this.player.flying,
      debug: this.debug,
      worldName: this.meta?.name ?? "",
      portalProgress: this.portalProgress,
      underwater: this.world && this.mode === "world" ? this.player.headUnderwater(this.world) : null,
      sprinting: this.player.sprinting,
      cracks: this.crackStage,
      targetName: this.targetName,
      pointerLocked: document.pointerLockElement === this.canvas,
      seedText: this.meta?.seedText ?? "",
      seed: this.meta?.seed ?? 0,
      dayNumber: Math.floor(this.worldTime / dayLen),
      hostileCount: this.entities.aliveHostiles,
      dead: this.dead,
      dimStatus: this.dimDef.status,
      hudScale: this.settings.hudScale,
      tour: this.tour ? { label: this.tour.stops[Math.min(this.tour.idx, this.tour.stops.length - 1)].label, fade: this.tour.fade, idx: this.tour.idx, total: this.tour.stops.length } : null,
      tutorial: this.meta?.type === "tutorial" ? (() => {
        const i = TUTORIAL_STEPS.findIndex((s) => !this.tutorial[s.key]);
        return i < 0
          ? { step: TUTORIAL_STEPS.length, total: TUTORIAL_STEPS.length, text: "Tutorial complete — explore, build and enjoy!", done: true }
          : { step: i, total: TUTORIAL_STEPS.length, text: TUTORIAL_STEPS[i].text, done: false };
      })() : null,
    };
  }

  private emit(): void {
    const s = this.snapshot();
    for (const l of this.listeners) l(s);
  }

  private makeHooks(): EntityHooks {
    return {
      damagePlayer: (amount, source, from) => this.damagePlayer(amount, source, from),
      explode: (pos, radius) => this.explode(pos.x, pos.y, pos.z, radius, 3),
      isPlayerSleepingOrCreative: () => this.player.creative,
      playerPos: () => this.player.pos.add(new Vector3(0, 0.9, 0)),
      playerLookingAt: (pos) => {
        const dir = this.player.lookDir();
        const to = pos.subtract(this.player.camera.position);
        const l = to.length();
        if (l < 0.01) return false;
        return Vector3.Dot(dir, to.scale(1 / l)) > 0.93;
      },
      dayFraction: () => ((this.worldTime / (this.settings.dayLengthMinutes * 60)) + 0.25) % 1,
      difficulty: () => this.meta?.difficulty ?? "normal",
      sound: (name, pos, pitch) => audio.play(name, { pos: { x: pos.x, y: pos.y, z: pos.z }, pitch, cooldown: 120 }),
      xp: (n) => { this.xp += n; audio.play("xp"); },
      iconFor: (key) => iconDataUrl(key),
      spawnDrops: (pos, key, count) => {
        for (let i = 0; i < count; i++) this.entities.spawnItem(makeStack(key, 1), pos);
      },
    };
  }

  /** Collects item entities near the player (survival). */
  private collectItems(): void {
    if (this.dead || this.mode !== "world") return;
    const pp = this.player.pos.add(new Vector3(0, 0.6, 0));
    for (const it of this.entities.items) {
      if (it.age < 0.5) continue;
      if (Vector3.Distance(it.pos, pp) > 1.3) continue;
      const rem = addToSlots(this.inv, { ...it.stack });
      if (rem) continue;
      audio.play("collect", { cooldown: 60 });
      it.stack.count = -1;
      this.emit();
    }
  }

  // ---- Frame loop -----------------------------------------------------------------------
  private frame = () => {
    const now = performance.now();
    const elapsed = now - this.lastFrame;
    const cap = this.settings.maxFps;
    if (cap > 0 && elapsed < 1000 / cap) return;
    this.lastFrame = now;
    const dt = Math.min(0.05, elapsed / 1000);
    this.fps = this.engine.getFps();
    try {
      if (this.mode === "menu") this.updatePanorama(dt);
      else this.updateWorld(dt);
    } catch (err) {
      console.error("Frame error", err);
    }
    this.scene.render();
  };

  private updatePanorama(dt: number): void {
    if (!this.world) return;
    this.panoramaAngle += dt * 0.045;
    const cx = 0, cz = 0;
    const r = 52 + Math.sin(this.panoramaAngle * 0.7) * 6;
    const px = cx + Math.cos(this.panoramaAngle) * r, pz = cz + Math.sin(this.panoramaAngle) * r;
    const py = 96 + Math.sin(this.panoramaAngle * 0.5) * 3;
    this.worldTime += dt * 14;
    this.player.camera.position.set(px, py, pz);
    this.player.camera.setTarget(new Vector3(cx, 84, cz));
    this.world.update(px, pz, 6, 4);
    this.world.setSeason(this.currentSeason());
    const pos = new Vector3(px, py, pz);
    this.env.update(dt, pos, { worldTime: this.worldTime, dayLengthSec: this.settings.dayLengthMinutes * 60, weather: "clear", season: 1, sky: DIMENSIONS.overworld.sky }, ((this.worldTime / (this.settings.dayLengthMinutes * 60)) + 0.25) % 1);
    this.updateReflections(px, pz);
    setPortalTime(this.mats, performance.now() / 1000);
  }

  private updateWorld(dt: number): void {
    if (!this.world || !this.meta) return;
    const world = this.world;
    if (this.tour) { this.updateTour(dt); return; }
    const inMenuScreen = this.screen !== "none";
    if (this.dead) this.input.keys.clear();
    // time & weather
    if (!this.paused) this.worldTime += dt;
    const dayLen = this.settings.dayLengthMinutes * 60;
    const dayNum = Math.floor(this.worldTime / dayLen);
    if (dayNum !== this.lastDayNum) { this.lastDayNum = dayNum; this.addMessage(`Day ${dayNum + 1} · ${SEASON_NAMES[this.currentSeason()]}`); }
    this.seasonIdx = this.currentSeason();
    world.setSeason(this.seasonIdx);
    this.weatherTimer -= dt;
    if (this.weatherTimer <= 0 && this.settings.weatherEnabled && this.dimDef.sky.weatherAllowed) {
      this.weatherTimer = 150 + Math.random() * 240;
      const roll = Math.random();
      const seasonalSnow = this.seasonIdx === 3;
      this.weather = roll < 0.55 ? "clear" : roll < 0.8 ? (seasonalSnow ? "snow" : "rain") : roll < 0.94 ? "rain" : (seasonalSnow ? "snow" : "thunder");
      this.emit();
    } else if (!this.settings.weatherEnabled || !this.dimDef.sky.weatherAllowed) this.weather = "clear";
    if (this.weather !== "clear" && this.weatherTimer > 0 && this.weatherTimer < 2) { /* fade handled by env */ }
    if (this.weather !== "clear" && Math.random() < dt * 0.02) { this.weather = "clear"; }

    // input-driven look & physics
    if (!inMenuScreen && !this.dead) this.player.applyLook(this.input, this.settings.sensitivity, this.settings.invertY);
    else { this.input.mouseDX = 0; this.input.mouseDY = 0; }
    if (!this.dead && !this.pendingArrival) {
      const ev = this.player.step(dt, world, this.input, { survival: !this.player.creative });
      if (ev.jumped) audio.play("jump", { cooldown: 100 });
      if (ev.landedFall > 0 && !this.player.creative) this.damagePlayer(Math.floor(ev.landedFall - 3) + 1, "fall", null);
      if (ev.landedFall > 3) audio.play("land", { volume: 0.7 });
      if (ev.stepped) {
        const k = ev.landedSurfaceKey ?? "";
        const sound = /sand|red_sand/.test(k) ? "step_sand" : /stone|cobble|granite|deepslate|brick|obsidian|basalt|netherrack/.test(k) ? "step_stone" : /wood|planks|log|chest|crafting/.test(k) ? "step_wood" : /snow|ice/.test(k) ? "step_snow" : "step_grass";
        audio.play(sound, { cooldown: 60, volume: this.player.sprinting ? 0.9 : 0.6 });
      }
      if (ev.inWater && !this.player.feetInFluid(world).head && Math.random() < dt * 0.4) audio.play("splash", { volume: 0.25, cooldown: 300 });
    } else if (this.pendingArrival) {
      this.player.vel.set(0, 0, 0);
    }
    if (this.player.thirdPerson && this.screen !== "none") { /* camera stays */ }
    this.player.updateCamera(dt, this.settings.fov, this.player.bobbing, this.shake);
    this.shake = Math.max(0, this.shake - dt * 2.4);
    audio.setListener(this.player.camera.position.x, this.player.camera.position.y, this.player.camera.position.z, this.player.yaw);

    // world streaming & meshing
    world.update(this.player.pos.x, this.player.pos.z, this.screen === "none" ? 7 : 9, this.settings.renderDistance);
    if (this.loading && this.loading.text.startsWith("Preparing")) this.loading = null;

    // mining/placing
    this.placeCd = Math.max(0, this.placeCd - dt);
    this.useCd = Math.max(0, this.useCd - dt);
    if (this.input.rightDown && this.screen === "none") { if (this.placeCd <= 0) this.onUseClick(); }
    this.updateMining(dt);

    // simulation
    this.entities.update(dt, this.worldTime, this.meta.difficulty === "peaceful");
    this.updateTnt(dt);
    this.updateFurnaces(dt);
    this.collectItems();
    if (!this.dead) this.survivalTick(dt);
    this.checkPortal(dt);

    // environment
    const env = this.env;
    const timeFrac = ((this.worldTime / dayLen) + 0.25) % 1;
    const dimSky = this.dimDef.sky;
    env.update(dt, this.player.camera.position, { worldTime: this.worldTime, dayLengthSec: dayLen, weather: this.weather, season: this.seasonIdx, sky: dimSky }, timeFrac);
    const uw = this.player.headUnderwater(world);
    env.setUnderwater(uw);
    setWetness(this.mats, dimSky.kind === "overworld" ? env.wetFactor : 0, this.scene.fogColor);
    this.effects.update(dt, world, this.player.pos, env.wetFactor, (v) => { this.shake = Math.max(this.shake, v * this.settings.screenShake); });
    {
      const px = Math.floor(this.player.pos.x), pz = Math.floor(this.player.pos.z);
      const surf = world.surfaceY(px, pz);
      const underground = surf > 0 && this.player.pos.y < surf - 6;
      audio.ambientTick(dt, {
        biome: world.biomeAt(px, pz), day: env.dayFactor, underground, ocean: this.nearWaterFactor(),
        rain: this.weather === "rain" || this.weather === "thunder", dimension: this.dimDef.id, underwater: !!uw,
      });
    }
    // rare volcano eruptions (only near a volcano, roughly every 4-9 minutes)
    this.eruptionTimer -= dt;
    if (this.eruptionTimer <= 0) {
      this.eruptionTimer = 240 + Math.random() * 300;
      const vs = volcanoesNear(world.params, this.player.pos.x, this.player.pos.z, 220);
      if (vs.length) {
        const v = vs[0];
        this.effects.eruption(v.x, v.y, v.z, this.settings.particles);
        this.addMessage("The ground trembles... a volcano is erupting!");
      }
    }
    // tutorial movement tracking
    if (this.meta.type === "tutorial") {
      this.tutorialMoved += Math.hypot(this.player.vel.x, this.player.vel.z) * dt;
      if (this.tutorialMoved > 8) this.tutorial.moved = true;
    }
    env.shadowGen.getShadowMap()!.renderList = env.shadowGen.getShadowMap()!.renderList ?? [];
    this.shadowTick -= dt;
    if (this.shadowTick <= 0) {
      this.shadowTick = 0.5;
      const casters = world.collectMeshes(this.player.pos.x, this.player.pos.z, 3, (b) => b === "solid" || b === "emissive" || b === "cutout");
      env.setShadowCasters(casters as never);
    }
    this.env.shadowGen.getShadowMap()!.refreshRate = 1;
    if (this.env.sun.position) this.env.sun.position.addInPlace(new Vector3(0, 0, 0));
    this.updateReflections(this.player.pos.x, this.player.pos.z);
    setPortalTime(this.mats, performance.now() / 1000);
    audio.updateAmbience(this.weather, this.player.feetInFluid(world).body ? 1 : this.nearWaterFactor(), this.weather === "thunder" ? 1 : this.weather === "rain" ? 0.6 : 0.3, this.dimDef.id, this.weather === "rain" || this.weather === "thunder");
    audio.tickMusic(dt, timeFrac, this.settings.volumeMusic > 0 && this.screen === "none");

    // messages & dialogue timers
    for (const m of this.messages) m.t -= dt;
    while (this.messages.length && this.messages[0].t <= 0) this.messages.shift();
    if (this.dialogue) { this.dialogue.t -= dt; }

    // autosave
    this.autosaveTimer -= dt;
    if (this.autosaveTimer <= 0 && !this.dead) {
      this.autosaveTimer = 45;
      void this.saveNow();
    }

    // snapshot throttle
    this.snapTimer -= dt;
    if (this.snapTimer <= 0) {
      this.snapTimer = 0.1;
      this.emit();
    }
    // HUD speed info
    this.reflectionTick++;
  }

  /** Starts the cinematic World Tour (overworld only). Esc ends it early. */
  startTour(): void {
    if (!this.world || !this.meta || this.mode !== "world") return;
    if (this.dimDef.id !== "overworld") { this.addMessage("The World Tour is only available in the Overworld"); return; }
    const stops = tourStops(this.world.params, 10);
    if (stops.length === 0) return;
    if (document.pointerLockElement === this.canvas) document.exitPointerLock();
    const p = this.player.pos;
    this.tour = { stops, idx: 0, t: 0, fade: 1, waiting: true, saved: { x: p.x, y: p.y, z: p.z, yaw: this.player.yaw, pitch: this.player.pitch } };
    this.tutorial.tour = true;
    this.screen = "none";
    this.player.fpArm.root.setEnabled(false);
    this.emit();
  }

  stopTour(): void {
    if (!this.tour) return;
    const s = this.tour.saved;
    this.tour = null;
    this.player.pos.set(s.x, s.y, s.z);
    this.player.yaw = s.yaw;
    this.player.pitch = s.pitch;
    this.player.vel.set(0, 0, 0);
    this.player.fallStart = s.y;
    this.screen = "pause";
    this.emit();
  }

  private updateTour(dt: number): void {
    const tour = this.tour!;
    const world = this.world!;
    const stop = tour.stops[tour.idx];
    tour.t += dt;
    const DUR = 10;
    const cam = this.player.camera;
    const ang = tour.idx * 1.7 + tour.t * 0.11;
    const r = 36;
    const cx = stop.x + Math.cos(ang) * r, cz = stop.z + Math.sin(ang) * r;
    const cy = Math.max(stop.y, 64) + 24 + Math.sin(tour.t * 0.3) * 3;
    world.update(stop.x, stop.z, 10, Math.min(this.settings.renderDistance, 6));
    if (tour.waiting) {
      tour.fade = 1;
      const rr = world.readyAround(stop.x, stop.z, 2);
      if (rr.ready >= rr.total * 0.8 || tour.t > 10) { tour.waiting = false; tour.t = 0; }
    } else {
      tour.fade = tour.t < 1 ? 1 - tour.t : tour.t > DUR - 1 ? tour.t - (DUR - 1) : 0;
      if (tour.t >= DUR) {
        tour.idx++;
        tour.t = 0;
        tour.waiting = true;
        if (tour.idx >= tour.stops.length) { this.stopTour(); return; }
      }
    }
    cam.position.set(cx, cy, cz);
    cam.setTarget(new Vector3(stop.x, Math.max(stop.y, 63) + 4, stop.z));
    this.player.pos.set(stop.x, Math.max(stop.y, 64) + 40, stop.z); // keeps streaming centred and the player safe
    this.player.vel.set(0, 0, 0);
    this.worldTime += dt * 6;
    const dayLen = this.settings.dayLengthMinutes * 60;
    const timeFrac = ((this.worldTime / dayLen) + 0.25) % 1;
    this.env.setUnderwater(null);
    this.env.update(dt, cam.position, { worldTime: this.worldTime, dayLengthSec: dayLen, weather: this.weather, season: this.seasonIdx, sky: this.dimDef.sky }, timeFrac);
    this.effects.update(dt, world, cam.position, this.env.wetFactor, () => undefined);
    setPortalTime(this.mats, performance.now() / 1000);
    this.updateReflections(stop.x, stop.z);
    this.snapTimer -= dt;
    if (this.snapTimer <= 0) { this.snapTimer = 0.1; this.emit(); }
  }

  private giveTutorialKit(): void {
    const kit: [string, number][] = [
      ["stone_pickaxe", 1], ["stone_axe", 1], ["flint_steel", 1], ["torch", 32], ["oak_planks", 64],
      ["lamp_red", 16], ["lamp_blue", 16], ["lamp_green", 16], ["lamp_gold", 16], ["tnt", 6], ["bread", 12], ["glass", 32],
    ];
    for (const [k, n] of kit) addToSlots(this.inv, makeStack(k, n));
  }

  private nearWaterFactor(): number {
    const p = this.player.pos;
    let n = 0;
    for (const [dx, dz] of [[3, 0], [-3, 0], [0, 3], [0, -3]]) {
      const id = this.world?.getBlock(Math.floor(p.x + dx), Math.floor(p.y), Math.floor(p.z + dz)) ?? 0;
      if (isFluidId(id)) n++;
    }
    return n / 4;
  }

  private updateReflections(x: number, z: number): void {
    const refl = this.mats.water.reflectionTexture;
    if (!refl) return;
    this.reflectionTick = (this.reflectionTick + 1) % 20;
    if (this.reflectionTick === 0 && this.world) {
      const list = this.world.collectMeshes(x, z, 4, (b) => b === "solid" || b === "emissive" || b === "cutout" || b === "glass");
      list.push(this.env.sky as unknown as Mesh);
      list.push(this.env.clouds as unknown as Mesh);
      refl.renderList = this.settings.waterReflections && this.settings.waterQuality > 0 ? (list as never) : [];
      const refr = this.mats.water.refractionTexture;
      if (refr) refr.renderList = this.settings.waterQuality >= 2 ? (list as never) : [];
    }
  }

  /** Waits for world meshes to exist (used by UI for the loading dots). */
  loadingProgress(): { ready: number; total: number } {
    if (!this.world || !this.meta) return { ready: 0, total: 1 };
    const p = this.player.pos;
    return this.world.readyAround(p.x, p.z, 3);
  }

  dispose(): void {
    window.removeEventListener("resize", this.onResize);
    window.removeEventListener("keydown", this.onKeyDown);
    window.removeEventListener("keyup", this.onKeyUp);
    this.engine.stopRenderLoop();
    this.world?.dispose();
    this.entities.dispose();
    this.env.dispose();
    this.engine.dispose();
    this.running = false;
  }
}

function canMerge(a: ItemStack, b: ItemStack): boolean {
  return a.key === b.key && (a.damage ?? 0) === (b.damage ?? 0);
}

function canFitInInventory(inv: Slot[], s: ItemStack): boolean {
  const max = maxStackOf(s.key);
  let room = 0;
  for (const sl of inv.slice(0, 36)) {
    if (!sl) room += max;
    else if (sl.key === s.key) room += max - sl.count;
  }
  return room >= s.count;
}

function debrisTextureUrl(): string {
  const c = document.createElement("canvas");
  c.width = 8; c.height = 8;
  const g = c.getContext("2d")!;
  const grd = g.createRadialGradient(4, 4, 0, 4, 4, 4);
  grd.addColorStop(0, "rgba(255,255,255,1)");
  grd.addColorStop(1, "rgba(255,255,255,0)");
  g.fillStyle = grd;
  g.fillRect(0, 0, 8, 8);
  return c.toDataURL("image/png");
}

export { CHUNK_SIZE, ITEM_BY_KEY, CREATIVE_TABS, ITEMS, itemName, MOBS, Material, Color3, Vector4, Recipe, ItemDef, removeItem, countItem, newSlots, shiftMove, clickSlot, type Mob };
export { isReplaceable };
