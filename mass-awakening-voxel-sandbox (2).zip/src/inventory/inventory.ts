// Stack and slot operations shared by the player inventory, containers, crafting and creative UI.

import { itemDef, maxStackOf, durabilityOf } from "../items/items";

export interface ItemStack {
  key: string;
  count: number;
  damage?: number; // durability used
}

export type Slot = ItemStack | null;

export function makeStack(key: string, count = 1, damage?: number): ItemStack {
  return damage ? { key, count, damage } : { key, count };
}

export function cloneSlot(s: Slot): Slot {
  return s ? { ...s } : null;
}

export function canStackTogether(a: ItemStack, b: ItemStack): boolean {
  return a.key === b.key && (a.damage ?? 0) === (b.damage ?? 0);
}

/** Adds as much of `stack` into the given slot index range; returns the remainder (or null). */
export function addToSlots(slots: Slot[], stack: ItemStack, start = 0, end = slots.length - 1): ItemStack | null {
  let remaining = stack.count;
  const max = maxStackOf(stack.key);
  // merge into existing stacks first
  for (let i = start; i <= end && remaining > 0; i++) {
    const s = slots[i];
    if (s && canStackTogether(s, stack) && s.count < max) {
      const add = Math.min(max - s.count, remaining);
      s.count += add;
      remaining -= add;
    }
  }
  for (let i = start; i <= end && remaining > 0; i++) {
    if (!slots[i]) {
      const add = Math.min(max, remaining);
      slots[i] = makeStack(stack.key, add, stack.damage);
      remaining -= add;
    }
  }
  return remaining > 0 ? makeStack(stack.key, remaining, stack.damage) : null;
}

export function countItem(slots: Slot[], key: string): number {
  let n = 0;
  for (const s of slots) if (s && s.key === key) n += s.count;
  return n;
}

export function removeItem(slots: Slot[], key: string, count: number): number {
  let left = count;
  for (let i = 0; i < slots.length && left > 0; i++) {
    const s = slots[i];
    if (!s || s.key !== key) continue;
    const take = Math.min(s.count, left);
    s.count -= take;
    left -= take;
    if (s.count <= 0) slots[i] = null;
  }
  return count - left;
}

export interface CursorRef {
  cursor: Slot;
}

/** Standard click semantics: left = pick/place/swap/merge, right = half-pick/place-one. */
export function clickSlot(ctx: CursorRef, slots: Slot[], idx: number, button: 0 | 2, accept?: (s: ItemStack) => boolean): void {
  const slot = slots[idx];
  const cur = ctx.cursor;
  if (cur && accept && !accept(cur)) return;
  if (button === 0) {
    if (!cur) {
      ctx.cursor = slot;
      slots[idx] = null;
    } else if (!slot) {
      slots[idx] = cur;
      ctx.cursor = null;
    } else if (canStackTogether(slot, cur)) {
      const max = maxStackOf(slot.key);
      const room = max - slot.count;
      const move = Math.min(room, cur.count);
      slot.count += move;
      cur.count -= move;
      if (cur.count <= 0) ctx.cursor = null;
    } else {
      slots[idx] = cur;
      ctx.cursor = slot;
    }
    return;
  }
  // right click
  if (!cur) {
    if (slot) {
      const half = Math.ceil(slot.count / 2);
      ctx.cursor = { ...slot, count: half };
      slot.count -= half;
      if (slot.count <= 0) slots[idx] = null;
    }
  } else if (!slot) {
    if (!accept || accept(cur)) {
      slots[idx] = { ...cur, count: 1 };
      cur.count -= 1;
      if (cur.count <= 0) ctx.cursor = null;
    }
  } else if (canStackTogether(slot, cur) && slot.count < maxStackOf(slot.key)) {
    slot.count += 1;
    cur.count -= 1;
    if (cur.count <= 0) ctx.cursor = null;
  }
}

/** Moves the whole stack at `from` into the first sensible target section (shift-click). */
export function shiftMove(from: Slot[], idx: number, targets: { slots: Slot[]; start?: number; end?: number; accept?: (s: ItemStack) => boolean }[]): boolean {
  const s = from[idx];
  if (!s) return false;
  for (const t of targets) {
    if (t.accept && !t.accept(s)) continue;
    const rem = addToSlots(t.slots, { ...s }, t.start ?? 0, t.end ?? t.slots.length - 1);
    if (!rem || rem.count !== s.count) {
      from[idx] = rem && rem.count > 0 ? { ...s, count: rem.count } : null;
      return true;
    }
  }
  return false;
}

/** Applies durability damage to a stack; returns false when it broke (count goes to 0). */
export function damageStack(s: ItemStack, amount: number): boolean {
  const max = durabilityOf(s.key);
  if (!max) return true;
  s.damage = (s.damage ?? 0) + amount;
  if (s.damage >= max) {
    s.count = 0;
    return false;
  }
  return true;
}

export function durabilityFraction(s: ItemStack): number {
  const max = durabilityOf(s.key);
  if (!max) return 1;
  return 1 - (s.damage ?? 0) / max;
}

export function isTool(key: string): boolean {
  return itemDef(key)?.kind === "tool";
}

export function armorSlotOf(key: string): "head" | "chest" | "legs" | "feet" | null {
  const d = itemDef(key);
  return d?.armor ? d.armor.slot : null;
}

/** Simple player inventory layout: 0-8 hotbar, 9-35 main, 36-39 armor, 40 offhand. */
export const HOTBAR_START = 0;
export const MAIN_START = 9;
export const ARMOR_START = 36;
export const OFFHAND_INDEX = 40;
export const PLAYER_SLOTS = 41;

export function newSlots(n: number): Slot[] {
  return new Array<Slot>(n).fill(null);
}
