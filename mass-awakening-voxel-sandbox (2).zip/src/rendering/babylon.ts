// Single import shim for Babylon.js. Every module imports Babylon from here (never from the "@babylonjs/core"
// barrel) so the bundle only contains what the game uses. The barrel import blew the build's memory limit.

export { Engine } from "@babylonjs/core/Engines/engine";
export { Scene } from "@babylonjs/core/scene";
export { Vector2, Vector3, Vector4, Matrix } from "@babylonjs/core/Maths/math.vector";
export { Color3, Color4 } from "@babylonjs/core/Maths/math.color";
export { Mesh } from "@babylonjs/core/Meshes/mesh";
export { AbstractMesh } from "@babylonjs/core/Meshes/abstractMesh";
export { InstancedMesh } from "@babylonjs/core/Meshes/instancedMesh";
export { MeshBuilder } from "@babylonjs/core/Meshes/meshBuilder";
export { VertexData } from "@babylonjs/core/Meshes/mesh.vertexData";
export { TransformNode } from "@babylonjs/core/Meshes/transformNode";
export { Material } from "@babylonjs/core/Materials/material";
export { StandardMaterial } from "@babylonjs/core/Materials/standardMaterial";
export { ShaderMaterial } from "@babylonjs/core/Materials/shaderMaterial";
export { Effect } from "@babylonjs/core/Materials/effect";
export { Texture } from "@babylonjs/core/Materials/Textures/texture";
export { ImageProcessingConfiguration } from "@babylonjs/core/Materials/imageProcessingConfiguration";
export { DirectionalLight } from "@babylonjs/core/Lights/directionalLight";
export { HemisphericLight } from "@babylonjs/core/Lights/hemisphericLight";
export { PointLight } from "@babylonjs/core/Lights/pointLight";
export { ShadowGenerator } from "@babylonjs/core/Lights/Shadows/shadowGenerator";
export { CascadedShadowGenerator } from "@babylonjs/core/Lights/Shadows/cascadedShadowGenerator";
export { FreeCamera } from "@babylonjs/core/Cameras/freeCamera";
export { ParticleSystem } from "@babylonjs/core/Particles/particleSystem";
export { DefaultRenderingPipeline } from "@babylonjs/core/PostProcesses/RenderPipeline/Pipelines/defaultRenderingPipeline";
export { SSAO2RenderingPipeline } from "@babylonjs/core/PostProcesses/RenderPipeline/Pipelines/ssao2RenderingPipeline";
export { WaterMaterial } from "@babylonjs/materials/water/waterMaterial";

// side-effect registrations (scene components)
import "@babylonjs/core/Lights/Shadows/shadowGeneratorSceneComponent";
import "@babylonjs/core/PostProcesses/RenderPipeline/postProcessRenderPipelineManagerSceneComponent";
import "@babylonjs/core/Rendering/edgesRenderer";
