// Environment: day/night cycle, visible sun & moon discs, sky dome (gradient, sun shafts, smooth stars, aurora,
// rainbow), cloud layer, world-space god-ray beams, cascaded shadows, tone-mapped post pipeline, rain/snow,
// lightning (with a callback for synced thunder), linear distance fog and underwater fog.

import {
  Color3, Color4, DefaultRenderingPipeline, DirectionalLight, Effect, Engine, HemisphericLight, ImageProcessingConfiguration,
  Mesh, MeshBuilder, ParticleSystem, Scene, ShaderMaterial, ShadowGenerator, CascadedShadowGenerator, SSAO2RenderingPipeline,
  StandardMaterial, Texture, Vector3, FreeCamera, Vector2,
} from "./babylon";
import type { SkyPreset } from "../dimensions/dimensions";
import type { Settings } from "../core/settings";
import { smoothstep, clamp } from "../world/noise";

export type Weather = "clear" | "rain" | "thunder" | "snow";

export interface EnvState {
  worldTime: number;
  dayLengthSec: number;
  weather: Weather;
  season: number;
  sky: SkyPreset;
}

const SKY_VS = `
precision highp float;
attribute vec3 position;
uniform mat4 worldViewProjection;
varying vec3 vDir;
void main(void) {
  vDir = position;
  gl_Position = worldViewProjection * vec4(position, 1.0);
}`;

const SKY_FS = `
precision highp float;
varying vec3 vDir;
uniform vec3 uSunDir;
uniform vec3 uZenith;
uniform vec3 uHorizon;
uniform vec3 uSunColor;
uniform float uStars;
uniform float uAurora;
uniform float uRainbow;
uniform float uTime;
uniform float uSunVis;
uniform float uDark;
uniform float uShafts;
uniform vec3 uAur1;
uniform vec3 uAur2;
float hash(vec3 p) { p = fract(p * 0.3183099 + 0.1); p *= 17.0; return fract(p.x * p.y * p.z * (p.x + p.y + p.z)); }
float h1(float x) { return fract(sin(x * 127.1) * 43758.5453); }
float vn(float x) { float i = floor(x); float f = fract(x); f = f * f * (3.0 - 2.0 * f); return mix(h1(i), h1(i + 1.0), f); }
void main(void) {
  vec3 d = normalize(vDir);
  float up = clamp(d.y, 0.0, 1.0);
  vec3 col = mix(uHorizon, uZenith, pow(up, 0.45));
  col = mix(col, uHorizon * 0.5, smoothstep(0.0, -0.3, d.y));
  float sd = max(dot(d, uSunDir), 0.0);
  // atmospheric glow around the sun (strong at low sun)
  col += uSunColor * (pow(sd, 5.0) * 0.35 + pow(sd, 48.0) * 0.6) * uSunVis;
  // sun shafts: angular streaks radiating from the sun, broken up by slow noise
  if (uShafts > 0.0 && sd > 0.6) {
    vec3 t1 = normalize(cross(uSunDir, vec3(0.0, 1.0, 0.0001)));
    vec3 t2 = cross(uSunDir, t1);
    float ang = atan(dot(d, t2), dot(d, t1));
    float rays = vn(ang * 14.0 + uTime * 0.05) * vn(ang * 31.0 - uTime * 0.03);
    col += uSunColor * pow(rays, 2.0) * smoothstep(0.6, 0.99, sd) * uShafts * 0.55 * uSunVis;
  }
  // smooth, non-shimmering stars: soft dots at cell centres
  if (d.y > -0.05 && uStars > 0.0) {
    vec3 g = d * 180.0;
    vec3 c = floor(g);
    float r = hash(c);
    if (r > 0.985) {
      vec3 centre = c + 0.5 + (vec3(hash(c + 1.3), hash(c + 2.7), hash(c + 4.1)) - 0.5) * 0.6;
      float dist = length(g - centre);
      float tw = 0.7 + 0.3 * sin(uTime * 1.7 + r * 60.0);
      float s = smoothstep(0.42, 0.0, dist) * tw * smoothstep(-0.05, 0.25, d.y) * (r - 0.985) * 66.0;
      col += vec3(0.95, 0.97, 1.0) * s * uStars;
    }
  }
  if (uAurora > 0.0 && d.y > 0.02) {
    float az = atan(d.z, d.x);
    float wave = sin(az * 3.0 + uTime * 0.12) * 0.5 + sin(az * 7.0 - uTime * 0.21) * 0.25;
    float band = exp(-pow((d.y - 0.42 - wave * 0.1) * 5.5, 2.0));
    float rip = 0.5 + 0.5 * sin(az * 42.0 + uTime * 1.4 + d.y * 26.0);
    float curt = 0.6 + 0.4 * sin(az * 13.0 - uTime * 0.6 + sin(az * 4.0 + uTime * 0.3) * 2.0);
    vec3 aur = mix(uAur1, uAur2, 0.5 + 0.5 * sin(az * 2.0 + uTime * 0.25));
    col += aur * band * (0.45 + 0.55 * rip) * curt * uAurora * 1.1;
  }
  if (uRainbow > 0.0) {
    float ang = acos(clamp(dot(d, -uSunDir), -1.0, 1.0));
    float t = (ang - 0.68) / 0.09;
    float inBand = smoothstep(0.0, 0.15, t) * smoothstep(1.0, 0.75, t);
    vec3 spec = 0.5 + 0.5 * cos(6.2831 * (vec3(0.0, 0.33, 0.67) + t * 0.85));
    col += spec * inBand * uRainbow * 0.5 * smoothstep(-0.05, 0.25, d.y);
  }
  col *= uDark;
  gl_FragColor = vec4(col, 1.0);
}`;

const CLOUD_VS = `
precision highp float;
attribute vec3 position;
uniform mat4 worldViewProjection;
uniform mat4 world;
varying vec3 vWorld;
void main(void) {
  vWorld = (world * vec4(position, 1.0)).xyz;
  gl_Position = worldViewProjection * vec4(position, 1.0);
}`;

const CLOUD_FS = `
precision highp float;
varying vec3 vWorld;
uniform vec3 uSunDir;
uniform vec3 uCam;
uniform float uTime;
uniform float uCover;
uniform vec3 uSunCol;
uniform vec3 uAmb;
uniform float uDark;
uniform vec2 uWind;
float h(vec2 p) { return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453); }
float n(vec2 p) {
  vec2 i = floor(p); vec2 f = fract(p);
  f = f * f * (3.0 - 2.0 * f);
  return mix(mix(h(i), h(i + vec2(1.0, 0.0)), f.x), mix(h(i + vec2(0.0, 1.0)), h(i + vec2(1.0, 1.0)), f.x), f.y);
}
float fbm(vec2 p) {
  float v = 0.0; float a = 0.5;
  for (int i = 0; i < 5; i++) { v += a * n(p); p = p * 2.03 + vec2(1.7, 9.2); a *= 0.5; }
  return v;
}
float density(vec2 xz) {
  vec2 q = xz * 0.0045 + uWind * uTime * 0.01;
  vec2 warp = vec2(fbm(q * 0.6 + 3.1), fbm(q * 0.6 + 7.7));
  float base = fbm(q + warp * 0.9);
  return clamp((base - (1.0 - uCover)) * 3.0, 0.0, 1.0);
}
void main(void) {
  float dens = density(vWorld.xz);
  float shade = density(vWorld.xz + uSunDir.xz * 24.0) + density(vWorld.xz + uSunDir.xz * 48.0) * 0.6;
  float lit = exp(-shade * 1.2);
  vec3 cl = mix(uAmb * 0.55, uSunCol * 1.1 + uAmb * 0.3, lit);
  cl += pow(1.0 - dens, 2.0) * uSunCol * 0.35 * lit;
  float fade = 1.0 - smoothstep(600.0, 1500.0, length(vWorld.xz - uCam.xz));
  float a = smoothstep(0.0, 0.35, dens) * 0.92 * fade;
  gl_FragColor = vec4(cl * uDark, a);
}`;

// Light-shaft beam: soft tapered gradient with slow flicker, additive.
const BEAM_VS = `
precision highp float;
attribute vec3 position;
attribute vec2 uv;
uniform mat4 worldViewProjection;
varying vec2 vUV;
void main(void) { vUV = uv; gl_Position = worldViewProjection * vec4(position, 1.0); }`;

const BEAM_FS = `
precision highp float;
varying vec2 vUV;
uniform vec3 uColor;
uniform float uAlpha;
uniform float uTime;
uniform float uSeed;
void main(void) {
  float across = 1.0 - abs(vUV.x - 0.5) * 2.0;
  float soft = smoothstep(0.0, 1.0, across);
  float along = smoothstep(0.0, 0.25, vUV.y) * smoothstep(1.0, 0.55, vUV.y);
  float flicker = 0.75 + 0.25 * sin(uTime * 0.6 + uSeed * 7.0 + vUV.y * 3.0);
  gl_FragColor = vec4(uColor * soft * along * flicker * uAlpha, 1.0);
}`;

function c3(c: [number, number, number]): Color3 {
  return new Color3(c[0], c[1], c[2]);
}

function lerp3(a: [number, number, number], b: [number, number, number], t: number): [number, number, number] {
  return [a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t, a[2] + (b[2] - a[2]) * t];
}

function glowTexture(scene: Scene, inner: string, outer: string, core = 0.18): Texture {
  const c = document.createElement("canvas");
  c.width = 128;
  c.height = 128;
  const g = c.getContext("2d")!;
  const grd = g.createRadialGradient(64, 64, 0, 64, 64, 64);
  grd.addColorStop(0, inner);
  grd.addColorStop(core, inner);
  grd.addColorStop(core + 0.04, outer);
  grd.addColorStop(1, "rgba(0,0,0,0)");
  g.fillStyle = grd;
  g.fillRect(0, 0, 128, 128);
  const t = new Texture(c.toDataURL("image/png"), scene);
  t.hasAlpha = true;
  return t;
}

function streakTexture(scene: Scene): Texture {
  const c = document.createElement("canvas");
  c.width = 4;
  c.height = 32;
  const g = c.getContext("2d")!;
  const grd = g.createLinearGradient(0, 0, 0, 32);
  grd.addColorStop(0, "rgba(255,255,255,0)");
  grd.addColorStop(0.5, "rgba(220,235,255,0.75)");
  grd.addColorStop(1, "rgba(255,255,255,0)");
  g.fillStyle = grd;
  g.fillRect(1, 0, 2, 32);
  return new Texture(c.toDataURL("image/png"), scene);
}

export class Environment {
  readonly sun: DirectionalLight;
  readonly moon: DirectionalLight;
  readonly hemi: HemisphericLight;
  readonly sky: Mesh;
  readonly clouds: Mesh;
  readonly sunMesh: Mesh;
  readonly moonMesh: Mesh;
  readonly pipeline: DefaultRenderingPipeline;
  shadowGen: ShadowGenerator;
  readonly emitter: Mesh;
  onLightning: ((pos: Vector3, distance: number) => void) | null = null;
  private scene: Scene;
  private camera: FreeCamera;
  private skyMat: ShaderMaterial;
  private cloudMat: ShaderMaterial;
  private beams: { mesh: Mesh; mat: ShaderMaterial; ox: number; oz: number; seed: number }[] = [];
  private ssao: SSAO2RenderingPipeline | null = null;
  private rain: ParticleSystem;
  private snow: ParticleSystem;
  private lightning = 0;
  private nextBolt = 6;
  private bolt: Mesh | null = null;
  private boltAge = 0;
  private cloudCover = 0.5;
  private weatherCurrent: Weather = "clear";
  private wetness = 0;
  private sunDirV = new Vector3(0, 1, 0);
  private dayness = 1;
  private settings: Settings;
  private underwater: string | null = null;
  private renderDistance = 8;
  sunElevation = 0;

  constructor(scene: Scene, engine: Engine, camera: FreeCamera, settings: Settings) {
    this.scene = scene;
    this.camera = camera;
    this.settings = settings;
    void engine;
    scene.clearColor = new Color4(0.5, 0.7, 0.9, 1);
    scene.fogMode = Scene.FOGMODE_LINEAR;
    scene.fogStart = 80;
    scene.fogEnd = 140;
    scene.fogColor = new Color3(0.7, 0.8, 0.9);

    this.hemi = new HemisphericLight("hemi", new Vector3(0, 1, 0), scene);
    this.hemi.intensity = 0.55;
    this.hemi.groundColor = new Color3(0.25, 0.22, 0.2);

    this.sun = new DirectionalLight("sun", new Vector3(-0.5, -1, -0.3), scene);
    this.sun.intensity = 1.2;
    this.sun.diffuse = new Color3(1, 0.97, 0.9);
    this.sun.specular = new Color3(0.35, 0.33, 0.3);
    this.sun.shadowMinZ = 0;
    this.sun.shadowMaxZ = 200;

    this.moon = new DirectionalLight("moon", new Vector3(0.5, -1, 0.3), scene);
    this.moon.intensity = 0;
    this.moon.diffuse = new Color3(0.55, 0.65, 1);
    this.moon.specular = new Color3(0.1, 0.1, 0.2);

    this.shadowGen = this.makeShadows(settings);

    // Sky dome (no depth write so the sun/moon/clouds draw on top of it)
    Effect.ShadersStore["aetherSkyVertexShader"] = SKY_VS;
    Effect.ShadersStore["aetherSkyFragmentShader"] = SKY_FS;
    this.skyMat = new ShaderMaterial("skyMat", scene, { vertex: "aetherSky", fragment: "aetherSky" }, {
      attributes: ["position"],
      uniforms: ["worldViewProjection", "uSunDir", "uZenith", "uHorizon", "uSunColor", "uStars", "uAurora", "uRainbow", "uTime", "uSunVis", "uDark", "uShafts", "uAur1", "uAur2"],
    });
    this.skyMat.backFaceCulling = false;
    this.skyMat.disableDepthWrite = true;
    this.sky = MeshBuilder.CreateSphere("sky", { diameter: 2000, segments: 32 }, scene);
    this.sky.material = this.skyMat;
    this.sky.infiniteDistance = true;
    this.sky.isPickable = false;
    this.sky.applyFog = false;
    this.sky.renderingGroupId = 0;

    // Sun and moon: camera-facing glowing discs placed along the light direction
    const sunMat = new StandardMaterial("sunMat", scene);
    sunMat.emissiveTexture = glowTexture(scene, "rgba(255,250,225,1)", "rgba(255,190,90,0.45)", 0.16);
    sunMat.opacityTexture = sunMat.emissiveTexture;
    sunMat.disableLighting = true;
    sunMat.diffuseColor = new Color3(0, 0, 0);
    sunMat.disableDepthWrite = true;
    sunMat.fogEnabled = false;
    this.sunMesh = MeshBuilder.CreatePlane("sunDisc", { size: 260 }, scene);
    this.sunMesh.material = sunMat;
    this.sunMesh.billboardMode = Mesh.BILLBOARDMODE_ALL;
    this.sunMesh.isPickable = false;
    this.sunMesh.applyFog = false;
    this.sunMesh.infiniteDistance = true;

    const moonMat = new StandardMaterial("moonMat", scene);
    moonMat.emissiveTexture = glowTexture(scene, "rgba(230,238,255,1)", "rgba(140,170,255,0.25)", 0.2);
    moonMat.opacityTexture = moonMat.emissiveTexture;
    moonMat.disableLighting = true;
    moonMat.diffuseColor = new Color3(0, 0, 0);
    moonMat.disableDepthWrite = true;
    moonMat.fogEnabled = false;
    this.moonMesh = MeshBuilder.CreatePlane("moonDisc", { size: 120 }, scene);
    this.moonMesh.material = moonMat;
    this.moonMesh.billboardMode = Mesh.BILLBOARDMODE_ALL;
    this.moonMesh.isPickable = false;
    this.moonMesh.applyFog = false;
    this.moonMesh.infiniteDistance = true;

    // Clouds
    Effect.ShadersStore["aetherCloudVertexShader"] = CLOUD_VS;
    Effect.ShadersStore["aetherCloudFragmentShader"] = CLOUD_FS;
    this.cloudMat = new ShaderMaterial("cloudMat", scene, { vertex: "aetherCloud", fragment: "aetherCloud" }, {
      attributes: ["position"],
      uniforms: ["worldViewProjection", "world", "uSunDir", "uCam", "uTime", "uCover", "uSunCol", "uAmb", "uDark", "uWind"],
      needAlphaBlending: true,
    });
    this.cloudMat.alphaMode = Engine.ALPHA_COMBINE;
    this.cloudMat.disableDepthWrite = true;
    this.cloudMat.backFaceCulling = false;
    this.cloudMat.setVector2("uWind", new Vector2(1, 0.4));
    this.clouds = MeshBuilder.CreateGround("clouds", { width: 3200, height: 3200, subdivisions: 2 }, scene);
    this.clouds.position.y = 180;
    this.clouds.material = this.cloudMat;
    this.clouds.isPickable = false;
    this.clouds.applyFog = false;

    // World-space god-ray beams (additive quads aligned with the sun direction)
    Effect.ShadersStore["aetherBeamVertexShader"] = BEAM_VS;
    Effect.ShadersStore["aetherBeamFragmentShader"] = BEAM_FS;
    for (let i = 0; i < 9; i++) {
      const mat = new ShaderMaterial(`beamMat${i}`, scene, { vertex: "aetherBeam", fragment: "aetherBeam" }, {
        attributes: ["position", "uv"],
        uniforms: ["worldViewProjection", "uColor", "uAlpha", "uTime", "uSeed"],
        needAlphaBlending: true,
      });
      mat.alphaMode = Engine.ALPHA_ADD;
      mat.disableDepthWrite = true;
      mat.backFaceCulling = false;
      mat.setFloat("uSeed", i * 1.37);
      const mesh = MeshBuilder.CreatePlane(`beam${i}`, { width: 7 + (i % 3) * 4, height: 260 }, scene);
      mesh.material = mat;
      mesh.isPickable = false;
      mesh.applyFog = false;
      const a = (i / 9) * Math.PI * 2;
      this.beams.push({ mesh, mat, ox: Math.cos(a) * (18 + i * 6), oz: Math.sin(a) * (18 + i * 6), seed: i });
    }

    // Post-processing: MSAA + FXAA, ACES, contrast/saturation; no sharpen or grain (those read as noise)
    this.pipeline = new DefaultRenderingPipeline("aetherPipe", true, scene, [camera]);
    this.pipeline.samples = settings.antialias ? 4 : 1;
    this.pipeline.fxaaEnabled = true;
    this.pipeline.bloomEnabled = settings.bloom;
    this.pipeline.bloomThreshold = 0.78;
    this.pipeline.bloomWeight = 0.38;
    this.pipeline.bloomKernel = 64;
    this.pipeline.bloomScale = 0.5;
    this.pipeline.sharpenEnabled = false;
    this.pipeline.grainEnabled = false;
    this.pipeline.chromaticAberrationEnabled = false;
    this.pipeline.imageProcessingEnabled = true;
    const ip = this.pipeline.imageProcessing;
    ip.toneMappingEnabled = true;
    ip.toneMappingType = ImageProcessingConfiguration.TONEMAPPING_ACES;
    ip.exposure = 1.2;
    ip.contrast = 1.22;
    ip.vignetteEnabled = true;
    ip.vignetteWeight = 1.4;
    ip.vignetteColor = new Color4(0, 0, 0, 0);
    ip.vignetteStretch = 0.4;

    if (settings.ssao) this.setupSSAO(camera);

    // Weather particles
    this.emitter = MeshBuilder.CreateBox("weatherEmitter", { size: 0.1 }, scene);
    this.emitter.isVisible = false;
    this.emitter.isPickable = false;
    this.rain = new ParticleSystem("rain", 3000, scene);
    this.rain.particleTexture = streakTexture(scene);
    this.rain.emitter = this.emitter;
    this.rain.minEmitBox = new Vector3(-24, 0, -24);
    this.rain.maxEmitBox = new Vector3(24, 6, 24);
    this.rain.direction1 = new Vector3(-0.8, -24, -0.8);
    this.rain.direction2 = new Vector3(0.8, -20, 0.8);
    this.rain.minLifeTime = 0.6;
    this.rain.maxLifeTime = 0.95;
    this.rain.emitRate = 1600;
    this.rain.minSize = 0.04;
    this.rain.maxSize = 0.07;
    this.rain.minScaleY = 6;
    this.rain.maxScaleY = 9;
    this.rain.color1 = new Color4(0.75, 0.82, 0.95, 0.5);
    this.rain.color2 = new Color4(0.7, 0.8, 0.95, 0.35);
    this.rain.colorDead = new Color4(0.7, 0.8, 0.9, 0);
    this.rain.gravity = new Vector3(0, 0, 0);
    this.rain.billboardMode = ParticleSystem.BILLBOARDMODE_Y;

    this.snow = new ParticleSystem("snow", 1800, scene);
    this.snow.particleTexture = glowTexture(scene, "rgba(255,255,255,1)", "rgba(255,255,255,0.6)", 0.3);
    this.snow.emitter = this.emitter;
    this.snow.minEmitBox = new Vector3(-28, 0, -28);
    this.snow.maxEmitBox = new Vector3(28, 6, 28);
    this.snow.direction1 = new Vector3(-0.8, -2.2, -0.8);
    this.snow.direction2 = new Vector3(0.8, -1.4, 0.8);
    this.snow.minLifeTime = 4;
    this.snow.maxLifeTime = 7;
    this.snow.emitRate = 280;
    this.snow.minSize = 0.08;
    this.snow.maxSize = 0.16;
    this.snow.color1 = new Color4(1, 1, 1, 0.9);
    this.snow.color2 = new Color4(0.95, 0.98, 1, 0.8);
    this.snow.colorDead = new Color4(1, 1, 1, 0);

    this.applySettings(settings);
  }

  private makeShadows(s: Settings): ShadowGenerator {
    try {
      const csm = new CascadedShadowGenerator(s.shadowMapSize, this.sun);
      csm.numCascades = 3;
      csm.lambda = 0.85;
      csm.shadowMaxZ = 160;
      csm.stabilizeCascades = true;
      csm.usePercentageCloserFiltering = true;
      csm.filteringQuality = ShadowGenerator.QUALITY_MEDIUM;
      csm.cascadeBlendPercentage = 0.1;
      csm.darkness = 0.28;
      csm.bias = 0.0008;
      csm.normalBias = 0.015;
      return csm;
    } catch (err) {
      console.warn("Cascaded shadows unavailable, using a single shadow map", err);
      const sg = new ShadowGenerator(s.shadowMapSize, this.sun);
      sg.usePercentageCloserFiltering = true;
      sg.darkness = 0.3;
      sg.bias = 0.0012;
      this.sun.orthoLeft = -90; this.sun.orthoRight = 90; this.sun.orthoBottom = -90; this.sun.orthoTop = 90;
      return sg;
    }
  }

  private setupSSAO(camera: FreeCamera): void {
    try {
      this.ssao = new SSAO2RenderingPipeline("ssao", this.scene, { ssaoRatio: 0.5, blurRatio: 0.5 });
      this.ssao.radius = 1.2;
      this.ssao.totalStrength = 0.9;
      this.scene.postProcessRenderPipelineManager.attachCamerasToRenderPipeline("ssao", camera);
    } catch (err) {
      console.warn("SSAO unavailable", err);
      this.ssao = null;
    }
  }

  applySettings(s: Settings): void {
    this.settings = s;
    this.sun.shadowEnabled = s.shadows;
    this.clouds.setEnabled(s.volumetricClouds);
    this.pipeline.bloomEnabled = s.bloom;
    this.pipeline.samples = s.antialias ? 4 : 1;
    this.pipeline.fxaaEnabled = true;
    for (const b of this.beams) b.mesh.setEnabled(s.godRays);
    if (this.ssao) {
      this.ssao.dispose();
      this.ssao = null;
    }
    if (s.ssao) this.setupSSAO(this.camera);
    if (this.shadowGen.mapSize !== s.shadowMapSize) {
      const casters = this.shadowGen.getShadowMap()?.renderList?.slice() ?? [];
      this.shadowGen.dispose();
      this.shadowGen = this.makeShadows(s);
      for (const m of casters) this.shadowGen.addShadowCaster(m as Mesh, false);
    }
    this.rain.emitRate = s.particles ? 1600 : 0;
    this.snow.emitRate = s.particles ? 280 : 0;
    this.renderDistance = s.renderDistance;
  }

  /** Underwater: dense coloured fog + darker ambient, keyed by fluid kind (null = above water). */
  setUnderwater(kind: string | null): void {
    this.underwater = kind;
  }

  update(dt: number, pos: Vector3, st: EnvState, timeFrac: number): void {
    const t = st.worldTime;
    const a = timeFrac * Math.PI * 2;
    const sd = new Vector3(Math.cos(a), Math.sin(a), 0.32).normalize();
    this.sunDirV.copyFrom(sd);
    this.sunElevation = sd.y;
    this.dayness = smoothstep(-0.14, 0.18, sd.y);
    const twilight = Math.exp(-(sd.y * sd.y) / 0.014);
    const sky = st.sky;
    const weatherDark = st.weather === "thunder" ? 0.5 : st.weather === "rain" ? 0.72 : st.weather === "snow" ? 0.86 : 1;
    this.weatherCurrent = st.weather;
    const targetWet = st.weather === "rain" || st.weather === "thunder" ? 1 : 0;
    this.wetness += (targetWet - this.wetness) * Math.min(1, dt * 0.25);

    let zenith = lerp3([0.01, 0.015, 0.05], sky.zenith, this.dayness);
    let horizon = lerp3([0.04, 0.05, 0.12], sky.horizon, this.dayness);
    horizon = lerp3(horizon, [1.0, 0.48, 0.2], twilight * 0.85 * (sky.kind === "overworld" ? 1 : 0.2));
    zenith = lerp3(zenith, [zenith[0] * 0.85, zenith[1] * 0.7, zenith[2] * 0.95], twilight * 0.3);
    if (sky.kind === "nether" || sky.kind === "end") { zenith = sky.zenith; horizon = sky.horizon; }

    const sunCol: [number, number, number] = lerp3([1.0, 0.97, 0.88], [1.0, 0.5, 0.2], twilight);
    this.skyMat.setVector3("uSunDir", sd);
    this.skyMat.setColor3("uZenith", c3(zenith));
    this.skyMat.setColor3("uHorizon", c3(horizon));
    this.skyMat.setColor3("uSunColor", c3(sunCol));
    const night = 1 - this.dayness;
    this.skyMat.setFloat("uStars", (sky.starsAlways ? 1 : night) * (this.settings.stars ? 1 : 0) * (1 - this.wetness * 0.8));
    const aurora = (sky.auroraAllowed ? 1 : 0) * (this.settings.aurora ? 1 : 0) * (sky.kind === "sift" ? 0.8 : smoothstep(0.1, 0.85, night)) * (st.season === 3 ? 1 : 0.8);
    this.skyMat.setFloat("uAurora", aurora);
    this.skyMat.setColor3("uAur1", sky.kind === "sift" ? new Color3(0.3, 1.0, 0.8) : new Color3(0.2, 1.0, 0.45));
    this.skyMat.setColor3("uAur2", sky.kind === "sift" ? new Color3(0.7, 0.4, 1.0) : new Color3(0.25, 0.6, 1.0));
    const rainbow = sky.rainbowAllowed && st.weather === "clear" && this.wetness > 0.03 ? clamp(this.wetness * 1.4, 0, 1) * smoothstep(0.02, 0.25, sd.y) * (1 - smoothstep(0.4, 0.65, sd.y)) : 0;
    this.skyMat.setFloat("uRainbow", rainbow);
    this.skyMat.setFloat("uSunVis", sky.sunVisible ? 1 - this.wetness * 0.7 : 0);
    // sun shafts are strongest when the sun is low (sunrise/sunset)
    const shafts = this.settings.godRays ? (0.35 + 0.9 * twilight) * smoothstep(-0.05, 0.08, sd.y) * (1 - this.wetness) : 0;
    this.skyMat.setFloat("uShafts", shafts);
    this.skyMat.setFloat("uTime", t);
    this.skyMat.setFloat("uDark", weatherDark + this.lightning * 0.9);

    // Lights
    const sunUp = smoothstep(-0.02, 0.12, sd.y);
    this.sun.direction = sd.scale(-1);
    this.sun.position = pos.add(sd.scale(150));
    this.sun.intensity = sky.sunVisible ? (0.12 + 1.15 * sunUp) * (1 - 0.5 * this.wetness) : 0;
    this.sun.diffuse = c3(sunCol);
    this.moon.direction = sd.scale(1);
    this.moon.intensity = (1 - sunUp) * 0.3 * (sky.sunVisible ? 1 : 0.5);
    this.hemi.intensity = (0.22 + 0.48 * this.dayness) * (sky.kind === "nether" ? 0.85 : 1) * (1 - 0.2 * this.wetness);
    const ambient = sky.kind === "overworld" ? lerp3([0.22, 0.27, 0.45], [0.66, 0.74, 0.9], this.dayness) : sky.ambient;
    this.hemi.diffuse = c3(ambient);
    this.hemi.groundColor = c3(lerp3([0.1, 0.09, 0.1], [0.3, 0.26, 0.21], this.dayness));
    this.hemi.specular = new Color3(0, 0, 0);

    // Fog: crisp until near the edge of the render distance, then fades into the horizon colour
    let fog: [number, number, number] = lerp3([0.02, 0.03, 0.07], sky.fog, this.dayness);
    fog = lerp3(fog, [fog[0] * 1.25, fog[1] * 0.75, fog[2] * 0.5], twilight * 0.6 * (sky.kind === "overworld" ? 1 : 0));
    fog = [fog[0] * weatherDark, fog[1] * weatherDark, fog[2] * weatherDark];
    if (sky.kind === "nether" || sky.kind === "end") fog = sky.fog;
    const rd = this.renderDistance * 16;
    let fogStart = rd * (st.weather === "clear" ? 0.62 : 0.3);
    let fogEnd = rd * (st.weather === "clear" ? 1.0 : 0.75);
    if (sky.kind === "nether") { fogStart = 10; fogEnd = Math.min(rd, 90); }
    if (this.underwater) {
      fog = this.underwater.includes("toxic") ? [0.18, 0.32, 0.06] : this.underwater.includes("sift") ? [0.2, 0.55, 0.6] : [0.04, 0.2, 0.32];
      fogStart = 2;
      fogEnd = 34;
    }
    this.scene.fogMode = Scene.FOGMODE_LINEAR;
    this.scene.fogColor = c3(fog);
    this.scene.fogStart = fogStart;
    this.scene.fogEnd = fogEnd;
    this.scene.clearColor = new Color4(fog[0], fog[1], fog[2], 1);

    // Sun & moon discs
    this.sunMesh.position.copyFrom(sd.scale(900));
    this.sunMesh.setEnabled(sky.sunVisible && sd.y > -0.12 && !this.underwater);
    (this.sunMesh.material as StandardMaterial).alpha = 1 - this.wetness * 0.85;
    this.moonMesh.position.copyFrom(sd.scale(-900));
    this.moonMesh.setEnabled(sky.kind === "overworld" && sd.y < 0.12 && !this.underwater);

    // Clouds
    const cover = st.weather === "thunder" ? 0.92 : st.weather === "rain" ? 0.78 : st.weather === "snow" ? 0.8 : st.season === 2 ? 0.6 : 0.48;
    this.cloudCover += (cover - this.cloudCover) * Math.min(1, dt * 0.4);
    this.cloudMat.setFloat("uCover", this.cloudCover);
    this.cloudMat.setVector3("uSunDir", sd);
    this.cloudMat.setVector3("uCam", pos);
    this.cloudMat.setFloat("uTime", t);
    this.cloudMat.setColor3("uSunCol", c3(sunCol));
    this.cloudMat.setColor3("uAmb", c3(lerp3([0.1, 0.12, 0.2], [0.86, 0.89, 0.96], this.dayness)));
    this.cloudMat.setFloat("uDark", weatherDark);
    this.clouds.position.set(Math.round(pos.x / 64) * 64, sky.kind === "sift" ? 200 : 180, Math.round(pos.z / 64) * 64);
    this.clouds.setEnabled(this.settings.volumetricClouds && sky.cloudsAllowed);

    // God-ray beams: planes tilted along the sun direction, rotated to face the camera around their axis
    const beamStrength = this.settings.godRays && sky.sunVisible && !this.underwater
      ? (0.05 + 0.2 * twilight) * smoothstep(0.0, 0.1, sd.y) * (1 - this.wetness) * (0.6 + 0.4 * this.cloudCover)
      : 0;
    for (const b of this.beams) {
      b.mesh.setEnabled(beamStrength > 0.005 && this.settings.godRays);
      if (beamStrength <= 0.005) continue;
      const base = new Vector3(pos.x + b.ox, pos.y - 10, pos.z + b.oz);
      b.mesh.position.copyFrom(base.add(sd.scale(130)));
      const axis = sd.clone();
      const toCam = pos.subtract(b.mesh.position);
      const side = Vector3.Cross(axis, toCam).normalize();
      const normal = Vector3.Cross(side, axis).normalize();
      b.mesh.rotation = Vector3.RotationFromAxis(side, axis, normal);
      b.mat.setColor3("uColor", c3(sunCol));
      b.mat.setFloat("uAlpha", beamStrength);
      b.mat.setFloat("uTime", t);
    }

    // Weather particles
    this.emitter.position.set(pos.x, pos.y + 14, pos.z);
    const raining = st.weather === "rain" || st.weather === "thunder";
    if (raining && this.settings.particles && sky.weatherAllowed && !this.underwater) {
      if (!this.rain.isStarted()) this.rain.start();
      this.rain.emitRate = st.weather === "thunder" ? 2400 : 1600;
    } else if (this.rain.isStarted()) this.rain.stop();
    if (st.weather === "snow" && this.settings.particles && sky.weatherAllowed && !this.underwater) {
      if (!this.snow.isStarted()) this.snow.start();
    } else if (this.snow.isStarted()) this.snow.stop();

    // Lightning (thunder sound is triggered by the game via onLightning)
    if (st.weather === "thunder" && sky.weatherAllowed) {
      this.nextBolt -= dt;
      if (this.nextBolt <= 0) {
        this.lightning = 1;
        this.nextBolt = 5 + Math.random() * 12;
        const p = this.spawnBolt(pos);
        this.onLightning?.(p, Vector3.Distance(p, pos));
      }
    }
    if (this.lightning > 0) this.lightning = Math.max(0, this.lightning - dt * 2.2);
    if (this.bolt) {
      this.boltAge += dt;
      if (this.boltAge > 0.3) { this.bolt.dispose(); this.bolt = null; }
    }
  }

  private spawnBolt(pos: Vector3): Vector3 {
    if (this.bolt) this.bolt.dispose();
    const pts: Vector3[] = [];
    let x = pos.x + (Math.random() - 0.5) * 160, z = pos.z + (Math.random() - 0.5) * 160;
    const ground = new Vector3(x, 60, z);
    let y = 170;
    while (y > 55) {
      pts.push(new Vector3(x, y, z));
      y -= 5 + Math.random() * 5;
      x += (Math.random() - 0.5) * 5;
      z += (Math.random() - 0.5) * 5;
    }
    this.bolt = MeshBuilder.CreateTube("bolt", { path: pts, radius: 0.3, tessellation: 4 }, this.scene);
    const m = new StandardMaterial("boltMat", this.scene);
    m.emissiveColor = new Color3(0.85, 0.92, 1);
    m.disableLighting = true;
    this.bolt.material = m;
    this.bolt.isPickable = false;
    this.boltAge = 0;
    return ground;
  }

  get sunDir(): Vector3 { return this.sunDirV; }
  get dayFactor(): number { return this.dayness; }
  get weather(): Weather { return this.weatherCurrent; }
  get wetFactor(): number { return this.wetness; }

  setShadowCasters(meshes: Mesh[]): void {
    const rl = this.shadowGen.getShadowMap()?.renderList;
    if (!rl) return;
    rl.length = 0;
    for (const m of meshes) rl.push(m);
  }

  setLightningFlash(v: number): void {
    this.lightning = Math.max(this.lightning, v);
  }

  dispose(): void {
    this.rain.dispose();
    this.snow.dispose();
    this.pipeline.dispose();
    this.shadowGen.dispose();
    this.sky.dispose();
    this.clouds.dispose();
    this.sunMesh.dispose();
    this.moonMesh.dispose();
    for (const b of this.beams) b.mesh.dispose();
    this.bolt?.dispose();
    this.ssao?.dispose();
  }
}
