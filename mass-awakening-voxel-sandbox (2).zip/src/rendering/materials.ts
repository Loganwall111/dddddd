// Shared materials: atlas terrain (bump + wet gloss), emissive, alpha-tested foliage, glass, animated portal
// shader, Babylon WaterMaterial water (planar reflection + refraction), puddles and crack overlays.

import {
  Color3, Effect, Engine, Material, Scene, ShaderMaterial, StandardMaterial, Texture, Vector2, WaterMaterial,
} from "./babylon";
import type { Atlas } from "../blocks/textures";
import type { MaterialMap } from "../world/world";

export interface MaterialLib extends MaterialMap {
  solid: StandardMaterial;
  water: WaterMaterial;
  toxic_water: WaterMaterial;
  sift_water: WaterMaterial;
  portalMat: ShaderMaterial;
  puddle: StandardMaterial;
}

export interface MaterialOptions {
  shadows: boolean;
  waterQuality: 0 | 1 | 2;
}

const PORTAL_VS = `
precision highp float;
attribute vec3 position;
attribute vec2 uv;
uniform mat4 worldViewProjection;
varying vec2 vUV;
varying vec3 vPos;
void main(void) { vUV = uv; vPos = position; gl_Position = worldViewProjection * vec4(position, 1.0); }`;

const PORTAL_FS = `
precision highp float;
varying vec2 vUV;
varying vec3 vPos;
uniform float time;
float h(vec2 p) { return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453); }
float n(vec2 p) {
  vec2 i = floor(p); vec2 f = fract(p); f = f * f * (3.0 - 2.0 * f);
  return mix(mix(h(i), h(i + vec2(1.0, 0.0)), f.x), mix(h(i + vec2(0.0, 1.0)), h(i + vec2(1.0, 1.0)), f.x), f.y);
}
void main(void) {
  vec2 p = vPos.xy * 2.2 + vPos.zz * 1.9;
  float t = time * 0.9;
  float v = 0.0; float a = 0.5; vec2 q = p;
  for (int i = 0; i < 4; i++) { v += a * n(q + vec2(sin(t + float(i)), cos(t * 0.7))); q = q * 2.03 + vec2(t * 0.6, -t * 0.4); a *= 0.5; }
  vec3 col = mix(vec3(0.05, 0.02, 0.22), vec3(0.42, 0.12, 0.95), smoothstep(0.25, 0.6, v));
  col = mix(col, vec3(0.15, 0.95, 1.0), smoothstep(0.62, 0.95, v) * 0.85);
  gl_FragColor = vec4(col * 1.35, 0.8);
}`;

function buildWaterNormal(): HTMLCanvasElement {
  const N = 256;
  const c = document.createElement("canvas");
  c.width = N;
  c.height = N;
  const g = c.getContext("2d")!;
  const img = g.createImageData(N, N);
  const hgt = new Float32Array(N * N);
  const rnd = (x: number, y: number, s: number) => {
    let h = (x * 374761393 + y * 668265263 + s * 982451653) | 0;
    h = Math.imul(h ^ (h >>> 13), 1274126177);
    return ((h ^ (h >>> 16)) >>> 0) / 4294967296;
  };
  for (let y = 0; y < N; y++) for (let x = 0; x < N; x++) {
    let v = 0, amp = 1, tot = 0;
    for (let o = 0; o < 4; o++) {
      const cell = 4 << o;
      const gx = (x / N) * cell, gy = (y / N) * cell;
      const x0 = Math.floor(gx), y0 = Math.floor(gy);
      const fx = gx - x0, fy = gy - y0;
      const sx = fx * fx * (3 - 2 * fx), sy = fy * fy * (3 - 2 * fy);
      const a = rnd(x0 % cell, y0 % cell, o), b = rnd((x0 + 1) % cell, y0 % cell, o);
      const cc = rnd(x0 % cell, (y0 + 1) % cell, o), d = rnd((x0 + 1) % cell, (y0 + 1) % cell, o);
      const top = a + (b - a) * sx, bot = cc + (d - cc) * sx;
      v += (top + (bot - top) * sy) * amp; tot += amp; amp *= 0.5;
    }
    hgt[y * N + x] = v / tot;
  }
  for (let y = 0; y < N; y++) for (let x = 0; x < N; x++) {
    const l = hgt[y * N + ((x + 1) % N)] - hgt[y * N + ((x - 1 + N) % N)];
    const u = hgt[((y + 1) % N) * N + x] - hgt[((y - 1 + N) % N) * N + x];
    const nx = -l * 3, ny = -u * 3;
    const inv = 1 / Math.hypot(nx, ny, 1);
    const o = (y * N + x) * 4;
    img.data[o] = (nx * inv * 0.5 + 0.5) * 255;
    img.data[o + 1] = (ny * inv * 0.5 + 0.5) * 255;
    img.data[o + 2] = (inv * 0.5 + 0.5) * 255;
    img.data[o + 3] = 255;
  }
  g.putImageData(img, 0, 0);
  return c;
}

function canvasTexture(canvas: HTMLCanvasElement, scene: Scene, sampling: number): Texture {
  return new Texture(canvas.toDataURL("image/png"), scene, false, false, sampling);
}

export function createMaterials(scene: Scene, atlas: Atlas, opts: MaterialOptions): MaterialLib {
  // Nearest magnification keeps pixel-art crisp up close; trilinear mips + anisotropy keep distance calm.
  const colorTex = canvasTexture(atlas.color, scene, Texture.NEAREST_LINEAR_MIPLINEAR);
  colorTex.anisotropicFilteringLevel = 8;
  const normalTex = canvasTexture(atlas.normal, scene, Texture.NEAREST_LINEAR_MIPLINEAR);
  normalTex.anisotropicFilteringLevel = 8;
  normalTex.gammaSpace = false;

  const solid = new StandardMaterial("mat_solid", scene);
  solid.diffuseTexture = colorTex;
  solid.bumpTexture = normalTex;
  solid.bumpTexture.level = 0.7;
  solid.specularColor = new Color3(0.05, 0.05, 0.05);
  solid.specularPower = 24;
  solid.ambientColor = new Color3(0.14, 0.14, 0.16);
  solid.backFaceCulling = false; // mesher winding not verified against Babylon's convention; keep both sides

  const emissive = new StandardMaterial("mat_emissive", scene);
  emissive.diffuseTexture = colorTex;
  emissive.emissiveTexture = colorTex;
  emissive.disableLighting = true;
  emissive.backFaceCulling = false;

  const cutout = new StandardMaterial("mat_cutout", scene);
  cutout.diffuseTexture = colorTex;
  cutout.useAlphaFromDiffuseTexture = true;
  cutout.transparencyMode = Material.MATERIAL_ALPHATEST;
  cutout.alphaCutOff = 0.5;
  cutout.backFaceCulling = false;
  cutout.specularColor = new Color3(0, 0, 0);
  cutout.ambientColor = new Color3(0.16, 0.16, 0.16);

  const emissiveCut = new StandardMaterial("mat_emissive_cut", scene);
  emissiveCut.diffuseTexture = colorTex;
  emissiveCut.emissiveTexture = colorTex;
  emissiveCut.useAlphaFromDiffuseTexture = true;
  emissiveCut.transparencyMode = Material.MATERIAL_ALPHATEST;
  emissiveCut.disableLighting = true;
  emissiveCut.backFaceCulling = false;

  const glass = new StandardMaterial("mat_glass", scene);
  glass.diffuseTexture = colorTex;
  glass.useAlphaFromDiffuseTexture = true;
  glass.transparencyMode = Material.MATERIAL_ALPHABLEND;
  glass.needDepthPrePass = true;
  glass.backFaceCulling = false;
  glass.specularColor = new Color3(0.9, 0.95, 1);
  glass.specularPower = 96;

  const lava = new StandardMaterial("mat_lava", scene);
  lava.diffuseTexture = colorTex;
  lava.emissiveTexture = colorTex;
  lava.disableLighting = true;
  lava.backFaceCulling = false;

  Effect.ShadersStore["aetherPortalVertexShader"] = PORTAL_VS;
  Effect.ShadersStore["aetherPortalFragmentShader"] = PORTAL_FS;
  const portalMat = new ShaderMaterial("mat_portal", scene, { vertex: "aetherPortal", fragment: "aetherPortal" }, {
    attributes: ["position", "uv"],
    uniforms: ["worldViewProjection", "time"],
    needAlphaBlending: true,
  });
  portalMat.alphaMode = Engine.ALPHA_COMBINE;
  portalMat.backFaceCulling = false;
  portalMat.setFloat("time", 0);

  const waterNormal = canvasTexture(buildWaterNormal(), scene, Texture.TRILINEAR_SAMPLINGMODE);
  const rt = opts.waterQuality === 2 ? 1024 : opts.waterQuality === 1 ? 512 : 256;
  const mkWater = (name: string, color: [number, number, number], blend: number, bumpH: number, wind: number) => {
    const w = new WaterMaterial(name, scene, new Vector2(rt, rt));
    w.bumpTexture = waterNormal;
    w.windForce = wind;
    w.waveHeight = 0.0;
    w.waveLength = 0.15;
    w.bumpHeight = bumpH;
    w.windDirection = new Vector2(1, 0.6);
    w.waterColor = new Color3(color[0], color[1], color[2]);
    w.colorBlendFactor = blend;
    w.waterColor2 = new Color3(color[0] * 0.6, color[1] * 0.8, color[2]);
    w.colorBlendFactor2 = blend * 0.6;
    w.backFaceCulling = false;
    return w;
  };
  const water = mkWater("mat_water", [0.03, 0.26, 0.4], 0.32, 0.35, 5);
  const toxic = mkWater("mat_toxic", [0.28, 0.55, 0.08], 0.6, 0.3, 3);
  const sift = mkWater("mat_sift", [0.15, 0.55, 0.65], 0.35, 0.5, 8);

  const puddle = new StandardMaterial("mat_puddle", scene);
  puddle.diffuseColor = new Color3(0.08, 0.1, 0.13);
  puddle.specularColor = new Color3(1, 1, 1);
  puddle.specularPower = 220;
  puddle.emissiveColor = new Color3(0.25, 0.3, 0.38);
  puddle.alpha = 0;
  puddle.zOffset = -1;
  puddle.bumpTexture = waterNormal;
  puddle.bumpTexture.level = 0.35;

  return {
    solid, emissive, cutout, emissive_cut: emissiveCut, glass, lava, portal: portalMat,
    water, toxic_water: toxic, sift_water: sift, portalMat, puddle,
  } as MaterialLib;
}

export function createCrackMaterials(scene: Scene, frames: HTMLCanvasElement[]): StandardMaterial[] {
  return frames.map((f, i) => {
    const m = new StandardMaterial(`mat_crack_${i}`, scene);
    m.diffuseTexture = canvasTexture(f, scene, Texture.NEAREST_NEAREST);
    m.useAlphaFromDiffuseTexture = true;
    m.transparencyMode = Material.MATERIAL_ALPHABLEND;
    m.disableLighting = true;
    m.backFaceCulling = false;
    m.zOffset = -2;
    return m;
  });
}

export function applyWaterQuality(lib: MaterialLib, quality: 0 | 1 | 2, reflections: boolean): void {
  for (const w of [lib.water, lib.toxic_water, lib.sift_water]) {
    const refl = w.reflectionTexture;
    if (refl && (!reflections || quality === 0)) refl.renderList = [];
    const refr = w.refractionTexture;
    if (refr && quality < 2) refr.renderList = [];
  }
}

/** Rain makes the ground darker and glossier; puddles fade in with wetness. */
export function setWetness(lib: MaterialLib, wet: number, skyColor: Color3): void {
  const s = 0.05 + wet * 0.5;
  lib.solid.specularColor.set(s, s, s * 1.05);
  lib.solid.specularPower = 24 + wet * 70;
  const d = 1 - wet * 0.22;
  lib.solid.diffuseColor.set(d, d, d);
  lib.puddle.alpha = wet * 0.78;
  lib.puddle.emissiveColor.copyFrom(skyColor.scale(0.55));
}

export function setPortalTime(lib: MaterialLib, t: number): void {
  lib.portalMat.setFloat("time", t);
}
