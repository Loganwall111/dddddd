// App shell: owns the single Game instance (Babylon canvas behind everything) and routes between screens.
// The title screen floats over the panorama; every other menu is a full-screen page.

import { useEffect, useRef, useState } from "react";
import { Game, type Snapshot } from "./core/Game";
import { loadSettings, saveSettings, type Settings } from "./core/settings";
import { audio } from "./audio/audio";
import { MainMenu, WorldSelect, CreateWorld, SettingsScreen, CharacterScreen, ControlsScreen, CreditsScreen, InfoScreen, loadCharacter } from "./ui/Menus";
import { GameOverlay } from "./ui/InGame";
import { db, newWorldId, type WorldMeta } from "./persistence/db";
import type { CharacterOpts } from "./entities/entities";

type Route = "title" | "worlds" | "create" | "settings" | "controls" | "credits" | "character" | "multiplayer" | "dimensions" | "game";

export default function App() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const gameRef = useRef<Game | null>(null);
  const [settings, setSettings] = useState<Settings>(() => loadSettings());
  const [route, setRoute] = useState<Route>("title");
  const [snap, setSnap] = useState<Snapshot | null>(null);
  const [character, setCharacter] = useState<CharacterOpts>(() => loadCharacter());
  const [pauseSettings, setPauseSettings] = useState(false);
  const [settingsBack, setSettingsBack] = useState<Route>("title");
  const [error, setError] = useState<string | null>(null);
  const settingsRef = useRef(settings);
  settingsRef.current = settings;

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    let game: Game;
    try {
      game = new Game(canvas, settingsRef.current);
    } catch (err) {
      setError(`Could not start WebGL: ${String(err)}`);
      return;
    }
    game.setCharacter(loadCharacter());
    gameRef.current = game;
    const unsub = game.subscribe(setSnap);
    void game.startPanorama();
    const unlock = () => audio.ensure();
    window.addEventListener("pointerdown", unlock, { once: true });
    return () => {
      unsub();
      window.removeEventListener("pointerdown", unlock);
      game.dispose();
      gameRef.current = null;
    };
  }, []);

  const applySettings = (s: Settings) => {
    setSettings(s);
    saveSettings(s);
    gameRef.current?.applySettings(s);
  };

  const playWorld = async (meta: WorldMeta) => {
    const g = gameRef.current;
    if (!g) return;
    audio.ensure();
    setRoute("game");
    setPauseSettings(false);
    g.setCharacter(character);
    try {
      await g.enterWorld(meta);
    } catch (err) {
      console.error(err);
      setError(`Could not load world: ${String(err)}`);
      setRoute("worlds");
      await g.startPanorama();
    }
  };

  const playTutorial = async () => {
    const existing = (await db.listWorlds()).find((w) => w.type === "tutorial" && w.name === "Tutorial World");
    if (existing) return playWorld(existing);
    const meta: WorldMeta = {
      id: newWorldId(), name: "Tutorial World", seedText: "tutorial", seed: 1234567, mode: "survival", difficulty: "peaceful", type: "tutorial",
      created: Date.now(), lastPlayed: Date.now(), worldTime: 0, weatherSeed: 7, version: 2, cheats: true,
    };
    await db.putWorld(meta);
    return playWorld(meta);
  };

  const toTitle = () => { setRoute("title"); setPauseSettings(false); };
  const inGame = route === "game";

  return (
    <div className="app-root">
      <canvas ref={canvasRef} className="game-canvas" aria-label="Game view" />
      <div className={`vignette ${inGame ? "soft" : ""}`} />
      {!inGame && (
        <div className="menu-layer">
          {route === "title" && (
            <MainMenu go={(s) => { if (s === "settings") setSettingsBack("title"); setRoute(s as Route); }} onSingleplayer={() => setRoute("worlds")} onTutorial={() => void playTutorial()} />
          )}
          {route === "worlds" && <WorldSelect onBack={toTitle} onCreate={() => setRoute("create")} onPlay={playWorld} />}
          {route === "create" && <CreateWorld onBack={() => setRoute("worlds")} onCreated={playWorld} />}
          {route === "settings" && <SettingsScreen settings={settings} onChange={applySettings} onBack={() => setRoute(settingsBack)} onCharacter={() => setRoute("character")} />}
          {route === "controls" && <ControlsScreen onBack={toTitle} />}
          {route === "credits" && <CreditsScreen onBack={toTitle} />}
          {(route === "multiplayer" || route === "dimensions") && <InfoScreen kind={route} onBack={toTitle} />}
          {route === "character" && (
            <CharacterScreen opts={character} onChange={(c) => { setCharacter(c); gameRef.current?.setCharacter(c); }} onBack={toTitle} />
          )}
        </div>
      )}
      {inGame && gameRef.current && snap && (
        <>
          <GameOverlay game={gameRef.current} snap={snap} settings={settings} onSettingsChange={applySettings} onTitle={toTitle} onOpenSettings={() => setPauseSettings(true)} />
          {pauseSettings && (
            <div className="menu-layer overlay-top">
              <SettingsScreen settings={settings} onChange={applySettings} onBack={() => setPauseSettings(false)} />
            </div>
          )}
        </>
      )}
      {error && <div className="error-banner" role="alert" onClick={() => setError(null)}>{error}</div>}
    </div>
  );
}
