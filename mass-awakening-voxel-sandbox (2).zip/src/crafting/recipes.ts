// Data-driven recipe registry with validation, plus smelting and fuel tables.

import type { Slot } from "../inventory/inventory";

export interface Recipe {
  id: string;
  type: "shaped" | "shapeless";
  pattern?: string[]; // rows, ' ' = empty
  key?: Record<string, string>; // char -> ingredient spec
  ingredients?: string[]; // shapeless ingredient specs
  result: { key: string; count: number };
}

export interface SmeltRecipe {
  input: string;
  output: string;
  time: number; // seconds
}

const R: Recipe[] = [];
const add = (r: Recipe) => R.push(r);

add({ id: "planks_oak", type: "shapeless", ingredients: ["oak_log"], result: { key: "oak_planks", count: 4 } });
add({ id: "planks_birch", type: "shapeless", ingredients: ["birch_log"], result: { key: "birch_planks", count: 4 } });
add({ id: "planks_spruce", type: "shapeless", ingredients: ["spruce_log"], result: { key: "spruce_planks", count: 4 } });
add({ id: "planks_cherry", type: "shapeless", ingredients: ["cherry_log"], result: { key: "cherry_planks", count: 4 } });
add({ id: "sticks", type: "shaped", pattern: ["P", "P"], key: { P: "#planks" }, result: { key: "stick", count: 4 } });
add({ id: "crafting_table", type: "shaped", pattern: ["PP", "PP"], key: { P: "#planks" }, result: { key: "crafting_table", count: 1 } });
add({ id: "chest", type: "shaped", pattern: ["PPP", "P P", "PPP"], key: { P: "#planks" }, result: { key: "chest", count: 1 } });
add({ id: "furnace", type: "shaped", pattern: ["SSS", "S S", "SSS"], key: { S: "cobblestone" }, result: { key: "furnace", count: 1 } });
add({ id: "torch", type: "shapeless", ingredients: ["coal", "stick"], result: { key: "torch", count: 4 } });
add({ id: "torch_char", type: "shapeless", ingredients: ["charcoal", "stick"], result: { key: "torch", count: 4 } });
add({ id: "lantern", type: "shapeless", ingredients: ["torch", "iron_ingot"], result: { key: "lantern", count: 1 } });
add({ id: "ladder", type: "shaped", pattern: ["S S", "SSS", "S S"], key: { S: "stick" }, result: { key: "ladder", count: 3 } });
add({ id: "bookshelf", type: "shaped", pattern: ["PPP", "BBB", "PPP"], key: { P: "#planks", B: "book" }, result: { key: "bookshelf", count: 1 } });
add({ id: "book", type: "shapeless", ingredients: ["leather", "feather"], result: { key: "book", count: 1 } });
add({ id: "stone_bricks", type: "shaped", pattern: ["SS", "SS"], key: { S: "stone" }, result: { key: "stone_bricks", count: 4 } });
add({ id: "bricks", type: "shaped", pattern: ["BB", "BB"], key: { B: "brick" }, result: { key: "bricks", count: 1 } });
add({ id: "brick_item", type: "shapeless", ingredients: ["clay_ball", "clay_ball", "clay_ball", "clay_ball"], result: { key: "brick", count: 1 } });
add({ id: "iron_block", type: "shaped", pattern: ["III", "III", "III"], key: { I: "iron_ingot" }, result: { key: "iron_block", count: 1 } });
add({ id: "gold_block", type: "shaped", pattern: ["GGG", "GGG", "GGG"], key: { G: "gold_ingot" }, result: { key: "gold_block", count: 1 } });
add({ id: "diamond_block", type: "shaped", pattern: ["DDD", "DDD", "DDD"], key: { D: "diamond" }, result: { key: "diamond_block", count: 1 } });
add({ id: "copper_block", type: "shaped", pattern: ["CCC", "CCC", "CCC"], key: { C: "copper_ingot" }, result: { key: "copper_block", count: 1 } });
add({ id: "snow_block", type: "shaped", pattern: ["SS", "SS"], key: { S: "snowball" }, result: { key: "snow_block", count: 1 } });
add({ id: "wool_white", type: "shaped", pattern: ["SS", "SS"], key: { S: "string" }, result: { key: "wool_white", count: 1 } });
add({ id: "string_from_wool", type: "shapeless", ingredients: ["wool_white"], result: { key: "string", count: 3 } });
add({ id: "tnt", type: "shaped", pattern: ["GSG", "SGS", "GSG"], key: { G: "gunpowder", S: "sand" }, result: { key: "tnt", count: 1 } });
add({ id: "flint_steel", type: "shapeless", ingredients: ["iron_ingot", "flint"], result: { key: "flint_steel", count: 1 } });
add({ id: "arrow", type: "shaped", pattern: ["F", "S", "B"], key: { F: "flint", S: "stick", B: "feather" }, result: { key: "arrow", count: 4 } });
add({ id: "shears", type: "shaped", pattern: [" I", "I "], key: { I: "iron_ingot" }, result: { key: "shears", count: 1 } });
add({ id: "compass", type: "shaped", pattern: [" I ", "IRI", " I "], key: { I: "iron_ingot", R: "lapis" }, result: { key: "compass", count: 1 } });
add({ id: "clock", type: "shaped", pattern: [" G ", "GRG", " G "], key: { G: "gold_ingot", R: "redstone_dust" }, result: { key: "clock", count: 1 } });
add({ id: "bread", type: "shaped", pattern: ["WWW"], key: { W: "wheat_seeds" }, result: { key: "bread", count: 1 } });
add({ id: "crystal_lantern", type: "shapeless", ingredients: ["crystal_shard", "torch"], result: { key: "lantern", count: 1 } });
add({ id: "prism_glass", type: "shaped", pattern: ["GGG", "GPG", "GGG"], key: { G: "glass", P: "prism_shard" }, result: { key: "prism_glass", count: 4 } });
add({ id: "glowstone", type: "shaped", pattern: ["DD", "DD"], key: { D: "glowstone_dust" }, result: { key: "glowstone", count: 1 } });
add({ id: "aether_key", type: "shapeless", ingredients: ["ender_pearl", "crystal_shard"], result: { key: "aether_key", count: 1 } });

// ---- Generated tool and armour recipes ----
const TOOL_MATS: [string, string][] = [
  ["wooden", "#planks"],
  ["stone", "cobblestone"],
  ["iron", "iron_ingot"],
  ["golden", "gold_ingot"],
  ["diamond", "diamond"],
];
for (const [mat, m] of TOOL_MATS) {
  add({ id: `${mat}_pickaxe`, type: "shaped", pattern: ["MMM", " S ", " S "], key: { M: m, S: "stick" }, result: { key: `${mat}_pickaxe`, count: 1 } });
  add({ id: `${mat}_axe`, type: "shaped", pattern: ["MM", "MS", " S"], key: { M: m, S: "stick" }, result: { key: `${mat}_axe`, count: 1 } });
  add({ id: `${mat}_shovel`, type: "shaped", pattern: ["M", "S", "S"], key: { M: m, S: "stick" }, result: { key: `${mat}_shovel`, count: 1 } });
  add({ id: `${mat}_hoe`, type: "shaped", pattern: ["MM", " S", " S"], key: { M: m, S: "stick" }, result: { key: `${mat}_hoe`, count: 1 } });
  add({ id: `${mat}_sword`, type: "shaped", pattern: ["M", "M", "S"], key: { M: m, S: "stick" }, result: { key: `${mat}_sword`, count: 1 } });
}
const ARMOR: [string, string][] = [
  ["leather", "leather"],
  ["iron", "iron_ingot"],
  ["diamond", "diamond"],
];
for (const [mat, m] of ARMOR) {
  add({ id: `${mat}_helmet`, type: "shaped", pattern: ["MMM", "M M"], key: { M: m }, result: { key: `${mat}_head`, count: 1 } });
  add({ id: `${mat}_chest`, type: "shaped", pattern: ["M M", "MMM", "MMM"], key: { M: m }, result: { key: `${mat}_chest`, count: 1 } });
  add({ id: `${mat}_legs`, type: "shaped", pattern: ["MMM", "M M", "M M"], key: { M: m }, result: { key: `${mat}_legs`, count: 1 } });
  add({ id: `${mat}_boots`, type: "shaped", pattern: ["M M", "M M"], key: { M: m }, result: { key: `${mat}_feet`, count: 1 } });
}

export const RECIPES: Recipe[] = R;

/** Ingredient spec matching: exact key, or tag (#planks, #logs). */
export function ingredientMatches(spec: string, key: string): boolean {
  if (spec === "#planks") return key.endsWith("_planks");
  if (spec === "#logs") return key.endsWith("_log");
  return spec === key;
}

function trimPattern(rows: string[]): string[] {
  let top = 0, bottom = rows.length - 1;
  const width = Math.max(...rows.map((r) => r.length));
  const padded = rows.map((r) => r.padEnd(width, " "));
  const empty = (r: string) => r.split("").every((c) => c === " ");
  while (top <= bottom && empty(padded[top])) top++;
  while (bottom >= top && empty(padded[bottom])) bottom--;
  let left = 0, right = width - 1;
  const colEmpty = (c: number) => padded.slice(top, bottom + 1).every((r) => r[c] === " ");
  while (left <= right && colEmpty(left)) left++;
  while (right >= left && colEmpty(right)) right--;
  const out: string[] = [];
  for (let r = top; r <= bottom; r++) out.push(padded[r].slice(left, right + 1));
  return out;
}

/** Given a crafting grid (row-major, width w), returns the matching recipe or null. */
export function matchRecipe(grid: Slot[], w: number): Recipe | null {
  const h = grid.length / w;
  // Build a char grid from the actual items; each item gets matched against specs later
  const filled = grid.some((s) => s);
  if (!filled) return null;
  // shaped
  let minR = h, maxR = -1, minC = w, maxC = -1;
  for (let r = 0; r < h; r++) for (let c = 0; c < w; c++) {
    if (grid[r * w + c]) {
      minR = Math.min(minR, r); maxR = Math.max(maxR, r);
      minC = Math.min(minC, c); maxC = Math.max(maxC, c);
    }
  }
  const bw = maxC - minC + 1, bh = maxR - minR + 1;
  const used = grid.filter((s) => s).length;
  for (const rec of R) {
    if (rec.type === "shaped" && rec.pattern && rec.key) {
      const pat = trimPattern(rec.pattern);
      const pw = pat[0].length, ph = pat.length;
      if (pw !== bw || ph !== bh) continue;
      const cells = pat.reduce((n, row) => n + row.split("").filter((c) => c !== " ").length, 0);
      if (cells !== used) continue;
      let ok = true;
      for (let r = 0; r < ph && ok; r++) for (let c = 0; c < pw && ok; c++) {
        const ch = pat[r][c];
        const s = grid[(minR + r) * w + (minC + c)];
        if (ch === " ") { if (s) ok = false; continue; }
        const spec = rec.key[ch];
        if (!s || !spec || !ingredientMatches(spec, s.key)) ok = false;
      }
      if (ok) return rec;
    } else if (rec.type === "shapeless" && rec.ingredients) {
      if (rec.ingredients.length !== used) continue;
      const pool = grid.filter((s) => s).map((s) => s!.key);
      let ok = true;
      for (const spec of rec.ingredients) {
        const idx = pool.findIndex((k) => ingredientMatches(spec, k));
        if (idx < 0) { ok = false; break; }
        pool.splice(idx, 1);
      }
      if (ok && pool.length === 0) return rec;
    }
  }
  return null;
}

export const SMELTING: SmeltRecipe[] = [
  { input: "iron_ore", output: "iron_ingot", time: 10 },
  { input: "raw_iron", output: "iron_ingot", time: 10 },
  { input: "raw_gold", output: "gold_ingot", time: 10 },
  { input: "gold_ore", output: "gold_ingot", time: 10 },
  { input: "raw_copper", output: "copper_ingot", time: 10 },
  { input: "copper_ore", output: "copper_ingot", time: 10 },
  { input: "sand", output: "glass", time: 8 },
  { input: "cobblestone", output: "stone", time: 8 },
  { input: "clay_ball", output: "brick", time: 8 },
  { input: "oak_log", output: "charcoal", time: 10 },
  { input: "birch_log", output: "charcoal", time: 10 },
  { input: "spruce_log", output: "charcoal", time: 10 },
  { input: "raw_beef", output: "cooked_beef", time: 10 },
  { input: "raw_porkchop", output: "cooked_porkchop", time: 10 },
  { input: "raw_chicken", output: "cooked_chicken", time: 10 },
  { input: "netherrack", output: "nether_bricks", time: 8 },
];

/** Burn time in seconds per fuel item. */
export function fuelTime(key: string): number {
  if (key === "coal" || key === "charcoal") return 80;
  if (key.endsWith("_log")) return 15;
  if (key.endsWith("_planks")) return 15;
  if (key === "stick") return 5;
  if (key === "lava_bucket") return 1000;
  return 0;
}

export function smeltFor(input: string): SmeltRecipe | undefined {
  return SMELTING.find((s) => s.input === input);
}
