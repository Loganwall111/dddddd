// Front-end menus. The title screen sits over the spinning panorama; every other menu is its own
// full-screen page (dark dirt background, header band, scrolling list, footer) like Minecraft's options.

import { useEffect, useMemo, useRef, useState, type ReactNode } from "react";
import { DEFAULT_SETTINGS, GRAPHICS_PRESETS, applyPreset, type GraphicsPreset, type Settings } from "../core/settings";
import { db, newWorldId, type Difficulty, type GameMode, type WorldMeta } from "../persistence/db";
import { seedToInt } from "../world/noise";
import { DIMENSIONS } from "../dimensions/dimensions";
import { DEFAULT_CHARACTER, paintPlayerSkin, type CharacterOpts } from "../entities/entities";
import type { WorldType } from "../world/generator";

const SPLASHES = [
  "Now with coloured light!", "Mind the gravel!", "Volcanoes erupt!", "Giant pyramids!", "Seasons change every eight days",
  "Obsidian and flint make a gate", "Creepers hate hugs", "Villagers have opinions", "Walk the aurora", "Take the World Tour!",
];

/** Procedural dark dirt tile used as the menu background (generated once). */
let dirtUrl = "";
function menuDirt(): string {
  if (dirtUrl) return dirtUrl;
  const c = document.createElement("canvas");
  c.width = 16; c.height = 16;
  const g = c.getContext("2d")!;
  const cols = ["#3b2a1d", "#33251a", "#43301f", "#2c2016", "#4a3524"];
  for (let y = 0; y < 16; y++) for (let x = 0; x < 16; x++) {
    let h = (x * 374761393 + y * 668265263) | 0;
    h = Math.imul(h ^ (h >>> 13), 1274126177);
    g.fillStyle = cols[((h >>> 0) % cols.length)];
    g.fillRect(x, y, 1, 1);
  }
  dirtUrl = c.toDataURL("image/png");
  return dirtUrl;
}

export function MCButton(props: { children: ReactNode; onClick?: () => void; disabled?: boolean; wide?: boolean; small?: boolean; className?: string; title?: string }) {
  return (
    <button type="button" title={props.title} disabled={props.disabled} onClick={props.onClick}
      className={`mc-btn ${props.wide ? "mc-wide" : ""} ${props.small ? "mc-small" : ""} ${props.className ?? ""}`}>
      {props.children}
    </button>
  );
}

export function MCSlider(props: { label: string; value: number; min: number; max: number; step?: number; onChange: (v: number) => void; format?: (v: number) => string }) {
  const pct = ((props.value - props.min) / (props.max - props.min)) * 100;
  return (
    <div className="mc-slider" style={{ ["--pct" as string]: `${pct}` }}>
      <input type="range" min={props.min} max={props.max} step={props.step ?? 1} value={props.value} onChange={(e) => props.onChange(Number(e.target.value))} aria-label={props.label} />
      <span className="mc-slider-label">{props.label}: {props.format ? props.format(props.value) : props.value}</span>
    </div>
  );
}

export function MCToggle(props: { label: string; value: boolean; onChange: (v: boolean) => void }) {
  return <MCButton wide onClick={() => props.onChange(!props.value)}>{`${props.label}: ${props.value ? "ON" : "OFF"}`}</MCButton>;
}

/** Legacy panel (still used by in-game overlays like the pause menu). */
export function Frame(props: { title?: string; children: ReactNode; className?: string; footer?: ReactNode }) {
  return (
    <div className={`mc-frame ${props.className ?? ""}`}>
      {props.title && <div className="mc-frame-title">{props.title}</div>}
      <div className="mc-frame-body">{props.children}</div>
      {props.footer && <div className="mc-frame-footer">{props.footer}</div>}
    </div>
  );
}

/** Full-screen Minecraft-style menu page. */
export function MCScreen(props: { title: string; children: ReactNode; footer?: ReactNode; subtitle?: string }) {
  return (
    <div className="mc-screen" style={{ backgroundImage: `url(${menuDirt()})` }}>
      <div className="mc-screen-head">
        <div className="mc-screen-title">{props.title}</div>
        {props.subtitle && <div className="mc-screen-sub">{props.subtitle}</div>}
      </div>
      <div className="mc-screen-list"><div className="mc-screen-inner">{props.children}</div></div>
      <div className="mc-screen-foot">{props.footer}</div>
    </div>
  );
}

// ---- Title screen ----------------------------------------------------------------
export function MainMenu(props: { go: (s: string) => void; onSingleplayer: () => void; onTutorial: () => void }) {
  const splash = useMemo(() => SPLASHES[Math.floor(Math.random() * SPLASHES.length)], []);
  return (
    <div className="title-screen">
      <div className="title-logo" aria-label="AETHERFORGED REINCARNATED">
        <div className="title-main">AETHERFORGED</div>
        <div className="title-sub">REINCARNATED</div>
        <div className="splash">{splash}</div>
      </div>
      <div className="title-buttons">
        <MCButton wide onClick={props.onSingleplayer}>Singleplayer</MCButton>
        <MCButton wide onClick={() => props.go("multiplayer")}>Multiplayer</MCButton>
        <MCButton wide onClick={props.onTutorial}>Tutorial World</MCButton>
        <div className="row-2">
          <MCButton onClick={() => props.go("settings")}>Options...</MCButton>
          <MCButton onClick={() => props.go("character")}>Character...</MCButton>
        </div>
        <div className="row-2">
          <MCButton onClick={() => props.go("dimensions")}>Dimensions...</MCButton>
          <MCButton onClick={() => props.go("controls")}>Controls &amp; Help</MCButton>
        </div>
      </div>
      <div className="title-foot">
        <span>AETHERFORGED Reincarnated · original voxel sandbox</span>
        <button type="button" className="link" onClick={() => props.go("credits")}>Credits</button>
      </div>
    </div>
  );
}

export function InfoScreen(props: { kind: "multiplayer" | "dimensions"; onBack: () => void }) {
  return (
    <MCScreen title={props.kind === "multiplayer" ? "Multiplayer" : "Dimensions"} footer={<MCButton wide onClick={props.onBack}>Done</MCButton>}>
      {props.kind === "multiplayer" ? (
        <p className="muted center">Multiplayer is not available in this build: it needs a game server. Singleplayer works fully offline.</p>
      ) : Object.values(DIMENSIONS).map((d) => (
        <div key={d.id} className="list-row">
          <b>{d.name}</b> <span className={`tag ${d.status}`}>{d.status === "complete" ? "playable" : "prototype"}</span>
          <div className="muted">{d.description}</div>
        </div>
      ))}
    </MCScreen>
  );
}

// ---- World selection ----------------------------------------------------------------
export function WorldSelect(props: { onBack: () => void; onCreate: () => void; onPlay: (w: WorldMeta) => void }) {
  const [worlds, setWorlds] = useState<WorldMeta[]>([]);
  const [status, setStatus] = useState("");
  const [selected, setSelected] = useState<string | null>(null);
  const fileRef = useRef<HTMLInputElement>(null);
  const refresh = () => db.listWorlds().then(setWorlds).catch((e) => setStatus(`Storage error: ${String(e)}`));
  useEffect(() => { void refresh(); }, []);
  const sel = worlds.find((w) => w.id === selected) ?? null;
  return (
    <MCScreen title="Select World" footer={
      <div className="foot-grid">
        <MCButton onClick={() => sel && props.onPlay(sel)} disabled={!sel}>Play Selected World</MCButton>
        <MCButton onClick={props.onCreate}>Create New World</MCButton>
        <MCButton small disabled={!sel} onClick={async () => {
          if (!sel) return;
          const name = window.prompt("Rename world", sel.name);
          if (!name) return;
          await db.putWorld({ ...sel, name });
          void refresh();
        }}>Edit</MCButton>
        <MCButton small disabled={!sel} onClick={async () => {
          if (!sel || !window.confirm(`Delete "${sel.name}"? This cannot be undone.`)) return;
          await db.deleteWorld(sel.id);
          setSelected(null);
          void refresh();
        }}>Delete</MCButton>
        <MCButton small disabled={!sel} onClick={async () => {
          if (!sel) return;
          const json = await db.exportWorld(sel.id);
          const a = document.createElement("a");
          a.href = URL.createObjectURL(new Blob([json], { type: "application/json" }));
          a.download = `${sel.name.replace(/[^a-z0-9]+/gi, "_")}.aetherworld.json`;
          a.click();
          setStatus("Exported world file.");
        }}>Export</MCButton>
        <MCButton small onClick={props.onBack}>Cancel</MCButton>
      </div>
    }>
      {worlds.length === 0 && <div className="muted center">No saved worlds yet. Create one to begin.</div>}
      {worlds.map((w) => (
        <div key={w.id} className={`world-row ${selected === w.id ? "sel" : ""}`} onClick={() => setSelected(w.id)} onDoubleClick={() => props.onPlay(w)}>
          <div className="world-icon" style={{ background: `hsl(${(w.seed >>> 0) % 360} 45% 40%)` }} />
          <div className="world-meta">
            <div className="world-name">{w.name}</div>
            <div className="muted">{new Date(w.lastPlayed).toLocaleString()}</div>
            <div className="muted">{w.mode === "creative" ? "Creative" : "Survival"} · {w.difficulty} · {w.type} · {DIMENSIONS[(w.player?.dimension ?? "overworld") as keyof typeof DIMENSIONS]?.name ?? "Overworld"}</div>
          </div>
        </div>
      ))}
      <div className="center" style={{ marginTop: 10 }}>
        <MCButton small onClick={() => fileRef.current?.click()}>Import world file...</MCButton>
        <input ref={fileRef} type="file" accept="application/json" hidden onChange={async (e) => {
          const f = e.target.files?.[0];
          if (!f) return;
          try { await db.importWorld(await f.text()); setStatus("World imported."); void refresh(); }
          catch (err) { setStatus(`Import failed: ${String(err)}`); }
        }} />
      </div>
      {status && <div className="muted center">{status}</div>}
    </MCScreen>
  );
}

// ---- Create world ----------------------------------------------------------------------
export function CreateWorld(props: { onBack: () => void; onCreated: (w: WorldMeta) => void }) {
  const [tab, setTab] = useState<"game" | "world" | "more">("game");
  const [name, setName] = useState("New World");
  const [seed, setSeed] = useState("");
  const [mode, setMode] = useState<GameMode>("survival");
  const [difficulty, setDifficulty] = useState<Difficulty>("normal");
  const [type, setType] = useState<WorldType>("default");
  const [cheats, setCheats] = useState(false);
  const [busy, setBusy] = useState(false);
  const TYPES: { id: WorldType; label: string }[] = [
    { id: "default", label: "Default" }, { id: "amplified", label: "Amplified" }, { id: "extreme", label: "Extreme Scale" },
    { id: "flat", label: "Superflat" }, { id: "tutorial", label: "Tutorial Town" },
  ];
  const cycle = <T,>(v: T, list: T[]) => list[(list.indexOf(v) + 1) % list.length];
  const create = async () => {
    setBusy(true);
    const meta: WorldMeta = {
      id: newWorldId(), name: name.trim() || "New World", seedText: seed, seed: seedToInt(seed), mode, difficulty, type,
      created: Date.now(), lastPlayed: Date.now(), worldTime: 0, weatherSeed: Math.floor(Math.random() * 1e9), version: 2, cheats,
    };
    await db.putWorld(meta);
    props.onCreated(meta);
  };
  return (
    <MCScreen title="Create New World" footer={
      <div className="foot-grid two">
        <MCButton onClick={create} disabled={busy}>{busy ? "Generating..." : "Create New World"}</MCButton>
        <MCButton onClick={props.onBack}>Cancel</MCButton>
      </div>
    }>
      <div className="mc-tabs">
        {(["game", "world", "more"] as const).map((t) => (
          <button key={t} type="button" className={`mc-tab ${tab === t ? "on" : ""}`} onClick={() => setTab(t)}>{t === "game" ? "Game" : t === "world" ? "World" : "More"}</button>
        ))}
      </div>
      {tab === "game" && (
        <div className="opt-col">
          <label className="mc-field">World Name<input value={name} onChange={(e) => setName(e.target.value)} maxLength={32} /></label>
          <MCButton wide onClick={() => setMode(mode === "survival" ? "creative" : "survival")}>Game Mode: {mode === "survival" ? "Survival" : "Creative"}</MCButton>
          <div className="muted center">{mode === "survival" ? "Search for resources, craft, gain levels, health and hunger." : "Unlimited resources, free flying and instant breaking."}</div>
          <MCButton wide onClick={() => setDifficulty(cycle(difficulty, ["peaceful", "easy", "normal", "hard"] as Difficulty[]))}>Difficulty: {difficulty}</MCButton>
          <MCToggle label="Allow Commands" value={cheats} onChange={setCheats} />
        </div>
      )}
      {tab === "world" && (
        <div className="opt-col">
          <MCButton wide onClick={() => setType(cycle(type, TYPES.map((t) => t.id)))}>World Type: {TYPES.find((t) => t.id === type)?.label}</MCButton>
          <label className="mc-field">Seed for the world generator<input value={seed} onChange={(e) => setSeed(e.target.value)} maxLength={40} placeholder="Leave blank for a random seed" /></label>
          <div className="muted center">Terrain uses legacy-style low/high/selector/depth noise with blended biome heights. The same seed always gives the same world.</div>
        </div>
      )}
      {tab === "more" && (
        <div className="opt-col">
          <div className="muted center">Structures (giant pyramids, obsidian mansions, volcanoes, fossils, villages) are rare and spread out. Dimensions are reached through frame portals.</div>
        </div>
      )}
    </MCScreen>
  );
}

// ---- Options: hub + one page per category -----------------------------------------------------------
type OptPage = "root" | "video" | "quality" | "sound" | "controls" | "access" | "world";

export function SettingsScreen(props: { settings: Settings; onChange: (s: Settings) => void; onBack: () => void; onCharacter?: () => void }) {
  const [page, setPage] = useState<OptPage>("root");
  const s = props.settings;
  const set = (patch: Partial<Settings>) => props.onChange({ ...s, ...patch });
  const cycle = <T,>(v: T, opts: T[]) => opts[(opts.indexOf(v) + 1) % opts.length];
  const done = (label = "Done") => <MCButton wide onClick={() => setPage("root")}>{label}</MCButton>;

  if (page === "root") return (
    <MCScreen title="Options" footer={<MCButton wide onClick={props.onBack}>Done</MCButton>}>
      <div className="opt-grid">
        <MCSlider label="FOV" value={s.fov} min={50} max={110} onChange={(v) => set({ fov: v })} format={(v) => (v === 70 ? "Normal" : `${v}`)} />
        <MCButton onClick={() => set(applyPreset(s, cycle(s.graphics, Object.keys(GRAPHICS_PRESETS) as GraphicsPreset[])))}>Graphics: {s.graphics.toUpperCase()}</MCButton>
        <MCButton onClick={() => setPage("video")}>Video Settings...</MCButton>
        <MCButton onClick={() => setPage("quality")}>Shaders &amp; Effects...</MCButton>
        <MCButton onClick={() => setPage("sound")}>Music &amp; Sounds...</MCButton>
        <MCButton onClick={() => setPage("controls")}>Controls...</MCButton>
        <MCButton onClick={() => setPage("access")}>Accessibility...</MCButton>
        <MCButton onClick={() => setPage("world")}>World &amp; Gameplay...</MCButton>
        {props.onCharacter && <MCButton onClick={props.onCharacter}>Skin Customization...</MCButton>}
        <MCButton onClick={() => props.onChange({ ...DEFAULT_SETTINGS })}>Reset to Defaults</MCButton>
      </div>
    </MCScreen>
  );
  if (page === "video") return (
    <MCScreen title="Video Settings" footer={done()}>
      <div className="opt-grid">
        <MCSlider label="Render Distance" value={s.renderDistance} min={2} max={16} onChange={(v) => set({ renderDistance: v })} format={(v) => `${v} chunks`} />
        <MCSlider label="Max Framerate" value={s.maxFps} min={0} max={240} step={10} onChange={(v) => set({ maxFps: v })} format={(v) => (v === 0 ? "Unlimited" : `${v} fps`)} />
        <MCSlider label="Render Scale" value={Math.round(s.renderScale * 100)} min={50} max={100} step={5} onChange={(v) => set({ renderScale: v / 100 })} format={(v) => `${v}%`} />
        <MCToggle label="Anti-Aliasing (MSAA)" value={s.antialias} onChange={(v) => set({ antialias: v })} />
        <MCToggle label="View Bobbing" value={s.viewBobbing} onChange={(v) => set({ viewBobbing: v })} />
        <MCSlider label="GUI Scale" value={s.hudScale} min={1} max={3} onChange={(v) => set({ hudScale: v })} format={(v) => `${v}x`} />
      </div>
    </MCScreen>
  );
  if (page === "quality") return (
    <MCScreen title="Shaders & Effects" footer={done()}>
      <div className="opt-grid">
        <MCToggle label="Shadows" value={s.shadows} onChange={(v) => set({ shadows: v })} />
        <MCButton onClick={() => set({ shadowMapSize: cycle(s.shadowMapSize, [512, 1024, 2048]) as 512 | 1024 | 2048 })}>Shadow Quality: {s.shadowMapSize}</MCButton>
        <MCToggle label="Water Reflections" value={s.waterReflections} onChange={(v) => set({ waterReflections: v })} />
        <MCButton onClick={() => set({ waterQuality: cycle(s.waterQuality, [0, 1, 2]) as 0 | 1 | 2 })}>Water Quality: {["Low", "Medium", "High"][s.waterQuality]}</MCButton>
        <MCToggle label="Clouds" value={s.volumetricClouds} onChange={(v) => set({ volumetricClouds: v })} />
        <MCToggle label="God Rays" value={s.godRays} onChange={(v) => set({ godRays: v })} />
        <MCToggle label="Bloom" value={s.bloom} onChange={(v) => set({ bloom: v })} />
        <MCToggle label="Ambient Occlusion (SSAO)" value={s.ssao} onChange={(v) => set({ ssao: v })} />
        <MCToggle label="Aurora Borealis" value={s.aurora} onChange={(v) => set({ aurora: v })} />
        <MCToggle label="Stars" value={s.stars} onChange={(v) => set({ stars: v })} />
        <MCToggle label="Particles" value={s.particles} onChange={(v) => set({ particles: v })} />
      </div>
    </MCScreen>
  );
  if (page === "sound") return (
    <MCScreen title="Music & Sound Options" footer={done()}>
      <div className="opt-col">
        <MCSlider label="Master Volume" value={Math.round(s.volumeMaster * 100)} min={0} max={100} onChange={(v) => set({ volumeMaster: v / 100 })} format={(v) => `${v}%`} />
        <MCSlider label="Music" value={Math.round(s.volumeMusic * 100)} min={0} max={100} onChange={(v) => set({ volumeMusic: v / 100 })} format={(v) => `${v}%`} />
        <MCSlider label="Blocks & Creatures" value={Math.round(s.volumeSfx * 100)} min={0} max={100} onChange={(v) => set({ volumeSfx: v / 100 })} format={(v) => `${v}%`} />
        <MCSlider label="Ambient & Weather" value={Math.round(s.volumeAmbient * 100)} min={0} max={100} onChange={(v) => set({ volumeAmbient: v / 100 })} format={(v) => `${v}%`} />
        <MCToggle label="Subtitles" value={s.subtitles} onChange={(v) => set({ subtitles: v })} />
      </div>
    </MCScreen>
  );
  if (page === "controls") return (
    <MCScreen title="Controls" footer={done()}>
      <div className="opt-grid">
        <MCSlider label="Mouse Sensitivity" value={Math.round(s.sensitivity * 100)} min={20} max={300} step={5} onChange={(v) => set({ sensitivity: v / 100 })} format={(v) => `${v}%`} />
        <MCToggle label="Invert Mouse" value={s.invertY} onChange={(v) => set({ invertY: v })} />
        <MCToggle label="Sneak: Hold" value={!s.crouchToggle} onChange={(v) => set({ crouchToggle: !v })} />
      </div>
      <ControlsTable />
    </MCScreen>
  );
  if (page === "access") return (
    <MCScreen title="Accessibility Settings" footer={done()}>
      <div className="opt-grid">
        <MCToggle label="Reduced Motion" value={s.reducedMotion} onChange={(v) => set({ reducedMotion: v, viewBobbing: v ? false : s.viewBobbing })} />
        <MCSlider label="Screen Effect Scale" value={Math.round(s.screenShake * 100)} min={0} max={100} onChange={(v) => set({ screenShake: v / 100 })} format={(v) => `${v}%`} />
        <MCToggle label="High Contrast HUD" value={s.highContrast} onChange={(v) => set({ highContrast: v })} />
        <MCToggle label="Colour-safe Tints" value={s.colorblindFriendlyTints} onChange={(v) => set({ colorblindFriendlyTints: v })} />
      </div>
    </MCScreen>
  );
  return (
    <MCScreen title="World & Gameplay" footer={done()}>
      <div className="opt-grid">
        <MCSlider label="Day Length" value={s.dayLengthMinutes} min={4} max={40} onChange={(v) => set({ dayLengthMinutes: v })} format={(v) => `${v} min`} />
        <MCToggle label="Weather" value={s.weatherEnabled} onChange={(v) => set({ weatherEnabled: v })} />
        <MCToggle label="Seasons" value={s.seasonsEnabled} onChange={(v) => set({ seasonsEnabled: v })} />
      </div>
    </MCScreen>
  );
}

function ControlsTable() {
  const rows: [string, string][] = [
    ["W A S D", "Move"], ["Space", "Jump / swim / fly (double-tap in creative)"], ["Shift", "Sprint"], ["Ctrl", "Sneak (edge-safe)"],
    ["Left click", "Mine / attack"], ["Right click", "Place / use / open / talk / prime TNT"], ["Middle click", "Pick block (creative)"],
    ["1-9 · Wheel", "Hotbar"], ["E", "Inventory"], ["Q", "Drop item"], ["F", "Third person"], ["G", "Fly (creative)"], ["F3", "Debug"], ["Esc", "Pause / exit tour"],
  ];
  return (
    <table className="controls-table"><tbody>
      {rows.map(([k, v]) => (<tr key={k}><td><kbd>{k}</kbd></td><td>{v}</td></tr>))}
    </tbody></table>
  );
}

// ---- Character creator ----------------------------------------------------------------
const PALETTES = {
  skin: ["#f1d2b5", "#e0b08a", "#c79a72", "#a8744c", "#7a5238", "#4d3222"],
  eyes: ["#3a6fbf", "#3f8a4a", "#4a3420", "#2a2a2a", "#5ab0e0", "#8a5ac0"],
  hair: ["#1c1410", "#3b2a1b", "#5a3b22", "#9a6a3a", "#d8b878", "#eee2c8", "#8a2a1a", "#7a7a7a", "#2a4fb4", "#d46ab0"],
  clothes: ["#3f7ad0", "#c04040", "#40a060", "#e0b040", "#8a5ac0", "#f0f0f0", "#303030", "#e07a30", "#f080b0"],
  pants: ["#2c3a7a", "#303030", "#6b4a2a", "#4a5a68", "#8a2a2a", "#3f6a40", "#c8b890", "#f0f0f0"],
  shoes: ["#2a2a2a", "#6b4a2a", "#f0f0f0", "#8a2a2a", "#2a4fb4", "#3f6a40"],
};

export function loadCharacter(): CharacterOpts {
  try {
    const raw = localStorage.getItem("aetherforged.character.v1");
    if (raw) return { ...DEFAULT_CHARACTER, ...(JSON.parse(raw) as Partial<CharacterOpts>) };
  } catch { /* ignore */ }
  return { ...DEFAULT_CHARACTER };
}

export function CharacterScreen(props: { opts: CharacterOpts; onChange: (c: CharacterOpts) => void; onBack: () => void }) {
  const c = props.opts;
  const set = (patch: Partial<CharacterOpts>) => props.onChange({ ...c, ...patch });
  const canvasRef = useRef<HTMLCanvasElement>(null);
  useEffect(() => {
    const cv = canvasRef.current;
    if (!cv) return;
    const g = cv.getContext("2d")!;
    g.imageSmoothingEnabled = false;
    g.clearRect(0, 0, cv.width, cv.height);
    const skin = paintPlayerSkin(c);
    const s = 6, ox = 34, oy = 14;
    const put = (sx: number, sy: number, w: number, h: number, dx: number, dy: number) => g.drawImage(skin, sx, sy, w, h, ox + dx * s, oy + dy * s, w * s, h * s);
    put(8, 8, 8, 8, 0, 0);
    put(20, 20, 8, 12, 0, 8);
    put(44, 20, 4, 12, -4, 8);
    put(36, 52, 4, 12, 8, 8);
    put(4, 20, 4, 12, 0, 20);
    put(20, 52, 4, 12, 4, 20);
  }, [c]);
  const swatch = (list: string[], value: string, onPick: (v: string) => void) => (
    <div className="swatches">
      {list.map((col) => <button key={col} type="button" className={`swatch ${value === col ? "on" : ""}`} style={{ background: col }} onClick={() => onPick(col)} aria-label={col} />)}
    </div>
  );
  const pick = (a: string[]) => a[Math.floor(Math.random() * a.length)];
  return (
    <MCScreen title="Skin Customization" footer={
      <div className="foot-grid three">
        <MCButton onClick={() => set({ skin: pick(PALETTES.skin), eyes: pick(PALETTES.eyes), hair: pick(PALETTES.hair), top: pick(PALETTES.clothes), pants: pick(PALETTES.pants), shoes: pick(PALETTES.shoes) })}>Randomize</MCButton>
        <MCButton onClick={() => props.onChange({ ...DEFAULT_CHARACTER })}>Reset</MCButton>
        <MCButton onClick={() => { localStorage.setItem("aetherforged.character.v1", JSON.stringify(c)); props.onBack(); }}>Done</MCButton>
      </div>
    }>
      <div className="char-layout">
        <div className="char-preview"><canvas ref={canvasRef} width={164} height={220} /></div>
        <div className="char-form">
          <label className="mc-field">Name<input value={c.name} maxLength={16} onChange={(e) => set({ name: e.target.value })} /></label>
          <div className="form-row"><span>Skin</span>{swatch(PALETTES.skin, c.skin, (v) => set({ skin: v }))}</div>
          <div className="form-row"><span>Eyes</span>{swatch(PALETTES.eyes, c.eyes, (v) => set({ eyes: v }))}</div>
          <div className="form-row"><span>Hair</span>{swatch(PALETTES.hair, c.hair, (v) => set({ hair: v }))}</div>
          <MCButton wide onClick={() => set({ hairStyle: c.hairStyle === "short" ? "ponytail" : c.hairStyle === "ponytail" ? "buzz" : "short" })}>Hairstyle: {c.hairStyle}</MCButton>
          <div className="form-row"><span>Top</span>{swatch(PALETTES.clothes, c.top, (v) => set({ top: v }))}</div>
          <div className="form-row"><span>Pants</span>{swatch(PALETTES.pants, c.pants, (v) => set({ pants: v }))}</div>
          <div className="form-row"><span>Shoes</span>{swatch(PALETTES.shoes, c.shoes, (v) => set({ shoes: v }))}</div>
        </div>
      </div>
    </MCScreen>
  );
}

export function ControlsScreen(props: { onBack: () => void }) {
  return (
    <MCScreen title="Controls & Help" footer={<MCButton wide onClick={props.onBack}>Done</MCButton>}>
      <ControlsTable />
      <h3>Portals</h3>
      <p className="muted">Nether: obsidian frame (2×3 interior) lit with Flint and Steel. Prismatic Sift: Prism Glass frame. End gate: Ancient Frame blocks.</p>
      <h3>Tips</h3>
      <p className="muted">Torches and coloured lamps tint nearby blocks. Sand and gravel fall when unsupported. Volcanoes erupt every few minutes when you are nearby. Try the World Tour from the pause menu.</p>
    </MCScreen>
  );
}

export function CreditsScreen(props: { onBack: () => void }) {
  return (
    <MCScreen title="Credits" footer={<MCButton wide onClick={props.onBack}>Done</MCButton>}>
      <p className="center">AETHERFORGED: REINCARNATED</p>
      <p className="muted center">Built with Babylon.js, React and Vite. All textures, icons, sounds and models are generated procedurally at runtime.</p>
      <p className="muted center">Inspired by classic block-building games; no proprietary code, art or music is used.</p>
    </MCScreen>
  );
}
