// In-game interface: HUD, hotbar, inventory / crafting / furnace / chest / creative palette, pause, death,
// dialogue, debug overlay and the terrain-generation progress screen (dot grid, as in the reference).

import { useEffect, useMemo, useState, type MouseEvent as RMouseEvent } from "react";
import { Game, iconDataUrl, type Snapshot } from "../core/Game";
import type { Slot } from "../inventory/inventory";
import { itemDef, itemName, CREATIVE_TABS, maxStackOf, durabilityOf } from "../items/items";
import { MCButton, Frame, MCSlider } from "./Menus";
import { DEFAULT_SETTINGS, type Settings } from "../core/settings";

function SlotView(props: {
  stack: Slot;
  onDown?: (e: RMouseEvent) => void;
  selected?: boolean;
  big?: boolean;
  label?: string;
  onHover?: (s: Slot) => void;
  onLeave?: () => void;
  dim?: boolean;
}) {
  const s = props.stack;
  const def = s ? itemDef(s.key) : undefined;
  const dur = s && durabilityOf(s.key) ? 1 - (s.damage ?? 0) / durabilityOf(s.key) : 1;
  return (
    <div
      className={`slot ${props.selected ? "sel" : ""} ${props.big ? "big" : ""} ${props.dim ? "dim" : ""}`}
      onMouseDown={props.onDown}
      onContextMenu={(e) => e.preventDefault()}
      onMouseEnter={() => props.onHover?.(s)}
      onMouseLeave={() => props.onLeave?.()}
      role="button"
      aria-label={s ? `${def?.name ?? s.key} x${s.count}` : props.label ?? "empty slot"}
    >
      {s && <img src={iconDataUrl(s.key)} alt="" draggable={false} />}
      {s && s.count > 1 && <span className="count">{s.count}</span>}
      {s && dur < 1 && (
        <div className="durbar"><div style={{ width: `${Math.max(0, dur) * 100}%`, background: dur > 0.5 ? "#4ad04a" : dur > 0.25 ? "#e0c040" : "#e04040" }} /></div>
      )}
    </div>
  );
}

function Tooltip({ stack }: { stack: Slot }) {
  if (!stack) return null;
  const def = itemDef(stack.key);
  return (
    <div className="tooltip">
      <div className="tt-name">{def?.name ?? itemName(stack.key)}</div>
      {def?.lore && <div className="tt-lore">{def.lore}</div>}
      {def?.tool && <div className="tt-stat">Tier {def.tool.tier} · {def.tool.type} · dmg {def.tool.damage}</div>}
      {def?.armor && <div className="tt-stat">Defense {def.armor.defense} · {def.armor.slot}</div>}
      {def?.food && <div className="tt-stat">Restores {def.food.hunger} hunger</div>}
      {durabilityOf(stack.key) > 0 && <div className="tt-stat">Durability {durabilityOf(stack.key) - (stack.damage ?? 0)}/{durabilityOf(stack.key)}</div>}
    </div>
  );
}

export function GameOverlay(props: { game: Game; snap: Snapshot; settings: Settings; onSettingsChange: (s: Settings) => void; onTitle: () => void; onOpenSettings: () => void }) {
  const { game, snap } = props;
  const [hover, setHover] = useState<Slot>(null);
  const [mouse, setMouse] = useState({ x: 0, y: 0 });
  const [tab, setTab] = useState<string>("all");
  const [search, setSearch] = useState("");
  const [creativeLocalPage, setCreativeLocalPage] = useState(0);
  const scale = snap.hudScale ?? props.settings.hudScale ?? 2;
  void scale;

  const onMove = (e: React.MouseEvent) => setMouse({ x: e.clientX, y: e.clientY });

  if (snap.mode !== "world") return null;

  if (snap.loading && !snap.ready) {
    return <LoadingScreen label={snap.loading.text} ready={snap.loading.ready} total={snap.loading.total} />;
  }

  if (snap.tour) {
    return (
      <div className="tour">
        <div className="tour-bar top" />
        <div className="tour-bar bottom" />
        <div className="tour-card">
          <div className="tour-kicker">WORLD TOUR · {snap.tour.idx + 1} / {snap.tour.total}</div>
          <div className="tour-title">{snap.tour.label}</div>
        </div>
        <div className="tour-hint">Press Esc to end the tour</div>
        <div className="tour-fade" style={{ opacity: snap.tour.fade }} />
      </div>
    );
  }

  const hudCls = props.settings.highContrast ? "hud hc" : "hud";
  const hp = Math.max(0, snap.hp);
  const isOpen = snap.screen !== "none";

  return (
    <div className={hudCls} onMouseMove={onMove}>
      {snap.underwater && <div className={`underwater ${snap.underwater.includes("toxic") ? "tox" : snap.underwater.includes("sift") ? "sift" : ""}`} />}
      {snap.portalProgress > 0 && <div className="portal-tint" style={{ opacity: snap.portalProgress * 0.7 }} />}
      {!isOpen && (
        <>
          <div className="crosshair" aria-hidden="true" />
          {snap.cracks >= 0 && snap.targetName && <div className="target-name">{snap.targetName}</div>}
          <div className="top-left">
            <div className="dimtag">{snap.dimName} · {snap.timeText} · {snap.season} · {snap.weather}</div>
            {snap.creative && <div className="dimtag">Creative{snap.flying ? " · flying" : ""}</div>}
          </div>
          {snap.tutorial && (
            <div className={`tutorial ${snap.tutorial.done ? "done" : ""}`}>
              <div className="tutorial-head">Tutorial {Math.min(snap.tutorial.step + 1, snap.tutorial.total)}/{snap.tutorial.total}</div>
              <div className="tutorial-text">{snap.tutorial.text}</div>
              <div className="tutorial-bar"><div style={{ width: `${(snap.tutorial.step / snap.tutorial.total) * 100}%` }} /></div>
            </div>
          )}
          <div className="messages">
            {snap.messages.slice(-5).map((m) => (<div key={m.id} className="msg">{m.text}</div>))}
          </div>
          <div className="hud-bottom">
            {!snap.creative && (
              <div className="stats">
                <div className="hearts" title={`Health ${hp.toFixed(1)}/20`}>
                  {Array.from({ length: 10 }).map((_, i) => {
                    const v = hp - i * 2;
                    return <span key={i} className={`heart ${v >= 2 ? "full" : v >= 1 ? "half" : "empty"}`} />;
                  })}
                  {snap.armor > 0 && <span className="armor-pips">{snap.armor}</span>}
                </div>
                <div className="hearts hunger" title={`Hunger ${snap.hunger}/20`}>
                  {Array.from({ length: 10 }).map((_, i) => (<span key={i} className={`food ${snap.hunger - i * 2 >= 2 ? "full" : snap.hunger - i * 2 >= 1 ? "half" : "empty"}`} />))}
                </div>
                {snap.air < 300 && <div className="air">Air {Math.round((snap.air / 300) * 100)}%</div>}
              </div>
            )}
            <div className="hotbar">
              {snap.hotbar.map((s, i) => (
                <SlotView key={i} stack={s} selected={snap.selected === i} onHover={setHover} onLeave={() => setHover(null)} />
              ))}
            </div>
            {!snap.creative && (
              <div className="xpbar"><div style={{ width: `${Math.min(100, ((snap.xp - Math.pow(snap.level, 2)) / Math.max(1, Math.pow(snap.level + 1, 2) - Math.pow(snap.level, 2))) * 100)}%` }} /><span>{snap.level}</span></div>
            )}
          </div>
          {snap.debug && (
            <div className="debug">
              <div>{snap.dimName} · {snap.biome || "—"}</div>
              <div>XYZ {snap.pos.x}, {snap.pos.y}, {snap.pos.z}</div>
              <div>FPS {snap.fps.toFixed(0)} · Seed {snap.seed} ({snap.seedText || "random"})</div>
              <div>Hostiles {snap.hostileCount} · Weather {snap.weather} · {snap.season}</div>
              <div>Dimension status: {snap.dimStatus}</div>
            </div>
          )}
          {snap.dialogue && (
            <div className="dialogue">
              <b>{snap.dialogue.name}</b>
              <p>{snap.dialogue.text}</p>
              <span className="muted">Press E or Esc to continue</span>
            </div>
          )}
          {!snap.pointerLocked && <div className="click-hint" onClick={() => game.requestPointerLock()}>Click to play</div>}
        </>
      )}

      {snap.screen === "inventory" && (
        <div className="overlay" onMouseMove={onMove}>
          <div className="panel-row">
            <div className="inv-panel">
              <div className="panel-title">Crafting</div>
              <div className="craft-row">
                <div className="craft-grid g2">
                  {[0, 1, 2, 3].map((i) => (<SlotView key={i} stack={snap.craftGrid[i]} onDown={(e) => { e.preventDefault(); game.clickSlot("craft", i + 1, e.button === 2 ? 2 : 0, e.shiftKey); }} />))}
                </div>
                <div className="arrow">→</div>
                <SlotView big stack={snap.craftOut} label="output" onDown={(e) => { e.preventDefault(); game.clickSlot("craft", 0, e.button === 2 ? 2 : 0, e.shiftKey); }} />
              </div>
              <div className="panel-title small">Armour &amp; Offhand</div>
              <div className="armour-col">
                {[36, 37, 38, 39, 40].map((i) => (<SlotView key={i} stack={snap.inv[i]} label={["helmet", "chestplate", "leggings", "boots", "offhand"][i - 36]} onDown={(e) => { e.preventDefault(); game.clickSlot("inv", i, e.button === 2 ? 2 : 0, e.shiftKey); }} onHover={setHover} onLeave={() => setHover(null)} />))}
              </div>
              <div className="panel-title small">Inventory</div>
              <InvGrid snap={snap} game={game} onHover={setHover} setHover={setHover} />
            </div>
            {snap.creative && (
              <CreativePalette game={game} tab={tab} setTab={setTab} search={search} setSearch={setSearch} page={creativeLocalPage} setPage={setCreativeLocalPage} setHover={setHover} />
            )}
          </div>
          <div className="overlay-foot"><MCButton onClick={() => game.closeScreen()}>Close (E)</MCButton></div>
        </div>
      )}

      {(snap.screen === "crafting") && (
        <div className="overlay">
          <div className="panel-row">
            <div className="inv-panel">
              <div className="panel-title">Crafting Table</div>
              <div className="craft-row">
                <div className="craft-grid g3">
                  {[0, 1, 2, 3, 4, 5, 6, 7, 8].map((i) => (<SlotView key={i} stack={snap.craftGrid[i]} onDown={(e) => { e.preventDefault(); game.clickSlot("craft", i + 1, e.button === 2 ? 2 : 0, e.shiftKey); }} />))}
                </div>
                <div className="arrow">→</div>
                <SlotView big stack={snap.craftOut} label="output" onDown={(e) => { e.preventDefault(); game.clickSlot("craft", 0, e.button === 2 ? 2 : 0, e.shiftKey); }} />
              </div>
              <div className="panel-title small">Inventory</div>
              <InvGrid snap={snap} game={game} onHover={setHover} setHover={setHover} />
            </div>
          </div>
          <div className="overlay-foot"><MCButton onClick={() => game.closeScreen()}>Close (E)</MCButton></div>
        </div>
      )}

      {snap.screen === "furnace" && snap.container && (
        <div className="overlay">
          <div className="panel-row">
            <div className="inv-panel">
              <div className="panel-title">Furnace</div>
              <div className="furnace-row">
                <div className="fcol">
                  <SlotView stack={snap.container.slots[0]} label="input" onDown={(e) => { e.preventDefault(); game.clickSlot("container", 0, e.button === 2 ? 2 : 0, e.shiftKey); }} />
                  <div className="flame"><div style={{ height: `${snap.container.burnMax ? (snap.container.burn / snap.container.burnMax) * 100 : 0}%` }} /></div>
                  <SlotView stack={snap.container.slots[1]} label="fuel" onDown={(e) => { e.preventDefault(); game.clickSlot("container", 1, e.button === 2 ? 2 : 0, e.shiftKey); }} />
                </div>
                <div className="progress"><div style={{ width: `${(snap.container.cook / Math.max(0.1, snap.container.cookMax)) * 100}%` }} /></div>
                <SlotView big stack={snap.container.slots[2]} label="result" onDown={(e) => { e.preventDefault(); game.clickSlot("container", 2, e.button === 2 ? 2 : 0, e.shiftKey); }} />
              </div>
              <div className="panel-title small">Inventory</div>
              <InvGrid snap={snap} game={game} onHover={setHover} setHover={setHover} />
            </div>
          </div>
          <div className="overlay-foot"><MCButton onClick={() => game.closeScreen()}>Close (E)</MCButton></div>
        </div>
      )}

      {snap.screen === "chest" && snap.container && (
        <div className="overlay">
          <div className="panel-row">
            <div className="inv-panel">
              <div className="panel-title">Chest</div>
              <div className="grid9">
                {snap.container.slots.map((s, i) => (<SlotView key={i} stack={s} onDown={(e) => { e.preventDefault(); game.clickSlot("container", i, e.button === 2 ? 2 : 0, e.shiftKey); }} onHover={setHover} onLeave={() => setHover(null)} />))}
              </div>
              <div className="panel-title small">Inventory</div>
              <InvGrid snap={snap} game={game} onHover={setHover} setHover={setHover} />
            </div>
          </div>
          <div className="overlay-foot"><MCButton onClick={() => game.closeScreen()}>Close (E)</MCButton></div>
        </div>
      )}

      {snap.screen === "pause" && (
        <div className="overlay pause">
          <Frame title={`Game Menu — ${snap.worldName}`} className="pause-frame">
            <div className="pause-buttons">
              <MCButton wide onClick={() => game.closeScreen()}>Back to Game</MCButton>
              <MCButton wide onClick={() => game.startTour()}>World Tour</MCButton>
              <MCButton wide onClick={() => props.onOpenSettings()}>Options...</MCButton>
              <MCButton wide onClick={() => game.setCreative(!snap.creative)}>{snap.creative ? "Switch to Survival" : "Switch to Creative"}</MCButton>
              <MCButton wide onClick={() => game.toggleThirdPerson()}>{snap.thirdPerson ? "First-person view" : "Third-person view"}</MCButton>
              <MCButton wide onClick={() => game.setDebug(!snap.debug)}>Debug overlay: {snap.debug ? "ON" : "OFF"}</MCButton>
              <MCButton wide onClick={() => void game.saveNow()}>Save Game</MCButton>
              <MCButton wide onClick={() => void game.exitToMenu().then(props.onTitle)}>Save and Quit to Title</MCButton>
            </div>
            <div className="pause-quick">
              <MCSlider label="Render distance" value={props.settings.renderDistance} min={2} max={16} onChange={(v) => props.onSettingsChange({ ...props.settings, renderDistance: v })} format={(v) => `${v}`} />
            </div>
          </Frame>
        </div>
      )}

      {snap.screen === "dead" && (
        <div className="overlay death">
          <div className="death-title">You died!</div>
          <div className="muted">Your items were left where you fell.</div>
          <div className="death-buttons">
            <MCButton wide onClick={() => game.respawn()}>Respawn</MCButton>
            <MCButton wide onClick={() => void game.exitToMenu().then(props.onTitle)}>Save and Quit to Title</MCButton>
          </div>
        </div>
      )}

      {snap.screen !== "none" && snap.screen !== "dead" && snap.screen !== "pause" && snap.screen !== "dialogue" && hover && (
        <div className="tt-follow" style={{ left: mouse.x + 14, top: mouse.y + 10 }}><Tooltip stack={hover} /></div>
      )}
      {snap.screen === "inventory" && snap.cursor && (
        <div className="cursor-item" style={{ left: mouse.x - 16, top: mouse.y - 16 }}>
          <img src={iconDataUrl(snap.cursor.key)} alt="" />
          {snap.cursor.count > 1 && <span className="count">{snap.cursor.count}</span>}
        </div>
      )}
      {snap.screen !== "none" && snap.screen !== "dead" && snap.cursor && snap.screen !== "pause" && snap.screen !== "inventory" && (
        <div className="cursor-item" style={{ left: mouse.x - 16, top: mouse.y - 16 }}>
          <img src={iconDataUrl(snap.cursor.key)} alt="" />
          {snap.cursor.count > 1 && <span className="count">{snap.cursor.count}</span>}
        </div>
      )}
      {snap.screen !== "none" && hover && snap.screen !== "dead" && snap.screen !== "pause" && <div className="tt-follow" style={{ left: mouse.x + 14, top: mouse.y + 10 }}><Tooltip stack={hover} /></div>}
      {snap.screen === "inventory" && hover && <div className="tt-follow" style={{ left: mouse.x + 14, top: mouse.y + 10 }}><Tooltip stack={hover} /></div>}
    </div>
  );
}

function InvGrid(props: { snap: Snapshot; game: Game; onHover: (s: Slot) => void; setHover: (s: Slot) => void }) {
  const { snap, game } = props;
  return (
    <>
      <div className="grid9 main">
        {snap.inv.slice(9, 36).map((s, i) => (
          <SlotView key={i + 9} stack={s} onHover={props.onHover} onLeave={() => props.setHover(null)} onDown={(e) => { e.preventDefault(); game.clickSlot("inv", i + 9, e.button === 2 ? 2 : 0, e.shiftKey); }} />
        ))}
      </div>
      <div className="grid9 hot">
        {snap.inv.slice(0, 9).map((s, i) => (
          <SlotView key={i} stack={s} selected={snap.selected === i} onHover={props.onHover} onLeave={() => props.setHover(null)} onDown={(e) => { e.preventDefault(); game.clickSlot("inv", i, e.button === 2 ? 2 : 0, e.shiftKey); }} />
        ))}
      </div>
    </>
  );
}

function CreativePalette(props: { game: Game; tab: string; setTab: (t: string) => void; search: string; setSearch: (s: string) => void; page: number; setPage: (n: number) => void; setHover: (s: Slot) => void }) {
  const { game } = props;
  const keys = useMemo(() => game.creativeKeys(props.tab, props.search), [game, props.tab, props.search]);
  const perPage = 45;
  const pages = Math.max(1, Math.ceil(keys.length / perPage));
  const page = Math.min(props.page, pages - 1);
  const slice = keys.slice(page * perPage, page * perPage + perPage);
  return (
    <div className="inv-panel creative">
      <div className="panel-title">Creative Inventory</div>
      <input className="search" placeholder="Search items..." value={props.search} onChange={(e) => props.setSearch(e.target.value)} />
      <div className="tabs wrap">
        {CREATIVE_TABS.map((t) => (<button key={t.id} type="button" className={`tab ${props.tab === t.id ? "on" : ""}`} onClick={() => props.setTab(t.id)}>{t.label}</button>))}
      </div>
      <div className="grid9 palette">
        {slice.map((k) => {
          const def = itemDef(k);
          return (
            <SlotView
              key={k}
              stack={{ key: k, count: maxStackOf(k) }}
              onHover={(s) => props.setHover(s)}
              onLeave={() => props.setHover(null)}
              onDown={(e) => { e.preventDefault(); game.clickSlot("creative", keys.indexOf(k), e.button === 2 ? 2 : 0, e.shiftKey); }}
              label={def?.name}
            />
          );
        })}
      </div>
      <div className="pager">
        <MCButton small onClick={() => props.setPage(Math.max(0, page - 1))}>&lt;</MCButton>
        <span>{page + 1} / {pages} · {keys.length} items</span>
        <MCButton small onClick={() => props.setPage(Math.min(pages - 1, page + 1))}>&gt;</MCButton>
      </div>
    </div>
  );
}

function LoadingScreen(props: { label: string; ready: number; total: number }) {
  const cells = 15;
  const pct = props.total ? Math.round((props.ready / props.total) * 100) : 0;
  const R = cells / 2;
  const grid: { on: boolean; inside: boolean }[] = [];
  for (let y = 0; y < cells; y++) for (let x = 0; x < cells; x++) {
    const dx = x - R + 0.5, dy = y - R + 0.5;
    const inside = dx * dx + dy * dy <= R * R;
    const idx = y * cells + x;
    grid.push({ inside, on: inside && idx < (cells * cells) * (props.ready / Math.max(1, props.total)) });
  }
  return (
    <div className="loading">
      <div className="loading-title">Generating Terrain</div>
      <div className="loading-pct">{pct}%</div>
      <div className="dot-grid" style={{ gridTemplateColumns: `repeat(${cells}, 1fr)` }}>
        {grid.map((c, i) => (<i key={i} className={c.inside ? (c.on ? "on" : "off") : "none"} />))}
      </div>
      <div className="muted">{props.label} · {props.ready}/{props.total} chunks generated</div>
    </div>
  );
}

export { DEFAULT_SETTINGS };
