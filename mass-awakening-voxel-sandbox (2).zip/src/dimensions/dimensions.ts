// Dimension registry + frame-based portal logic (Minecraft-style: build a frame, ignite it, step through).

import type { DimId } from "../world/generator";
import { BID, blockIdByKey } from "../blocks/blocks";

export interface SkyPreset {
  kind: "overworld" | "nether" | "end" | "sift";
  sunVisible: boolean;
  cloudsAllowed: boolean;
  weatherAllowed: boolean;
  starsAlways: boolean;
  auroraAllowed: boolean;
  rainbowAllowed: boolean;
  fog: [number, number, number];
  fogDensity: number;
  ambient: [number, number, number];
  ambientIntensity: number;
  zenith: [number, number, number];
  horizon: [number, number, number];
  label: string;
}

export interface DimensionDef {
  id: DimId;
  name: string;
  description: string;
  sky: SkyPreset;
  spawnFallbackY: number;
  coordScale: number; // overworld <-> nether scale
  status: "complete" | "prototype";
}

export const DIMENSIONS: Record<DimId, DimensionDef> = {
  overworld: {
    id: "overworld",
    name: "Overworld",
    description: "Biomes, villages, rivers, oceans and the sky. Seasons and weather apply here.",
    spawnFallbackY: 90,
    coordScale: 1,
    status: "complete",
    sky: {
      kind: "overworld", sunVisible: true, cloudsAllowed: true, weatherAllowed: true, starsAlways: false,
      auroraAllowed: true, rainbowAllowed: true, fog: [0.72, 0.84, 0.92], fogDensity: 0.0038,
      ambient: [0.6, 0.7, 0.9], ambientIntensity: 0.55, zenith: [0.22, 0.47, 0.86], horizon: [0.7, 0.85, 0.98], label: "Overworld",
    },
  },
  nether: {
    id: "nether",
    name: "The Nether",
    description: "A volcanic realm of lava oceans, basalt deltas, glowing fungi and fortress bridges.",
    spawnFallbackY: 70,
    coordScale: 8,
    status: "complete",
    sky: {
      kind: "nether", sunVisible: false, cloudsAllowed: false, weatherAllowed: false, starsAlways: false,
      auroraAllowed: false, rainbowAllowed: false, fog: [0.28, 0.07, 0.05], fogDensity: 0.011,
      ambient: [1, 0.5, 0.25], ambientIntensity: 0.7, zenith: [0.25, 0.04, 0.03], horizon: [0.5, 0.12, 0.06], label: "Nether",
    },
  },
  end: {
    id: "end",
    name: "The End",
    description: "Floating end-stone islands above a void, obsidian pillars and crystal towers. Prototype: no dragon boss yet.",
    spawnFallbackY: 70,
    coordScale: 1,
    status: "prototype",
    sky: {
      kind: "end", sunVisible: false, cloudsAllowed: false, weatherAllowed: false, starsAlways: true,
      auroraAllowed: false, rainbowAllowed: false, fog: [0.06, 0.03, 0.1], fogDensity: 0.006,
      ambient: [0.6, 0.5, 0.9], ambientIntensity: 0.45, zenith: [0.03, 0.01, 0.07], horizon: [0.12, 0.06, 0.2], label: "End",
    },
  },
  sift: {
    id: "sift",
    name: "The Prismatic Sift",
    description: "Teal skies painted with aurora, prismatic stone and rainbow water that stings. Prototype: scripted events pending.",
    spawnFallbackY: 120,
    coordScale: 1,
    status: "prototype",
    sky: {
      kind: "sift", sunVisible: true, cloudsAllowed: true, weatherAllowed: true, starsAlways: true,
      auroraAllowed: true, rainbowAllowed: true, fog: [0.3, 0.7, 0.7], fogDensity: 0.0026,
      ambient: [0.7, 1, 0.95], ambientIntensity: 0.6, zenith: [0.05, 0.42, 0.45], horizon: [0.45, 0.92, 0.85], label: "Sift",
    },
  },
};

export const DIM_ORDER: DimId[] = ["overworld", "nether", "end", "sift"];

/** Frame blocks that light each portal type. */
const FRAME_FOR: Record<string, DimId> = {
  obsidian: "nether",
  prism_glass: "sift",
  portal_frame: "end",
};

export const PORTAL_BLOCK = BID.nether_portal;

export interface PortalFrame {
  minX: number;
  maxX: number;
  minY: number;
  maxY: number;
  z: number; // plane of the portal (x-axis aligned, or z-axis if axis==='z')
  axis: "x" | "z";
  frameKey: string;
}

type GetBlock = (x: number, y: number, z: number) => number;

/** Searches for a rectangular frame (interior 2..21 wide, 3..21 tall) around a point. Returns the interior bounds. */
export function findFrameInterior(getBlock: GetBlock, x: number, y: number, z: number, frameKey: string, axis: "x" | "z"): PortalFrame | null {
  const frameId = blockIdByKey(frameKey);
  const at = (dx: number, dy: number): number => (axis === "x" ? getBlock(x + dx, y + dy, z) : getBlock(x, y + dy, z + dx));
  // expand to find walls on left/right
  let left = 0, right = 0, bottom = 0, top = 0;
  while (left < 21 && at(-left - 1, 0) !== frameId && (at(-left - 1, 0) === 0 || at(-left - 1, 0) === PORTAL_BLOCK)) left++;
  while (right < 21 && at(right + 1, 0) !== frameId && (at(right + 1, 0) === 0 || at(right + 1, 0) === PORTAL_BLOCK)) right++;
  if (at(-left - 1, 0) !== frameId || at(right + 1, 0) !== frameId) return null;
  // scan down for the floor
  while (bottom < 21 && (at(0, -bottom - 1) === 0 || at(0, -bottom - 1) === PORTAL_BLOCK)) bottom++;
  // scan up for the ceiling
  while (top < 21 && (at(0, top + 1) === 0 || at(0, top + 1) === PORTAL_BLOCK)) top++;
  const minX = -left, maxX = right, minY = -bottom, maxY = top;
  const interiorW = maxX - minX + 1, interiorH = maxY - minY + 1;
  if (interiorW < 2 || interiorH < 3) return null;
  // validate frame around the interior
  for (let dx = minX - 1; dx <= maxX + 1; dx++) {
    if (at(dx, minY - 1) !== frameId || at(dx, maxY + 1) !== frameId) return null;
  }
  for (let dy = minY; dy <= maxY; dy++) {
    if (at(minX - 1, dy) !== frameId || at(maxX + 1, dy) !== frameId) return null;
  }
  return { minX: x + minX, maxX: x + maxX, minY: y + minY, maxY: y + maxY, z: axis === "x" ? z : z, axis, frameKey };
}

/** Attempts to light a portal by igniting the interior at (x,y,z) with flint and steel. */
export function tryIgnitePortal(getBlock: GetBlock, x: number, y: number, z: number): { cells: [number, number, number][]; dim: DimId } | null {
  for (const axis of ["x", "z"] as const) {
    for (const frameKey of ["obsidian", "prism_glass", "portal_frame"]) {
      const f = findFrameInterior(getBlock, x, y, z, frameKey, axis);
      if (!f) continue;
      const cells: [number, number, number][] = [];
      for (let yy = f.minY; yy <= f.maxY; yy++) for (let xx = f.minX; xx <= f.maxX; xx++) {
        const ax = axis === "x" ? xx : f.z;
        const az = axis === "x" ? f.z : xx;
        if (getBlock(ax, yy, az) === 0) cells.push([ax, yy, az]);
      }
      if (cells.length === 0) continue;
      return { cells, dim: FRAME_FOR[frameKey] };
    }
  }
  return null;
}

/** Determines which dimension a portal cell leads to by inspecting its surrounding frame. */
export function portalDestination(getBlock: GetBlock, x: number, y: number, z: number, current: DimId): DimId | null {
  const seen = new Set<string>();
  const queue: [number, number, number][] = [[x, y, z]];
  let steps = 0;
  while (queue.length && steps < 400) {
    const [cx, cy, cz] = queue.pop()!;
    steps++;
    for (const [dx, dy, dz] of [[1, 0, 0], [-1, 0, 0], [0, 1, 0], [0, -1, 0], [0, 0, 1], [0, 0, -1]]) {
      const nx = cx + dx, ny = cy + dy, nz = cz + dz;
      const key = `${nx},${ny},${nz}`;
      if (seen.has(key)) continue;
      seen.add(key);
      const id = getBlock(nx, ny, nz);
      if (id === PORTAL_BLOCK) queue.push([nx, ny, nz]);
      else if (id !== 0) {
        const bKey = keyOfBlock(id);
        if (FRAME_FOR[bKey]) return FRAME_FOR[bKey];
      }
    }
  }
  // default travel: overworld <-> nether
  if (current === "overworld") return "nether";
  return "overworld";
}

import { BLOCKS } from "../blocks/blocks";
function keyOfBlock(id: number): string {
  return BLOCKS[id]?.key ?? "";
}

/** Converts a position between overworld and nether using the coordinate scale. */
export function mapCoordinates(from: DimId, to: DimId, x: number, z: number): { x: number; z: number } {
  if (from === "overworld" && to === "nether") return { x: x / 8, z: z / 8 };
  if (from === "nether" && to === "overworld") return { x: x * 8, z: z * 8 };
  return { x, z };
}

export function dimensionName(id: DimId): string {
  return DIMENSIONS[id].name;
}
