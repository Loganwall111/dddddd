// Data-driven item registry. Block items reuse the block key. Icons are generated procedurally (rendering/icons.ts).

import { BLOCKS } from "../blocks/blocks";

export type ItemKind = "block" | "tool" | "armor" | "food" | "item" | "spawn_egg" | "flint" | "tnt";
export type CreativeTab =
  | "building" | "natural" | "functional" | "decoration" | "dimension"
  | "tools" | "combat" | "food" | "ingredients" | "spawn" | "misc";

export const CREATIVE_TABS: { id: CreativeTab | "all"; label: string }[] = [
  { id: "all", label: "All" },
  { id: "building", label: "Building" },
  { id: "natural", label: "Natural" },
  { id: "functional", label: "Functional" },
  { id: "decoration", label: "Decor" },
  { id: "dimension", label: "Dimensions" },
  { id: "tools", label: "Tools" },
  { id: "combat", label: "Combat" },
  { id: "food", label: "Food" },
  { id: "ingredients", label: "Items" },
  { id: "spawn", label: "Spawn" },
  { id: "misc", label: "Misc" },
];

export interface ItemDef {
  key: string;
  name: string;
  kind: ItemKind;
  tab: CreativeTab;
  maxStack: number;
  // icon art description consumed by the procedural icon generator
  icon: IconSpec;
  tool?: { type: "pickaxe" | "axe" | "shovel" | "hoe" | "sword" | "shears"; tier: number; speed: number; damage: number; durability: number };
  armor?: { slot: "head" | "chest" | "legs" | "feet"; defense: number; durability: number };
  food?: { hunger: number; saturation: number; heal?: number; effect?: string };
  mob?: string; // spawn egg target
  durability?: number;
  blockKey?: string;
  lore?: string;
}

export type IconSpec =
  | { t: "block" }
  | { t: "tool"; tool: string; head: string; handle?: string }
  | { t: "armor"; slot: string; color: string; trim?: string }
  | { t: "food"; color: string; accent?: string; shape?: "round" | "meat" | "bread" }
  | { t: "ingot"; color: string; shine?: string }
  | { t: "gem"; color: string; shape?: "diamond" | "shard" | "cluster" | "pearl" }
  | { t: "raw"; color: string; accent: string }
  | { t: "egg"; a: string; b: string }
  | { t: "misc"; shape: string; color: string; accent?: string };

const items: ItemDef[] = [];
const byKey: Record<string, ItemDef> = {};

function add(d: ItemDef): void {
  items.push(d);
  byKey[d.key] = d;
}

// ---- Block items (generated from registry) ----
for (const b of BLOCKS) {
  if (b.id === 0 || b.key === "water" || b.key === "lava" || b.key === "toxic_water" || b.key === "sift_water" || b.key === "nether_portal" || b.key === "bedrock" || b.key === "snow_layer" || b.key === "bed_block" || b.key === "sapling_cherry") continue;
  if (b.key === "cornflower" || b.key === "dead_bush" || b.key === "reed" || b.key === "tall_grass") {
    // plants are still collectable items (as decorative placeables)
  }
  add({
    key: b.key,
    name: b.name,
    kind: b.special === "tnt" ? "tnt" : "block",
    tab: (b.category as CreativeTab) || "building",
    maxStack: 64,
    icon: { t: "block" },
    blockKey: b.key,
  });
}

// ---- Materials & tools ----
type Mat = { key: string; name: string; tier: number; dur: number; speed: number; dmg: number; color: string; head: string };
const MATS: Mat[] = [
  { key: "wooden", name: "Wooden", tier: 0, dur: 59, speed: 2, dmg: 2, color: "#b8925a", head: "#b8925a" },
  { key: "stone", name: "Stone", tier: 1, dur: 131, speed: 4, dmg: 3, color: "#8b8b8b", head: "#8b8b8b" },
  { key: "iron", name: "Iron", tier: 2, dur: 250, speed: 6, dmg: 4, color: "#e8e8e8", head: "#e8e8e8" },
  { key: "golden", name: "Golden", tier: 0, dur: 32, speed: 12, dmg: 2, color: "#f6d64a", head: "#f6d64a" },
  { key: "diamond", name: "Diamond", tier: 3, dur: 1561, speed: 8, dmg: 5, color: "#7ff0e8", head: "#7ff0e8" },
];
for (const m of MATS) {
  const toolTypes: { type: "pickaxe" | "axe" | "shovel" | "hoe" | "sword"; name: string; tool: string }[] = [
    { type: "pickaxe", name: "Pickaxe", tool: "pickaxe" },
    { type: "axe", name: "Axe", tool: "axe" },
    { type: "shovel", name: "Shovel", tool: "shovel" },
    { type: "hoe", name: "Hoe", tool: "hoe" },
    { type: "sword", name: "Sword", tool: "sword" },
  ];
  for (const t of toolTypes) {
    add({
      key: `${m.key}_${t.type}`,
      name: `${m.name} ${t.name}`,
      kind: "tool",
      tab: t.type === "sword" ? "combat" : "tools",
      maxStack: 1,
      durability: m.dur,
      icon: { t: "tool", tool: t.tool, head: m.head, handle: "#8a5a34" },
      tool: { type: t.type, tier: m.tier, speed: m.speed, damage: m.dmg + (t.type === "sword" ? 1 : 0), durability: m.dur },
    });
  }
}
add({ key: "shears", name: "Shears", kind: "tool", tab: "tools", maxStack: 1, durability: 238, icon: { t: "tool", tool: "shears", head: "#d8d8d8", handle: "#8a8a8a" }, tool: { type: "shears", tier: 0, speed: 5, damage: 1, durability: 238 } });
add({ key: "flint_steel", name: "Flint and Steel", kind: "flint", tab: "tools", maxStack: 1, durability: 64, icon: { t: "tool", tool: "flint", head: "#7a7a7a", handle: "#3f3f3f" } });

// ---- Armor ----
const ARMOR_MATS = [
  { key: "leather", name: "Leather", color: "#8a5a34", dur: 55, def: [1, 3, 2, 1] },
  { key: "iron", name: "Iron", color: "#e8e8e8", dur: 240, def: [2, 6, 5, 2] },
  { key: "diamond", name: "Diamond", color: "#7ff0e8", dur: 528, def: [3, 8, 6, 3] },
];
const PARTS: { slot: "head" | "chest" | "legs" | "feet"; name: string; idx: number }[] = [
  { slot: "head", name: "Helmet", idx: 0 },
  { slot: "chest", name: "Chestplate", idx: 1 },
  { slot: "legs", name: "Leggings", idx: 2 },
  { slot: "feet", name: "Boots", idx: 3 },
];
for (const m of ARMOR_MATS) {
  for (const p of PARTS) {
    add({
      key: `${m.key}_${p.slot}`,
      name: `${m.name} ${p.name}`,
      kind: "armor",
      tab: "combat",
      maxStack: 1,
      icon: { t: "armor", slot: p.slot, color: m.color },
      armor: { slot: p.slot, defense: m.def[p.idx], durability: m.dur },
      durability: m.dur,
    });
  }
}

// ---- Food ----
add({ key: "apple", name: "Apple", kind: "food", tab: "food", maxStack: 64, icon: { t: "food", color: "#d43a2a", accent: "#3f8a29", shape: "round" }, food: { hunger: 4, saturation: 2 } });
add({ key: "bread", name: "Bread", kind: "food", tab: "food", maxStack: 64, icon: { t: "food", color: "#c98a4a", shape: "bread" }, food: { hunger: 5, saturation: 6 } });
add({ key: "raw_beef", name: "Raw Beef", kind: "food", tab: "food", maxStack: 64, icon: { t: "food", color: "#c4524a", shape: "meat" }, food: { hunger: 3, saturation: 2 } });
add({ key: "cooked_beef", name: "Steak", kind: "food", tab: "food", maxStack: 64, icon: { t: "food", color: "#7a4a2a", shape: "meat" }, food: { hunger: 8, saturation: 12 } });
add({ key: "raw_porkchop", name: "Raw Porkchop", kind: "food", tab: "food", maxStack: 64, icon: { t: "food", color: "#e8a0a0", shape: "meat" }, food: { hunger: 3, saturation: 2 } });
add({ key: "cooked_porkchop", name: "Cooked Porkchop", kind: "food", tab: "food", maxStack: 64, icon: { t: "food", color: "#b8653a", shape: "meat" }, food: { hunger: 8, saturation: 12 } });
add({ key: "raw_chicken", name: "Raw Chicken", kind: "food", tab: "food", maxStack: 64, icon: { t: "food", color: "#e6b8a8", shape: "meat" }, food: { hunger: 2, saturation: 1 } });
add({ key: "cooked_chicken", name: "Cooked Chicken", kind: "food", tab: "food", maxStack: 64, icon: { t: "food", color: "#c08040", shape: "meat" }, food: { hunger: 6, saturation: 7 } });
add({ key: "golden_apple", name: "Golden Apple", kind: "food", tab: "food", maxStack: 64, icon: { t: "food", color: "#f6d64a", accent: "#fff3a0", shape: "round" }, food: { hunger: 4, saturation: 6, heal: 8, effect: "regeneration" } });
add({ key: "prism_fruit", name: "Prism Fruit", kind: "food", tab: "food", maxStack: 32, icon: { t: "food", color: "#ff7ad0", accent: "#7af0ff", shape: "round" }, food: { hunger: 6, saturation: 6, heal: 2, effect: "glowing" }, lore: "Found only in the Prismatic Sift." });

// ---- Ingredients & materials ----
const ING: [string, string, IconSpec][] = [
  ["stick", "Stick", { t: "misc", shape: "stick", color: "#9a6a3a" }],
  ["coal", "Coal", { t: "gem", color: "#2a2a2a", shape: "shard" }],
  ["charcoal", "Charcoal", { t: "gem", color: "#3a3030", shape: "shard" }],
  ["raw_iron", "Raw Iron", { t: "raw", color: "#c9a08a", accent: "#e8c0a0" }],
  ["raw_gold", "Raw Gold", { t: "raw", color: "#c9a13a", accent: "#f6d64a" }],
  ["raw_copper", "Raw Copper", { t: "raw", color: "#b06a3a", accent: "#e08a50" }],
  ["iron_ingot", "Iron Ingot", { t: "ingot", color: "#e8e8e8", shine: "#ffffff" }],
  ["gold_ingot", "Gold Ingot", { t: "ingot", color: "#f6d64a", shine: "#fff7b0" }],
  ["copper_ingot", "Copper Ingot", { t: "ingot", color: "#e08a50", shine: "#ffc8a0" }],
  ["diamond", "Diamond", { t: "gem", color: "#5fe7e0", shape: "diamond" }],
  ["emerald", "Emerald", { t: "gem", color: "#28c45e", shape: "diamond" }],
  ["lapis", "Lapis Lazuli", { t: "gem", color: "#2a4fb4", shape: "cluster" }],
  ["clay_ball", "Clay", { t: "misc", shape: "ball", color: "#9ea4b4" }],
  ["brick", "Brick", { t: "ingot", color: "#a85a40", shine: "#d88a70" }],
  ["snowball", "Snowball", { t: "misc", shape: "ball", color: "#f4f8fb" }],
  ["flint", "Flint", { t: "gem", color: "#4a4a4a", shape: "shard" }],
  ["string", "String", { t: "misc", shape: "string", color: "#f2f2f2" }],
  ["feather", "Feather", { t: "misc", shape: "feather", color: "#f2f2f2", accent: "#9ab8d8" }],
  ["leather", "Leather", { t: "misc", shape: "hide", color: "#8a5a34" }],
  ["bone", "Bone", { t: "misc", shape: "bone", color: "#efe8d4" }],
  ["rotten_flesh", "Rotten Flesh", { t: "misc", shape: "meat", color: "#6a8a4a" }],
  ["gunpowder", "Gunpowder", { t: "misc", shape: "powder", color: "#5a5a5a" }],
  ["ender_pearl", "Ender Pearl", { t: "gem", color: "#1f6b5a", shape: "pearl" }],
  ["glowstone_dust", "Glowstone Dust", { t: "misc", shape: "powder", color: "#ffd060" }],
  ["crystal_shard", "Crystal Shard", { t: "gem", color: "#4fd8ff", shape: "shard" }],
  ["amethyst_shard", "Amethyst Shard", { t: "gem", color: "#a36bff", shape: "shard" }],
  ["sugar", "Sugar", { t: "misc", shape: "powder", color: "#f8f8f8" }],
  ["arrow", "Arrow", { t: "misc", shape: "arrow", color: "#c9a13a", accent: "#e8e8e8" }],
  ["book", "Book", { t: "misc", shape: "book", color: "#7a3a2a" }],
  ["compass", "Compass", { t: "misc", shape: "compass", color: "#b8b8b8", accent: "#d43a2a" }],
  ["clock", "Clock", { t: "misc", shape: "compass", color: "#f6d64a", accent: "#4a3a1a" }],
  ["wheat_seeds", "Seeds", { t: "misc", shape: "seed", color: "#8a9a3a" }],
  ["prism_shard", "Prism Shard", { t: "gem", color: "#ffb3e6", shape: "shard" }],
];
for (const [key, name, icon] of ING) {
  add({ key, name, kind: "item", tab: "ingredients", maxStack: 64, icon, lore: undefined });
}

// ---- Spawn eggs (one per creature; target key matches entities registry) ----
const EGGS: [string, string, string, string][] = [
  ["pig", "Pig", "#e8a0a0", "#c07070"],
  ["cow", "Cow", "#f2f2f2", "#3a2a1a"],
  ["sheep", "Sheep", "#eaeaea", "#c0b080"],
  ["chicken", "Chicken", "#f2f2f2", "#d43a2a"],
  ["zombie", "Zombie", "#4a8a4a", "#2a4a6a"],
  ["skeleton", "Skeleton", "#dedad0", "#7a7a7a"],
  ["creeper", "Creeper", "#4aa84a", "#1a3a1a"],
  ["spider", "Spider", "#3a2a2a", "#c03a2a"],
  ["enderman", "Enderman", "#1a1a22", "#c06ae0"],
  ["villager", "Villager", "#8a6a4a", "#e8c8a0"],
  ["blaze", "Blaze", "#f6c03a", "#ff7a1a"],
  ["prism_jelly", "Prism Jelly", "#ff9ad6", "#7af0ff"],
  ["wisp", "Aether Wisp", "#9ff0ff", "#ffffff"],
  ["sky_ray", "Sky Ray", "#6ab0e0", "#e8f4ff"],
];
for (const [key, name, a, b] of EGGS) {
  add({ key: `spawn_${key}`, name: `${name} Spawn Egg`, kind: "spawn_egg", tab: "spawn", maxStack: 64, icon: { t: "egg", a, b }, mob: key });
}

// ---- Misc / dimension ----
add({ key: "tnt_stick", name: "Fuse Stick", kind: "item", tab: "misc", maxStack: 64, icon: { t: "misc", shape: "stick", color: "#4a2a1a" } });
add({ key: "debug_wand", name: "Creative Wand", kind: "item", tab: "misc", maxStack: 1, icon: { t: "misc", shape: "stick", color: "#7ad8ff", accent: "#ffffff" }, lore: "Right-click to summon an Aether Wisp (creative testing)." });
add({ key: "aether_key", name: "Aether Key", kind: "item", tab: "misc", maxStack: 1, icon: { t: "gem", color: "#7af0ff", shape: "pearl" }, lore: "Attunes portals and frames to the Aether." });

export const ITEMS: ItemDef[] = items;
export const ITEM_BY_KEY: Record<string, ItemDef> = byKey;

export function itemDef(key: string): ItemDef | undefined {
  return byKey[key];
}

export function maxStackOf(key: string): number {
  return byKey[key]?.maxStack ?? 64;
}

export function itemName(key: string): string {
  return byKey[key]?.name ?? key;
}

export function durabilityOf(key: string): number {
  const d = byKey[key];
  return d?.durability ?? d?.tool?.durability ?? d?.armor?.durability ?? 0;
}
