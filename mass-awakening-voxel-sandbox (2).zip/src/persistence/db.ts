// IndexedDB persistence: world metadata, RLE-compressed modified chunks, containers and misc key/value data.
// Everything is scoped by world id and dimension so saves stay dimension-aware.

import type { ChunkStore } from "../world/world";
import type { DimId, GenParams, WorldType } from "../world/generator";
import { CHUNK_VOLUME } from "../world/generator";
import type { Slot } from "../inventory/inventory";

export type GameMode = "survival" | "creative";
export type Difficulty = "peaceful" | "easy" | "normal" | "hard";

export interface PlayerSave {
  pos: { x: number; y: number; z: number };
  yaw: number;
  pitch: number;
  hp: number;
  hunger: number;
  saturation: number;
  xp: number;
  air: number;
  hotbar: number;
  inventory: Slot[]; // 41 slots
  dimension: DimId;
  dimPos: Partial<Record<DimId, { x: number; y: number; z: number }>>;
  flying: boolean;
  thirdPerson: boolean;
}

export interface WorldMeta {
  id: string;
  name: string;
  seedText: string;
  seed: number;
  mode: GameMode;
  difficulty: Difficulty;
  type: WorldType;
  created: number;
  lastPlayed: number;
  worldTime: number; // seconds of in-game clock
  weatherSeed: number;
  player?: PlayerSave;
  version: number;
  cheats: boolean;
  spawn?: { x: number; y: number; z: number };
}

export interface ContainerRecord {
  key: string;
  kind: "chest" | "furnace";
  slots: Slot[];
  burn?: number;
  burnMax?: number;
  cook?: number;
}

const DB_NAME = "aetherforged-db";
const DB_VERSION = 1;

let dbPromise: Promise<IDBDatabase> | null = null;

function open(): Promise<IDBDatabase> {
  if (dbPromise) return dbPromise;
  dbPromise = new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, DB_VERSION);
    req.onupgradeneeded = () => {
      const db = req.result;
      if (!db.objectStoreNames.contains("worlds")) db.createObjectStore("worlds", { keyPath: "id" });
      if (!db.objectStoreNames.contains("chunks")) db.createObjectStore("chunks", { keyPath: "key" });
      if (!db.objectStoreNames.contains("containers")) db.createObjectStore("containers", { keyPath: "key" });
      if (!db.objectStoreNames.contains("kv")) db.createObjectStore("kv", { keyPath: "key" });
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
  return dbPromise;
}

function tx<T>(store: string, mode: IDBTransactionMode, fn: (s: IDBObjectStore) => IDBRequest<T>): Promise<T> {
  return open().then(
    (db) =>
      new Promise<T>((resolve, reject) => {
        const t = db.transaction(store, mode);
        const req = fn(t.objectStore(store));
        t.oncomplete = () => resolve(req.result);
        t.onerror = () => reject(t.error);
        t.onabort = () => reject(t.error);
      }),
  );
}

// ---- RLE codec for chunk block data ---------------------------------------------
/** Encodes Uint16 block data as (run length, value) pairs. */
export function encodeBlocks(blocks: Uint16Array): ArrayBuffer {
  const out: number[] = [];
  let i = 0;
  while (i < blocks.length) {
    const v = blocks[i];
    let run = 1;
    while (i + run < blocks.length && blocks[i + run] === v && run < 65535) run++;
    out.push(run, v);
    i += run;
  }
  return Uint16Array.from(out).buffer;
}

/** Decodes RLE data; returns null if the payload is corrupt. */
export function decodeBlocks(buf: ArrayBuffer): Uint16Array | null {
  const pairs = new Uint16Array(buf);
  if (pairs.length % 2 !== 0) return null;
  const out = new Uint16Array(CHUNK_VOLUME);
  let o = 0;
  for (let p = 0; p < pairs.length; p += 2) {
    const run = pairs[p], v = pairs[p + 1];
    if (o + run > CHUNK_VOLUME) return null;
    out.fill(v, o, o + run);
    o += run;
  }
  return o === CHUNK_VOLUME ? out : null;
}

function bufToBase64(buf: ArrayBuffer): string {
  const bytes = new Uint8Array(buf);
  let s = "";
  const CH = 0x8000;
  for (let i = 0; i < bytes.length; i += CH) s += String.fromCharCode(...bytes.subarray(i, i + CH));
  return btoa(s);
}

function base64ToBuf(b64: string): ArrayBuffer {
  const s = atob(b64);
  const bytes = new Uint8Array(s.length);
  for (let i = 0; i < s.length; i++) bytes[i] = s.charCodeAt(i);
  return bytes.buffer;
}

// ---- Public API -------------------------------------------------------------------
export const db = {
  async listWorlds(): Promise<WorldMeta[]> {
    const all = await tx<WorldMeta[]>("worlds", "readonly", (s) => s.getAll());
    return all.sort((a, b) => b.lastPlayed - a.lastPlayed);
  },
  async getWorld(id: string): Promise<WorldMeta | undefined> {
    return tx<WorldMeta | undefined>("worlds", "readonly", (s) => s.get(id));
  },
  async putWorld(meta: WorldMeta): Promise<void> {
    await tx("worlds", "readwrite", (s) => s.put(meta));
  },
  async deleteWorld(id: string): Promise<void> {
    const d = await open();
    await new Promise<void>((resolve, reject) => {
      const t = d.transaction(["worlds", "chunks", "containers"], "readwrite");
      t.objectStore("worlds").delete(id);
      for (const store of ["chunks", "containers"]) {
        const req = t.objectStore(store).openCursor();
        req.onsuccess = () => {
          const c = req.result;
          if (!c) return;
          if (String(c.key).startsWith(`${id}|`)) c.delete();
          c.continue();
        };
      }
      t.oncomplete = () => resolve();
      t.onerror = () => reject(t.error);
    });
  },
  async getKv<T>(key: string): Promise<T | undefined> {
    const rec = await tx<{ key: string; value: T } | undefined>("kv", "readonly", (s) => s.get(key));
    return rec?.value;
  },
  async putKv<T>(key: string, value: T): Promise<void> {
    await tx("kv", "readwrite", (s) => s.put({ key, value }));
  },
  async getContainer(worldId: string, dim: DimId, pos: string): Promise<ContainerRecord | undefined> {
    const rec = await tx<ContainerRecord | undefined>("containers", "readonly", (s) => s.get(`${worldId}|${dim}|${pos}`));
    return rec;
  },
  async putContainer(worldId: string, dim: DimId, pos: string, rec: ContainerRecord): Promise<void> {
    await tx("containers", "readwrite", (s) => s.put({ ...rec, key: `${worldId}|${dim}|${pos}` }));
  },
  chunkStore(worldId: string): ChunkStore {
    return {
      async load(dim: DimId, cx: number, cz: number): Promise<Uint16Array | null> {
        const rec = await tx<{ key: string; data: ArrayBuffer } | undefined>("chunks", "readonly", (s) => s.get(`${worldId}|${dim}|${cx},${cz}`));
        if (!rec) return null;
        return decodeBlocks(rec.data);
      },
      async save(dim: DimId, cx: number, cz: number, blocks: Uint16Array): Promise<void> {
        const data = encodeBlocks(blocks);
        await tx("chunks", "readwrite", (s) => s.put({ key: `${worldId}|${dim}|${cx},${cz}`, data }));
      },
      async keys(dim: DimId): Promise<Set<string>> {
        const d = await open();
        const prefix = `${worldId}|${dim}|`;
        return new Promise<Set<string>>((resolve, reject) => {
          const out = new Set<string>();
          const t = d.transaction("chunks", "readonly");
          const range = IDBKeyRange.bound(prefix, prefix + "\uffff");
          const req = t.objectStore("chunks").openKeyCursor(range);
          req.onsuccess = () => {
            const c = req.result;
            if (!c) return;
            out.add(String(c.key).slice(prefix.length));
            c.continue();
          };
          t.oncomplete = () => resolve(out);
          t.onerror = () => reject(t.error);
        });
      },
    };
  },
  /** Serializes a world (meta + chunks + containers) to a JSON string for download. */
  async exportWorld(id: string): Promise<string> {
    const meta = await this.getWorld(id);
    if (!meta) throw new Error("World not found");
    const d = await open();
    const chunks: { key: string; data: string }[] = [];
    const containers: ContainerRecord[] = [];
    await new Promise<void>((resolve, reject) => {
      const t = d.transaction(["chunks", "containers"], "readonly");
      const prefix = `${id}|`;
      const range = IDBKeyRange.bound(prefix, prefix + "\uffff");
      const creq = t.objectStore("chunks").openCursor(range);
      creq.onsuccess = () => {
        const c = creq.result;
        if (!c) return;
        chunks.push({ key: String(c.key).slice(prefix.length), data: bufToBase64(c.value.data) });
        c.continue();
      };
      const kreq = t.objectStore("containers").openCursor(range);
      kreq.onsuccess = () => {
        const c = kreq.result;
        if (!c) return;
        containers.push(c.value as ContainerRecord);
        c.continue();
      };
      t.oncomplete = () => resolve();
      t.onerror = () => reject(t.error);
    });
    return JSON.stringify({ format: "aetherforged-world", version: 1, meta, chunks, containers });
  },
  /** Imports a world exported with exportWorld. Returns the new id. */
  async importWorld(json: string): Promise<string> {
    const data = JSON.parse(json) as { format: string; meta: WorldMeta; chunks: { key: string; data: string }[]; containers: ContainerRecord[] };
    if (data.format !== "aetherforged-world" || !data.meta) throw new Error("Not an AetherForged world file");
    const newId = `w${Date.now().toString(36)}${Math.random().toString(36).slice(2, 6)}`;
    const meta: WorldMeta = { ...data.meta, id: newId, name: `${data.meta.name} (imported)`, lastPlayed: Date.now() };
    await this.putWorld(meta);
    const d = await open();
    await new Promise<void>((resolve, reject) => {
      const t = d.transaction(["chunks", "containers"], "readwrite");
      for (const c of data.chunks) t.objectStore("chunks").put({ key: `${newId}|${c.key}`, data: base64ToBuf(c.data) });
      for (const c of data.containers) t.objectStore("containers").put({ ...c, key: c.key.replace(data.meta.id, newId) });
      t.oncomplete = () => resolve();
      t.onerror = () => reject(t.error);
    });
    return newId;
  },
  /** Creates GenParams from a world's metadata. */
  genParamsFor(meta: WorldMeta, dim: DimId): GenParams {
    return { seed: meta.seed, dim, type: meta.type };
  },
};

export function newWorldId(): string {
  return `w${Date.now().toString(36)}${Math.random().toString(36).slice(2, 7)}`;
}
