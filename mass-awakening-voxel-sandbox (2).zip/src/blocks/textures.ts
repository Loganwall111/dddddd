// Procedural pixel-art texture atlas. Every tile is painted at runtime (original art, no binary assets).
// Also derives a normal map from each tile's luminance for bump-lit detail ("PBR-lite").

import { hash2 } from "../world/noise";

export const TILE = 32;
export const ATLAS_COLS = 16;
type C = [number, number, number, number];
type Rnd = (x: number, y: number) => number;
type Paint = (x: number, y: number, r: Rnd) => C;

function hex(h: string, a = 255): C {
  const n = parseInt(h.slice(1), 16);
  return [(n >> 16) & 255, (n >> 8) & 255, n & 255, a];
}
const pick = (ps: string[], v: number): C => hex(ps[Math.min(ps.length - 1, Math.floor(v * ps.length))]);
const sh = (c: C, k: number): C => [c[0] * k, c[1] * k, c[2] * k, c[3]];
const CLEAR: C = [0, 0, 0, 0];

// Common patterns --------------------------------------------------------
const speckle = (cols: string[]): Paint => (x, y, r) => pick(cols, r(x, y));
const grainRows = (cols: string[], rowH = 4): Paint => (x, y, r) => {
  const band = Math.floor(y / rowH) % 2;
  return sh(pick(cols, r(x, y)), band ? 0.92 : 1.02);
};
const bricks = (mortar: string, cols: string[], w = 8, h = 4): Paint => (x, y, r) => {
  const row = Math.floor(y / h);
  const off = row % 2 ? w / 2 : 0;
  const bx = (x + off) % w, by = y % h;
  if (bx === 0 || by === 0) return hex(mortar);
  return sh(pick(cols, r(x, y)), 0.9 + r(Math.floor((x + off) / w) * 7, row) * 0.2);
};
const cobble = (cols: string[]): Paint => (x, y, r) => {
  const cx = Math.floor(x / 11), cy = Math.floor((y + (cx % 2) * 5) / 9);
  const lx = x % 11, ly = (y + (cx % 2) * 5) % 9;
  const edge = lx < 1 || ly < 1;
  if (edge) return hex("#4a4a4a");
  return sh(pick(cols, hash2(cx, cy, 77)), 0.85 + r(x, y) * 0.3);
};
const planksH = (cols: string[]): Paint => (x, y, r) => {
  const board = Math.floor(y / 8);
  if (y % 8 === 0) return hex("#3b2a16");
  const bx = (x + board * 9) % 16;
  if (bx === 0) return hex("#4d3a1f");
  return sh(pick(cols, r(x, board)), 0.93 + r(x, y) * 0.12);
};
const logSide = (bark: string[], inner: string): Paint => (x, y, r) => {
  const streak = hash2(Math.floor(x / 2), 3, 19);
  if (streak < 0.2 && r(x, y) > 0.3) return hex(inner);
  return sh(pick(bark, r(Math.floor(x / 2), Math.floor(y / 3))), 0.9 + streak * 0.2);
};
const logTop = (ring: string, core: string, edge: string): Paint => (x, y) => {
  const d = Math.hypot(x - 15.5, y - 15.5);
  if (d > 14.5) return hex(edge);
  const ringIdx = Math.floor(d / 2.2) % 2;
  return hex(ringIdx ? ring : core);
};
const ore = (base: string[], dots: string): Paint => (x, y, r) => {
  const v = r(x, y);
  if (v < 0.13 && hash2(x >> 1, y >> 1, 5) > 0.2) return hex(dots);
  return sh(pick(base, r(y, x)), 0.92 + hash2(x, y, 9) * 0.16);
};
const blockFill = (base: string, lines?: string): Paint => (x, y, r) => {
  if (lines && (x % 16 === 0 || y % 16 === 0)) return hex(lines);
  return sh(hex(base), 0.93 + r(x, y) * 0.14);
};
const sprite = (fn: (x: number, y: number, r: Rnd) => C | null): Paint => (x, y, r) => fn(x, y, r) ?? CLEAR;

// Tile painters ----------------------------------------------------------
const GREEN = ["#5fae3a", "#4f9a2f", "#6dbb45", "#3f8a29", "#5aa535"];
const PAINTERS: Record<string, Paint> = {
  missing: (x, y) => ((x >> 3) + (y >> 3)) % 2 ? [255, 0, 255, 255] : [20, 20, 20, 255],
  grass_top: speckle(GREEN),
  grass_side: (x, y, r) => {
    if (y < 7 + (hash2(x, 3, 2) * 4 | 0)) return sh(pick(GREEN, r(x, y)), 1.05);
    return sh(pick(["#8a5a34", "#7a4e2c", "#946239", "#6e4426"], r(x, y)), 1);
  },
  dirt: speckle(["#8a5a34", "#7a4e2c", "#946239", "#6e4426", "#7f5230"]),
  coarse_dirt: speckle(["#7a5030", "#6b4628", "#8f6038", "#5c3c22", "#a0785a"]),
  mycelium_top: speckle(["#7a6777", "#8c7a88", "#6a5a66", "#9b8b98"]),
  mycelium_side: (x, y, r) => (y < 6 ? sh(hex("#7a6777"), 1 + r(x, y) * 0.2) : pick(["#8a5a34", "#7a4e2c"], r(x, y))),
  stone: speckle(["#7d7d7d", "#8a8a8a", "#707070", "#969696", "#6a6a6a"]),
  cobblestone: cobble(["#8b8b8b", "#7a7a7a", "#9c9c9c", "#858585"]),
  mossy_cobble: (x, y, r) => (r(x, y) < 0.35 ? sh(pick(GREEN, r(y, x)), 0.9) : cobble(["#7f8a7f", "#6c776c", "#8d988d"])(x, y, r)),
  granite: speckle(["#a2634e", "#8f5544", "#b5735c", "#7e4a3d"]),
  deepslate: (x, y, r) => (y % 8 === 0 ? sh(hex("#3c3c42"), 0.9) : sh(pick(["#4d4d55", "#424249", "#56565f"], r(x, y)), 1)),
  sand: speckle(["#e6d59a", "#dcc88e", "#eadca4", "#d3bd82"]),
  red_sand: speckle(["#c8743a", "#bd6a33", "#d4824a", "#b26230"]),
  sandstone_top: (x, y, r) => sh(pick(["#e6d59a", "#dcc88e"], r(x, y)), 1 + (y % 16 === 0 ? -0.1 : 0)),
  sandstone_side: grainRows(["#e0cc8e", "#d6c085", "#eadca4"], 6),
  gravel: speckle(["#8b8888", "#6f6c6c", "#a09c9c", "#5f5b5b", "#b7b2b0"]),
  clay: speckle(["#9ea4b4", "#9097a8", "#aab0c0"]),
  mud: speckle(["#4a3f35", "#3e352c", "#55493c"]),
  moss: speckle(["#4f7a33", "#5c8a3b", "#3f6a29", "#6d9a48"]),
  snow: speckle(["#f4f8fb", "#e8f0f6", "#ffffff", "#dde9f2"]),
  snow_grass_side: (x, y, r) => (y < 6 + (hash2(x, 1, 8) * 3 | 0) ? sh(hex("#f4f8fb"), 1 + r(x, y) * 0.05) : pick(["#8a5a34", "#7a4e2c"], r(x, y))),
  ice: (x, y, r) => sh(pick(["#9fd3f0", "#8ac6ea", "#b4e0f6", "#7fbde2"], r(x, y)), 1 + (hash2(x >> 2, y >> 2, 4) > 0.8 ? 0.15 : 0)),
  packed_ice: speckle(["#7fb5dd", "#6aa5d2", "#93c6e6"]),
  bedrock: (x, y, r) => sh(pick(["#2a2a2a", "#3a3a3a", "#1e1e1e"], r(x, y)), 1),
  ash: speckle(["#5b5858", "#4a4848", "#6b6767", "#403e3e"]),
  bone_block_top: (x, y) => {
    const d = Math.hypot(x - 15.5, y - 15.5) % 8;
    return d < 2 ? hex("#efe8d4") : hex("#d9d1b8");
  },
  bone_block_side: (x, y) => ((x + y) % 10 < 2 ? hex("#efe8d4") : hex("#d9d1b8")),
  hay_top: (x, y, r) => sh(hex("#c9a13a"), 0.9 + r(x, y) * 0.2),
  hay_side: (x, y, r) => (y % 8 < 2 ? sh(hex("#8a6a22"), 1) : sh(hex("#c9a13a"), 0.9 + r(x, y) * 0.2)),
  pumpkin_top: (x, y, r) => sh(hex("#d7751d"), 0.94 + r(x, y) * 0.1),
  pumpkin_side: (x, y, r) => (Math.abs(x - 16) < 2 ? sh(hex("#a85a14"), 1) : sh(hex("#d7751d"), 0.94 + r(x, y) * 0.1)),
  terracotta: (x, y, r) => sh(hex(["#9a5f44", "#b26c4b", "#a0603f"][Math.floor(y / 6) % 3]), 0.95 + r(x, y) * 0.08),
  water: (x, y, r) => sh(hex("#2d7fb8"), 0.9 + r(x, y) * 0.2),
  toxic: (x, y, r) => sh(hex("#6fb02a"), 0.75 + r(x, y) * 0.45),
  lava: (x, y, r) => {
    const v = r(x, y);
    return v < 0.2 ? hex("#5a1a06") : sh(hex("#f08a1c"), 0.8 + v * 0.4);
  },
  sift_water: (x, y, r) => {
    const hue = ((x + y * 0.5) / 4 + r(x, y) * 0.6) % 6;
    const cs = ["#ff7aa2", "#ffd36a", "#9dff8a", "#6ae8ff", "#b48aff", "#ff9a6a"];
    return hex(cs[Math.floor(hue) % cs.length]);
  },
  oak_log_side: logSide(["#6b4f2c", "#5f4526", "#755735"], "#3e2c16"),
  oak_log_top: logTop("#a1834f", "#c39d62", "#5d4424"),
  birch_log_side: logSide(["#d9d6c9", "#cbc7b8", "#e6e3d6"], "#3a3a3a"),
  birch_log_top: logTop("#c8b67c", "#e3d6a6", "#8a7a52"),
  spruce_log_side: logSide(["#4b3520", "#3d2a18", "#5a4128"], "#2a1d0f"),
  spruce_log_top: logTop("#8b6b3f", "#b08a54", "#3f2d17"),
  cherry_log_side: logSide(["#5c3a40", "#4f3036", "#6a4850"], "#3a2226"),
  cherry_log_top: logTop("#e0a0b0", "#f2c4d0", "#6a4450"),
  jungle_log_side: logSide(["#5a4120", "#4e3719", "#664b28"], "#3a2a14"),
  jungle_log_top: logTop("#9b7340", "#bb8e56", "#4f3a1d"),
  dead_log_side: logSide(["#6e6453", "#5c5445", "#7a7060"], "#3e382d"),
  dead_log_top: logTop("#8b8070", "#a39886", "#4f4739"),
  oak_planks: planksH(["#b8925a", "#ad8750", "#c29b63"]),
  birch_planks: planksH(["#e0d2a4", "#d6c696", "#e8dbb0"]),
  spruce_planks: planksH(["#7a5a34", "#6d4f2d", "#856339"]),
  cherry_planks: planksH(["#e6b0bf", "#dba3b3", "#eebccb"]),
  leaves_oak: sprite((x, y, r) => (r(x, y) < 0.14 ? null : sh(pick(["#4f9a2f", "#3f8a29", "#5fae3a", "#37772a"], r(x, y)), 1))),
  leaves_birch: sprite((x, y, r) => (r(x, y) < 0.14 ? null : sh(pick(["#7fb84b", "#6fa83e", "#8cc857"], r(x, y)), 1))),
  leaves_spruce: sprite((x, y, r) => (r(x, y) < 0.12 ? null : sh(pick(["#2f5f36", "#264f2d", "#3a6d40"], r(x, y)), 1))),
  leaves_cherry: sprite((x, y, r) => (r(x, y) < 0.14 ? null : sh(pick(["#f2a9c3", "#e88fb0", "#ffc4d6"], r(x, y)), 1))),
  leaves_autumn: sprite((x, y, r) => (r(x, y) < 0.14 ? null : sh(pick(["#d9782a", "#c4521e", "#e8a040", "#b8401a"], r(x, y)), 1))),
  leaves_jungle: sprite((x, y, r) => (r(x, y) < 0.1 ? null : sh(pick(["#2e8a2e", "#3aa03a", "#247524"], r(x, y)), 1))),
  tall_grass: sprite((x, y, r) => {
    const blade = (x + Math.floor(y / 5)) % 4 === 0 || (x + 2) % 6 === 0;
    if (!blade || y < 10 + (hash2(x, 0, 3) * 6 | 0)) return null;
    return sh(pick(["#5fae3a", "#4f9a2f", "#6dbb45"], r(x, y)), 1);
  }),
  poppy: sprite((x, y, r) => {
    if (x >= 15 && x <= 16 && y > 14) return hex("#3f7a2a");
    if (Math.hypot(x - 15.5, y - 10) < 6) return Math.hypot(x - 15.5, y - 10) < 2 ? hex("#2a1a10") : hex("#e0262a");
    return null;
  }),
  cornflower: sprite((x, y) => {
    if (x >= 15 && x <= 16 && y > 14) return hex("#3f7a2a");
    if (Math.hypot(x - 15.5, y - 10) < 5) return hex("#4a7ee6");
    return null;
  }),
  dead_bush: sprite((x, y, r) => ((x + y) % 7 === 0 || (x - y) % 9 === 0) && y > 12 ? hex("#8b6a3a") : null),
  mushroom_red: sprite((x, y, r) => {
    if (x >= 13 && x <= 18 && y > 17) return hex("#efe2c9");
    if (y <= 17 && Math.hypot(x - 15.5, (y - 17) * 1.4) < 9) return (Math.hypot(x - 11, y - 11) < 1.8 || Math.hypot(x - 20, y - 13) < 1.5) ? hex("#f6f6f6") : hex("#d42626");
    return null;
  }),
  mushroom_brown: sprite((x, y) => {
    if (x >= 13 && x <= 18 && y > 17) return hex("#e8d8b8");
    if (y <= 17 && Math.hypot(x - 15.5, (y - 17) * 1.4) < 9) return hex("#8a5a34");
    return null;
  }),
  mushroom_stem: (x, y, r) => sh(hex("#e8d8b8"), 0.95 + r(x, y) * 0.1),
  mushroom_red_cap: (x, y, r) => ((x % 8 === 3 && y % 8 === 3) ? hex("#f6f6f6") : sh(hex("#d42626"), 0.9 + r(x, y) * 0.15)),
  cactus_top: (x, y) => (Math.hypot(x - 15.5, y - 15.5) < 10 ? hex("#4f8f3a") : hex("#3f7a2e")),
  cactus_side: (x, y, r) => (x % 8 === 4 ? hex("#2f5f22") : (x % 4 === 0 ? hex("#3f7a2e") : sh(hex("#56a040"), 0.95 + r(x, y) * 0.1))),
  reed: sprite((x, y) => (x % 8 === 3 || x % 8 === 4 ? hex("#7fbf50") : null)),
  sapling_cherry: sprite((x, y) => (x >= 15 && x <= 16 && y > 18 ? hex("#6a4a2a") : Math.hypot(x - 15.5, y - 14) < 4 ? hex("#f2a9c3") : null)),
  coal_ore: ore(["#7d7d7d", "#8a8a8a"], "#1a1a1a"),
  iron_ore: ore(["#7d7d7d", "#8a8a8a"], "#d8a07a"),
  copper_ore: ore(["#7d7d7d", "#8a8a8a"], "#c7713b"),
  gold_ore: ore(["#7d7d7d", "#8a8a8a"], "#f5d24a"),
  lapis_ore: ore(["#7d7d7d", "#8a8a8a"], "#2a4fb4"),
  diamond_ore: ore(["#7d7d7d", "#8a8a8a"], "#5fe7e0"),
  emerald_ore: ore(["#7d7d7d", "#8a8a8a"], "#28c45e"),
  iron_block: (x, y, r) => (x % 16 < 1 || y % 16 < 1 ? sh(hex("#c9c9c9"), 0.8) : sh(hex("#e8e8e8"), 0.97 + r(x, y) * 0.06)),
  gold_block: (x, y, r) => (x % 16 < 1 || y % 16 < 1 ? sh(hex("#c39a1a"), 1) : sh(hex("#f6d64a"), 0.97 + r(x, y) * 0.06)),
  diamond_block: (x, y, r) => (x % 16 < 1 || y % 16 < 1 ? sh(hex("#2a9c97"), 1) : sh(hex("#7ff0e8"), 0.97 + r(x, y) * 0.06)),
  copper_block: (x, y, r) => (x % 16 < 1 || y % 16 < 1 ? sh(hex("#9c5a2a"), 1) : sh(hex("#e08a50"), 0.97 + r(x, y) * 0.06)),
  obsidian: (x, y, r) => sh(pick(["#1a1226", "#241a33", "#16101f", "#2c2040"], r(x, y)), 1 + (hash2(x >> 2, y >> 2, 6) > 0.85 ? 0.3 : 0)),
  crystal_blue: (x, y, r) => sh(pick(["#4fd8ff", "#7ee8ff", "#2fb8e6", "#a8f2ff"], r(x, y)), 1),
  amethyst: (x, y, r) => sh(pick(["#a36bff", "#8c52e8", "#c39bff", "#7a44d6"], r(x, y)), 1),
  stone_bricks: bricks("#5c5c5c", ["#7d7d7d", "#8a8a8a", "#757575"], 8, 8),
  bricks: bricks("#b8b0a4", ["#9c4a36", "#a85a40", "#8c4030"], 8, 4),
  glass: (x, y) => (x < 1 || y < 1 || x > 30 || y > 30 ? hex("#dfeff5", 255) : hex("#bfe3f0", 70)),
  prism_glass: (x, y) => (x < 1 || y < 1 || x > 30 || y > 30 ? hex("#ffe9ff", 255) : hex("#c8f0ff", 60)),
  bookshelf: (x, y, r) => {
    if (y < 2 || (y > 14 && y < 17) || y > 29) return hex("#6b4f2c");
    const book = Math.floor(x / 4);
    return pick(["#b53a2a", "#2a5fb5", "#3a9a4a", "#c9a13a", "#7a3ab5"], hash2(book, Math.floor(y / 14), 11));
  },
  end_stone: speckle(["#e6e09a", "#dcd48a", "#efe8a8", "#d2cb84"]),
  end_bricks: bricks("#c9c384", ["#e4de9e", "#d8d193", "#ece6a8"], 8, 4),
  purpur_top: (x, y, r) => sh(hex("#b07ab5"), 0.92 + r(x, y) * 0.15),
  purpur_side: (x, y, r) => (x % 8 < 1 ? sh(hex("#8a5a90"), 1) : sh(hex("#b07ab5"), 0.92 + r(x, y) * 0.15)),
  netherrack: speckle(["#6e2a25", "#7d3129", "#5e221e", "#8a3a2e"]),
  nether_bricks: bricks("#2a1212", ["#4a1c1c", "#3d1616", "#552222"], 8, 4),
  basalt_top: (x, y) => (Math.hypot(x - 15.5, y - 15.5) % 9 < 1.5 ? hex("#2e2e2e") : hex("#4a4a4f")),
  basalt_side: (x, y, r) => (x % 6 < 1 ? hex("#2e2e33") : sh(hex("#4a4a4f"), 0.9 + r(x, y) * 0.2)),
  soul_sand: speckle(["#4f3c2c", "#5e4a36", "#3f3024", "#6a5340"]),
  glow_stone: (x, y, r) => sh(pick(["#f5c15a", "#ffd97a", "#e8ad40", "#fff0b0"], r(x, y)), 1),
  shroomlight: (x, y, r) => sh(pick(["#ffb14a", "#ff9a30", "#ffd080"], r(x, y)), 1),
  prism_stone: (x, y, r) => {
    const cs = ["#ffb3d1", "#b3f0ff", "#c9ffb3", "#fff3b3", "#d7b3ff"];
    return sh(hex(cs[(Math.floor(x / 8) + Math.floor(y / 8)) % cs.length]), 0.94 + r(x, y) * 0.12);
  },
  sift_grass_top: (x, y, r) => sh(pick(["#38d1b0", "#2fbfa0", "#45e0c0", "#25a88c"], r(x, y)), 1 + (r(x, y) > 0.96 ? 0.4 : 0)),
  sift_grass_side: (x, y, r) => (y < 7 ? sh(hex("#38d1b0"), 1) : pick(["#8a5a34", "#7a4e2c"], r(x, y))),
  toxic_moss: speckle(["#8ad43a", "#6fb02a", "#a6e550", "#5b9a22"]),
  wool_white: (x, y, r) => sh(hex("#f2f2f2"), 0.93 + r(x, y) * 0.1),
  wool_red: (x, y, r) => sh(hex("#b02a2a"), 0.93 + r(x, y) * 0.1),
  wool_blue: (x, y, r) => sh(hex("#2a3aa0"), 0.93 + r(x, y) * 0.1),
  wool_yellow: (x, y, r) => sh(hex("#f2d13a"), 0.93 + r(x, y) * 0.1),
  wool_green: (x, y, r) => sh(hex("#3e8a2a"), 0.93 + r(x, y) * 0.1),
  crafting_top: (x, y) => {
    if (x < 2 || y < 2 || x > 29 || y > 29) return hex("#5a3a1a");
    if ((x > 8 && x < 24 && (y === 8 || y === 16 || y === 24)) || (y > 8 && y < 24 && (x === 8 || x === 16 || x === 24))) return hex("#3b2410");
    return hex("#b8925a");
  },
  crafting_side: (x, y, r) => (x > 4 && x < 27 && y > 14 && y < 27 ? hex("#8a8a8a") : sh(hex("#b8925a"), 0.95 + r(x, y) * 0.1)),
  furnace_top: (x, y, r) => sh(hex("#7d7d7d"), 0.92 + r(x, y) * 0.16),
  furnace_front: (x, y, r) => {
    if (x > 7 && x < 24 && y > 12 && y < 26) return x > 10 && x < 21 && y > 15 && y < 24 ? hex("#ff8a2a") : hex("#3a3a3a");
    return sh(hex("#7d7d7d"), 0.92 + r(x, y) * 0.16);
  },
  furnace_side: (x, y, r) => sh(hex("#737373"), 0.92 + r(x, y) * 0.16),
  chest_top: (x, y) => (y < 3 || y > 28 || x < 3 || x > 28 ? hex("#5a3a1a") : hex("#b8925a")),
  chest_side: (x, y, r) => {
    if (y % 10 === 0 || x < 2 || x > 29) return hex("#5a3a1a");
    if (x > 13 && x < 18 && y > 13 && y < 19) return hex("#d8b04a");
    return sh(hex("#b8925a"), 0.95 + r(x, y) * 0.1);
  },
  tnt_side: (x, y) => {
    if (y > 9 && y < 22) return (x % 6 === 0 ? hex("#552020") : hex("#e8e4dc"));
    return hex("#b8242a");
  },
  tnt_top: (x, y) => (Math.hypot(x - 15.5, y - 15.5) < 6 ? hex("#3a2a1a") : hex("#c8c0b0")),
  tnt_bottom: (x, y, r) => sh(hex("#b8242a"), 0.9 + r(x, y) * 0.1),
  torch: sprite((x, y) => {
    if (x >= 14 && x <= 17 && y > 12) return hex("#7a5232");
    if (Math.hypot(x - 15.5, y - 9) < 3.2) return y < 8 ? hex("#ffe27a") : hex("#ff9a20");
    return null;
  }),
  lantern: (x, y, r) => (x < 3 || y < 3 || x > 28 || y > 28 ? hex("#4a4a4a") : sh(hex("#ffd27a"), 0.95 + r(x, y) * 0.1)),
  post_wood: (x, y, r) => (x % 16 < 3 ? hex("#3a2412") : sh(hex("#7a5232"), 0.95 + r(x, y) * 0.1)),
  sign_board: (x, y, r) => (y > 8 && y < 22 ? (y % 5 === 0 ? hex("#3a2412") : sh(hex("#b8925a"), 0.95 + r(x, y) * 0.1)) : hex("#5a3a1a")),
  ladder: sprite((x, y) => (x < 3 || x > 28 || y % 7 === 3 ? hex("#8a6a3a") : null)),
  portal: (x, y, r) => {
    const t = Math.sin((x + y) * 0.4) * 0.5 + 0.5;
    return sh(pick(["#5c1fa8", "#7b2fd0", "#3f1190", "#9e4af0"], t * 0.7 + r(x, y) * 0.3), 1);
  },
  portal_frame: (x, y, r) => {
    if (x < 3 || y < 3 || x > 28 || y > 28) return sh(hex("#c7f2ff"), 0.9 + r(x, y) * 0.1);
    return sh(hex("#1f1636"), 0.9 + r(x, y) * 0.2);
  },
  fern: sprite((x, y, r) => {
    const cx = 15.5, d = Math.abs(x - cx);
    if (y < 6 || d > (32 - y) * 0.5) return null;
    if (d < 1 || ((x + y) % 4 === 0 && d < (32 - y) * 0.45)) return sh(pick(["#4f8f2f", "#3f7a26", "#5ea23a"], r(x, y)), 1);
    return null;
  }),
  dandelion: sprite((x, y) => {
    if (x >= 15 && x <= 16 && y > 14) return hex("#3f7a2a");
    const d = Math.hypot(x - 15.5, y - 11);
    if (d < 5) return d < 2 ? hex("#f0a020") : hex("#ffe03a");
    return null;
  }),
  allium: sprite((x, y) => {
    if (x >= 15 && x <= 16 && y > 12) return hex("#3f7a2a");
    const d = Math.hypot(x - 15.5, y - 9);
    if (d < 5.5) return (x + y) % 3 === 0 ? hex("#e0a0ff") : hex("#b35ce0");
    return null;
  }),
  cobweb: sprite((x, y) => {
    const dx = x - 15.5, dy = y - 15.5;
    const d = Math.hypot(dx, dy);
    if (Math.abs(dx) < 0.6 || Math.abs(dy) < 0.6 || Math.abs(Math.abs(dx) - Math.abs(dy)) < 0.7 || (Math.abs(d % 6 - 3) < 0.5 && d < 15)) return hex("#e8e8f0", 220);
    return null;
  }),
  lamp_red: (x, y, r) => (x % 16 < 2 || y % 16 < 2 ? hex("#5a1010") : sh(hex("#ff3a30"), 0.85 + r(x, y) * 0.3)),
  lamp_blue: (x, y, r) => (x % 16 < 2 || y % 16 < 2 ? hex("#10205a") : sh(hex("#3a7aff"), 0.85 + r(x, y) * 0.3)),
  lamp_green: (x, y, r) => (x % 16 < 2 || y % 16 < 2 ? hex("#0f4a1a") : sh(hex("#3aff6a"), 0.85 + r(x, y) * 0.3)),
  lamp_gold: (x, y, r) => (x % 16 < 2 || y % 16 < 2 ? hex("#5a3a08") : sh(hex("#ffc23a"), 0.85 + r(x, y) * 0.3)),
  lamp_purple: (x, y, r) => (x % 16 < 2 || y % 16 < 2 ? hex("#3a0f5a") : sh(hex("#c35aff"), 0.85 + r(x, y) * 0.3)),
  chiseled_sandstone: (x, y, r) => {
    if (y < 3 || y > 28) return sh(hex("#d6c085"), 0.95);
    const d = Math.hypot(x - 15.5, y - 15.5);
    if (Math.abs(d - 8) < 1.2 || (Math.abs(x - 15.5) < 1 && y > 9 && y < 22)) return hex("#b49a5e");
    return sh(pick(["#e6d59a", "#dcc88e"], r(x, y)), 1);
  },
  tomb_top: (x, y, r) => {
    if (x < 3 || x > 28 || y < 3 || y > 28) return hex("#c9a13a");
    if (Math.abs(x - 15.5) < 2 && y > 6 && y < 26) return hex("#2a7ab0");
    return sh(hex("#d9c48a"), 0.92 + r(x, y) * 0.12);
  },
  tomb_side: (x, y, r) => (y < 4 || y > 27 ? hex("#c9a13a") : (x + y) % 9 === 0 ? hex("#2a7ab0") : sh(hex("#d1bb7e"), 0.92 + r(x, y) * 0.12)),
  magma: (x, y, r) => {
    const v = hash2(x >> 2, y >> 2, 51);
    return v > 0.7 ? sh(hex("#ff7a1a"), 0.9 + r(x, y) * 0.3) : sh(hex("#5a1a0a"), 0.8 + r(x, y) * 0.3);
  },
  blackstone: speckle(["#2a2630", "#353040", "#221e28", "#3a3545"]),
  mossy_cobble_unused: (x, y, r) => sh(hex("#7d7d7d"), 1 + r(x, y) * 0.1),
  bone_unused: (x, y) => hex("#efe8d4"),
  sculk_unused: (x, y) => hex("#0a2a30"),
  poppy_unused: (x, y) => hex("#e0262a"),
  rainbow_unused: (x, y) => hex("#ffffff"),
  flint_unused: (x, y) => hex("#2a2a2a"),
};

/** Tile order is the key order of PAINTERS. */
export const TILE_NAMES: string[] = Object.keys(PAINTERS);
const INDEX: Record<string, number> = {};
TILE_NAMES.forEach((n, i) => (INDEX[n] = i));

export function tileIndex(name: string): number {
  const i = INDEX[name];
  return i === undefined ? INDEX.missing : i;
}

/** Each tile sits in a CELL-sized slot with a GUTTER of wrapped pixels, so mipmaps don't bleed between tiles. */
export const GUTTER = 16;
export const CELL = TILE + GUTTER * 2; // 64
export const ATLAS_SIZE = ATLAS_COLS * CELL; // 1024

/** [u0, v0, u1, v1] in atlas UV space (image origin top-left), covering the tile's inner 32x32 region. */
export function tileUV(name: string): [number, number, number, number] {
  const idx = tileIndex(name);
  const col = idx % ATLAS_COLS, row = Math.floor(idx / ATLAS_COLS);
  const x0 = col * CELL + GUTTER, y0 = row * CELL + GUTTER;
  const pad = 0.25;
  return [(x0 + pad) / ATLAS_SIZE, (y0 + pad) / ATLAS_SIZE, (x0 + TILE - pad) / ATLAS_SIZE, (y0 + TILE - pad) / ATLAS_SIZE];
}

export interface Atlas {
  color: HTMLCanvasElement;
  normal: HTMLCanvasElement;
  size: number;
}

function paintTile(paint: Paint, seed: number): Uint8ClampedArray {
  const out = new Uint8ClampedArray(TILE * TILE * 4);
  const rnd: Rnd = (x, y) => hash2(x, y, seed);
  for (let y = 0; y < TILE; y++) {
    for (let x = 0; x < TILE; x++) {
      const c = paint(x, y, rnd);
      const o = (y * TILE + x) * 4;
      out[o] = c[0];
      out[o + 1] = c[1];
      out[o + 2] = c[2];
      out[o + 3] = c[3];
    }
  }
  return out;
}

/** Builds the color and normal atlases as canvases. Runs on the main thread once at startup. */
export function buildAtlas(): Atlas {
  const size = ATLAS_SIZE;
  const rows = ATLAS_COLS; // square atlas: UV math assumes size x size
  const color = document.createElement("canvas");
  color.width = size;
  color.height = rows * CELL;
  const normal = document.createElement("canvas");
  normal.width = size;
  normal.height = rows * CELL;
  const cctx = color.getContext("2d")!;
  const nctx = normal.getContext("2d")!;
  const cimg = cctx.createImageData(size, rows * CELL);
  const nimg = nctx.createImageData(size, rows * CELL);

  TILE_NAMES.forEach((name, idx) => {
    const px = paintTile(PAINTERS[name], 1000 + idx * 31);
    const col = idx % ATLAS_COLS, row = Math.floor(idx / ATLAS_COLS);
    const lum = (x: number, y: number) => {
      const xx = (x + TILE) % TILE, yy = (y + TILE) % TILE;
      const o = (yy * TILE + xx) * 4;
      return (px[o] * 0.3 + px[o + 1] * 0.59 + px[o + 2] * 0.11) / 255;
    };
    for (let cy = 0; cy < CELL; cy++) {
      for (let cx = 0; cx < CELL; cx++) {
        // wrap the tile into its gutter so filtering/mips sample the same texture
        const x = (((cx - GUTTER) % TILE) + TILE) % TILE;
        const y = (((cy - GUTTER) % TILE) + TILE) % TILE;
        const s = px[(y * TILE + x) * 4 + 3];
        const gx = cx + col * CELL, gy = cy + row * CELL;
        const o = (gy * size + gx) * 4;
        cimg.data[o] = px[(y * TILE + x) * 4];
        cimg.data[o + 1] = px[(y * TILE + x) * 4 + 1];
        cimg.data[o + 2] = px[(y * TILE + x) * 4 + 2];
        cimg.data[o + 3] = s;
        // derive normal from luminance gradient (bump-style detail)
        const dx = (lum(x + 1, y) - lum(x - 1, y)) * 2.2;
        const dy = (lum(x, y + 1) - lum(x, y - 1)) * 2.2;
        const inv = 1 / Math.hypot(dx, dy, 1);
        nimg.data[o] = (-dx * inv * 0.5 + 0.5) * 255;
        nimg.data[o + 1] = (-dy * inv * 0.5 + 0.5) * 255;
        nimg.data[o + 2] = (inv * 0.5 + 0.5) * 255;
        nimg.data[o + 3] = 255;
      }
    }
  });
  cctx.putImageData(cimg, 0, 0);
  nctx.putImageData(nimg, 0, 0);
  return { color, normal, size };
}

/** Ten crack-overlay frames for block breaking (0-9). */
export function buildCrackFrames(): HTMLCanvasElement[] {
  const frames: HTMLCanvasElement[] = [];
  for (let stage = 0; stage < 10; stage++) {
    const c = document.createElement("canvas");
    c.width = TILE;
    c.height = TILE;
    const g = c.getContext("2d")!;
    const cracks = 3 + stage * 2;
    g.strokeStyle = "rgba(10,10,10,0.85)";
    g.lineWidth = 1;
    let seed = 12345 + stage;
    const rnd = () => {
      seed = (seed * 16807) % 2147483647;
      return seed / 2147483647;
    };
    for (let i = 0; i < cracks; i++) {
      let x = rnd() * TILE, y = rnd() * TILE;
      g.beginPath();
      g.moveTo(x, y);
      const steps = 3 + Math.floor(stage / 2);
      for (let s = 0; s < steps; s++) {
        x += (rnd() - 0.5) * 9;
        y += (rnd() - 0.5) * 9;
        g.lineTo(Math.round(x), Math.round(y));
      }
      g.stroke();
    }
    frames.push(c);
  }
  return frames;
}
