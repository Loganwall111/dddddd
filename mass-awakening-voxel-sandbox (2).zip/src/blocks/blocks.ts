// Data-driven block registry. Adding a block = adding one entry here (and a texture painter in textures.ts).

export type RenderKind =
  | "solid" // opaque full cube, occludes neighbours
  | "glass" // transparent cube
  | "cutout" // alpha-tested full cube (leaves)
  | "emissive" // unlit glowing cube
  | "plant" // crossed quads (flowers, grass)
  | "torch" // thin emissive post
  | "water" // animated water surface
  | "lava" // emissive molten surface
  | "portal" // translucent animated portal plane
  | "none"; // air

export type ToolType = "pickaxe" | "axe" | "shovel" | "hoe" | "shears" | "none";

export interface BlockDef {
  id: number;
  key: string;
  name: string;
  top: string;
  side: string;
  bottom: string;
  render: RenderKind;
  solid: boolean; // collides with player
  hardness: number; // -1 = unbreakable
  tool: ToolType;
  tier: number; // minimum tool tier to harvest drops (0 wood,1 stone,2 iron,3 diamond)
  drop: string | null; // item key dropped (null = nothing)
  blast: number; // blast resistance
  tint: "grass" | "foliage" | "water" | null;
  light: number; // emitted light 0-15 (visual)
  lightColor?: [number, number, number]; // RGB of emitted light (0-1), used by the coloured-light mesher pass
  gravity?: boolean; // falls when unsupported (sand, gravel)
  category: string; // creative tab id
  flammable?: boolean;
  damage?: number; // contact damage per second
  fluid?: boolean;
  special?: "tnt" | "portal_frame" | "spawner" | "chest" | "furnace" | "crafting";
}

type Partial2 = Partial<Omit<BlockDef, "id" | "key" | "name" | "top" | "side" | "bottom">>;

const list: BlockDef[] = [];
let nextId = 1;

function blk(key: string, name: string, top: string, side = top, bottom = top, o: Partial2 = {}): void {
  list.push({
    id: nextId++,
    key,
    name,
    top,
    side,
    bottom,
    render: o.render ?? "solid",
    solid: o.solid ?? true,
    hardness: o.hardness ?? 1.5,
    tool: o.tool ?? "pickaxe",
    tier: o.tier ?? 0,
    drop: o.drop !== undefined ? o.drop : key,
    blast: o.blast ?? 3,
    tint: o.tint ?? null,
    light: o.light ?? 0,
    category: o.category ?? "building",
    flammable: o.flammable,
    damage: o.damage,
    fluid: o.fluid,
    special: o.special,
  });
}

// ---- Air ----
list.push({
  id: 0, key: "air", name: "Air", top: "missing", side: "missing", bottom: "missing", render: "none", solid: false,
  hardness: 0, tool: "none", tier: 0, drop: null, blast: 0, tint: null, light: 0, category: "none",
});

// ---- Natural terrain ----
blk("grass_block", "Grass Block", "grass_top", "grass_side", "dirt", { hardness: 0.6, tool: "shovel", drop: "dirt", tint: "grass", category: "natural" });
blk("dirt", "Dirt", "dirt", "dirt", "dirt", { hardness: 0.5, tool: "shovel", category: "natural" });
blk("coarse_dirt", "Coarse Dirt", "coarse_dirt", "coarse_dirt", "coarse_dirt", { hardness: 0.5, tool: "shovel", category: "natural" });
blk("podzol", "Mycelium", "mycelium_top", "mycelium_side", "dirt", { hardness: 0.6, tool: "shovel", drop: "dirt", category: "natural" });
blk("snow_grass", "Snowy Grass", "snow", "snow_grass_side", "dirt", { hardness: 0.6, tool: "shovel", drop: "dirt", category: "natural" });
blk("stone", "Stone", "stone", "stone", "stone", { hardness: 1.5, tier: 0, drop: "cobblestone", category: "natural" });
blk("cobblestone", "Cobblestone", "cobblestone", "cobblestone", "cobblestone", { hardness: 2, blast: 6, category: "building" });
blk("granite", "Granite", "granite", "granite", "granite", { hardness: 1.5, drop: "granite", category: "natural" });
blk("deepslate", "Deepslate", "deepslate", "deepslate", "deepslate", { hardness: 3, tier: 1, blast: 6, category: "natural" });
blk("sand", "Sand", "sand", "sand", "sand", { hardness: 0.5, tool: "shovel", category: "natural" });
blk("red_sand", "Red Sand", "red_sand", "red_sand", "red_sand", { hardness: 0.5, tool: "shovel", category: "natural" });
blk("sandstone", "Sandstone", "sandstone_top", "sandstone_side", "sandstone_top", { hardness: 0.8, category: "building" });
blk("gravel", "Gravel", "gravel", "gravel", "gravel", { hardness: 0.6, tool: "shovel", category: "natural" });
blk("clay", "Clay", "clay", "clay", "clay", { hardness: 0.6, tool: "shovel", drop: "clay_ball", category: "natural" });
blk("mud", "Mud", "mud", "mud", "mud", { hardness: 0.6, tool: "shovel", category: "natural" });
blk("moss_block", "Moss Block", "moss", "moss", "moss", { hardness: 0.1, tool: "hoe", category: "natural" });
blk("snow_block", "Snow Block", "snow", "snow", "snow", { hardness: 0.2, tool: "shovel", drop: "snowball", category: "natural" });
blk("ice", "Ice", "ice", "ice", "ice", { hardness: 0.5, render: "glass", blast: 1, category: "natural" });
blk("packed_ice", "Packed Ice", "packed_ice", "packed_ice", "packed_ice", { hardness: 0.5, blast: 1, category: "building" });
blk("bedrock", "Bedrock", "bedrock", "bedrock", "bedrock", { hardness: -1, blast: 3600000, category: "natural" });
blk("ash", "Ash Soil", "ash", "ash", "ash", { hardness: 0.5, tool: "shovel", category: "natural" });
blk("bone_block", "Bone Block", "bone_block_top", "bone_block_side", "bone_block_top", { hardness: 2, category: "decoration" });
blk("hay_bale", "Hay Bale", "hay_top", "hay_side", "hay_top", { hardness: 0.5, tool: "hoe", category: "functional", flammable: true });
blk("pumpkin", "Pumpkin", "pumpkin_top", "pumpkin_side", "pumpkin_top", { hardness: 1, tool: "axe", category: "natural" });
blk("terracotta", "Terracotta", "terracotta", "terracotta", "terracotta", { hardness: 1.25, category: "building" });

// ---- Water / fluids ----
blk("water", "Water", "water", "water", "water", { render: "water", solid: false, hardness: -1, tool: "none", drop: null, blast: 100, tint: "water", fluid: true, category: "none" });
blk("toxic_water", "Toxic Sludge", "toxic", "toxic", "toxic", { render: "water", solid: false, hardness: -1, tool: "none", drop: null, blast: 100, tint: "water", fluid: true, damage: 2, category: "none" });
blk("sift_water", "Prismatic Water", "sift_water", "sift_water", "sift_water", { render: "water", solid: false, hardness: -1, tool: "none", drop: null, blast: 100, tint: "water", fluid: true, damage: 3, light: 4, category: "none" });
blk("lava", "Lava", "lava", "lava", "lava", { render: "lava", solid: false, hardness: -1, tool: "none", drop: null, blast: 100, fluid: true, light: 15, damage: 4, category: "none" });

// ---- Wood ----
blk("oak_log", "Oak Log", "oak_log_top", "oak_log_side", "oak_log_top", { hardness: 2, tool: "axe", category: "natural", flammable: true });
blk("birch_log", "Birch Log", "birch_log_top", "birch_log_side", "birch_log_top", { hardness: 2, tool: "axe", category: "natural", flammable: true });
blk("spruce_log", "Spruce Log", "spruce_log_top", "spruce_log_side", "spruce_log_top", { hardness: 2, tool: "axe", category: "natural", flammable: true });
blk("cherry_log", "Cherry Log", "cherry_log_top", "cherry_log_side", "cherry_log_top", { hardness: 2, tool: "axe", category: "natural", flammable: true });
blk("jungle_log", "Jungle Log", "jungle_log_top", "jungle_log_side", "jungle_log_top", { hardness: 2, tool: "axe", category: "natural", flammable: true });
blk("dead_log", "Dead Log", "dead_log_top", "dead_log_side", "dead_log_top", { hardness: 2, tool: "axe", category: "natural", flammable: true });
blk("oak_planks", "Oak Planks", "oak_planks", "oak_planks", "oak_planks", { hardness: 2, tool: "axe", category: "building", flammable: true });
blk("birch_planks", "Birch Planks", "birch_planks", "birch_planks", "birch_planks", { hardness: 2, tool: "axe", category: "building", flammable: true });
blk("spruce_planks", "Spruce Planks", "spruce_planks", "spruce_planks", "spruce_planks", { hardness: 2, tool: "axe", category: "building", flammable: true });
blk("cherry_planks", "Cherry Planks", "cherry_planks", "cherry_planks", "cherry_planks", { hardness: 2, tool: "axe", category: "building", flammable: true });

// ---- Foliage ----
blk("oak_leaves", "Oak Leaves", "leaves_oak", "leaves_oak", "leaves_oak", { render: "cutout", hardness: 0.2, tool: "shears", drop: null, tint: "foliage", blast: 0.5, category: "natural", flammable: true });
blk("birch_leaves", "Birch Leaves", "leaves_birch", "leaves_birch", "leaves_birch", { render: "cutout", hardness: 0.2, tool: "shears", drop: null, tint: "foliage", blast: 0.5, category: "natural", flammable: true });
blk("spruce_leaves", "Spruce Leaves", "leaves_spruce", "leaves_spruce", "leaves_spruce", { render: "cutout", hardness: 0.2, tool: "shears", drop: null, tint: "foliage", blast: 0.5, category: "natural", flammable: true });
blk("cherry_leaves", "Cherry Leaves", "leaves_cherry", "leaves_cherry", "leaves_cherry", { render: "cutout", hardness: 0.2, tool: "shears", drop: null, tint: "foliage", blast: 0.5, category: "natural", flammable: true });
blk("autumn_leaves", "Autumn Leaves", "leaves_autumn", "leaves_autumn", "leaves_autumn", { render: "cutout", hardness: 0.2, tool: "shears", drop: null, tint: "foliage", blast: 0.5, category: "natural", flammable: true });
blk("jungle_leaves", "Jungle Leaves", "leaves_jungle", "leaves_jungle", "leaves_jungle", { render: "cutout", hardness: 0.2, tool: "shears", drop: null, tint: "foliage", blast: 0.5, category: "natural", flammable: true });
blk("tall_grass", "Grass", "tall_grass", "tall_grass", "tall_grass", { render: "plant", solid: false, hardness: 0, tool: "none", drop: null, tint: "grass", blast: 0, category: "natural", flammable: true });
blk("poppy", "Poppy", "poppy", "poppy", "poppy", { render: "plant", solid: false, hardness: 0, tool: "none", drop: "poppy", blast: 0, category: "natural", flammable: true });
blk("cornflower", "Cornflower", "cornflower", "cornflower", "cornflower", { render: "plant", solid: false, hardness: 0, tool: "none", blast: 0, category: "natural" });
blk("dead_bush", "Dead Bush", "dead_bush", "dead_bush", "dead_bush", { render: "plant", solid: false, hardness: 0, tool: "none", blast: 0, category: "natural", flammable: true });
blk("red_mushroom", "Red Mushroom", "mushroom_red", "mushroom_red", "mushroom_red", { render: "plant", solid: false, hardness: 0, tool: "none", blast: 0, light: 1, category: "natural" });
blk("brown_mushroom", "Brown Mushroom", "mushroom_brown", "mushroom_brown", "mushroom_brown", { render: "plant", solid: false, hardness: 0, tool: "none", blast: 0, light: 1, category: "natural" });
blk("mushroom_stem", "Mushroom Stem", "mushroom_stem", "mushroom_stem", "mushroom_stem", { hardness: 0.6, tool: "axe", category: "natural" });
blk("red_mushroom_block", "Red Mushroom Block", "mushroom_red_cap", "mushroom_red_cap", "mushroom_red_cap", { hardness: 0.6, tool: "axe", category: "natural" });
blk("cactus", "Cactus", "cactus_top", "cactus_side", "cactus_top", { render: "cutout", hardness: 0.4, tool: "none", blast: 0.5, category: "natural" });
blk("sugar_reed", "Reed", "reed", "reed", "reed", { render: "plant", solid: false, hardness: 0, tool: "none", blast: 0, tint: "grass", category: "natural" });
blk("sapling_cherry", "Cherry Sapling", "sapling_cherry", "sapling_cherry", "sapling_cherry", { render: "plant", solid: false, hardness: 0, tool: "none", blast: 0, tint: "foliage", category: "natural" });

// ---- Ores & minerals ----
blk("coal_ore", "Coal Ore", "coal_ore", "coal_ore", "coal_ore", { hardness: 3, tier: 0, drop: "coal", blast: 3, category: "natural" });
blk("iron_ore", "Iron Ore", "iron_ore", "iron_ore", "iron_ore", { hardness: 3, tier: 1, drop: "raw_iron", blast: 3, category: "natural" });
blk("copper_ore", "Copper Ore", "copper_ore", "copper_ore", "copper_ore", { hardness: 3, tier: 1, drop: "raw_copper", blast: 3, category: "natural" });
blk("gold_ore", "Gold Ore", "gold_ore", "gold_ore", "gold_ore", { hardness: 3, tier: 2, drop: "raw_gold", blast: 3, category: "natural" });
blk("lapis_ore", "Lapis Ore", "lapis_ore", "lapis_ore", "lapis_ore", { hardness: 3, tier: 1, drop: "lapis", blast: 3, category: "natural" });
blk("diamond_ore", "Diamond Ore", "diamond_ore", "diamond_ore", "diamond_ore", { hardness: 3, tier: 2, drop: "diamond", blast: 3, category: "natural" });
blk("emerald_ore", "Emerald Ore", "emerald_ore", "emerald_ore", "emerald_ore", { hardness: 3, tier: 2, drop: "emerald", blast: 3, category: "natural" });
blk("iron_block", "Block of Iron", "iron_block", "iron_block", "iron_block", { hardness: 5, tier: 1, blast: 6, category: "building" });
blk("gold_block", "Block of Gold", "gold_block", "gold_block", "gold_block", { hardness: 3, tier: 2, blast: 6, category: "building" });
blk("diamond_block", "Block of Diamond", "diamond_block", "diamond_block", "diamond_block", { hardness: 5, tier: 2, blast: 6, category: "building" });
blk("copper_block", "Block of Copper", "copper_block", "copper_block", "copper_block", { hardness: 3, tier: 1, blast: 6, category: "building" });
blk("obsidian", "Obsidian", "obsidian", "obsidian", "obsidian", { hardness: 50, tier: 3, blast: 1200, category: "natural" });
blk("crystal_blue", "Blue Crystal", "crystal_blue", "crystal_blue", "crystal_blue", { hardness: 1, tier: 0, render: "emissive", light: 12, drop: "crystal_shard", category: "natural" });
blk("amethyst", "Amethyst Cluster", "amethyst", "amethyst", "amethyst", { hardness: 1.5, render: "emissive", light: 6, drop: "amethyst_shard", category: "natural" });

// ---- Stone building ----
blk("stone_bricks", "Stone Bricks", "stone_bricks", "stone_bricks", "stone_bricks", { hardness: 1.5, blast: 6, category: "building" });
blk("bricks", "Bricks", "bricks", "bricks", "bricks", { hardness: 2, blast: 6, category: "building" });
blk("glass", "Glass", "glass", "glass", "glass", { render: "glass", hardness: 0.3, tool: "none", drop: null, blast: 0.3, category: "building" });
blk("prism_glass", "Prism Glass", "prism_glass", "prism_glass", "prism_glass", { render: "glass", hardness: 0.3, tool: "none", drop: null, blast: 0.3, light: 3, category: "building" });
blk("bookshelf", "Bookshelf", "bookshelf", "bookshelf", "oak_planks", { hardness: 1.5, tool: "axe", category: "building", flammable: true });
blk("end_stone", "End Stone", "end_stone", "end_stone", "end_stone", { hardness: 3, tier: 0, blast: 9, category: "dimension" });
blk("end_bricks", "End Stone Bricks", "end_bricks", "end_bricks", "end_bricks", { hardness: 3, tier: 0, blast: 9, category: "dimension" });
blk("purpur_pillar", "Purpur Pillar", "purpur_top", "purpur_side", "purpur_top", { hardness: 1.5, blast: 9, category: "dimension" });
blk("netherrack", "Netherrack", "netherrack", "netherrack", "netherrack", { hardness: 0.4, blast: 0.4, category: "dimension" });
blk("nether_bricks", "Nether Bricks", "nether_bricks", "nether_bricks", "nether_bricks", { hardness: 2, blast: 6, category: "dimension" });
blk("basalt", "Basalt", "basalt_top", "basalt_side", "basalt_top", { hardness: 1.25, blast: 4, category: "dimension" });
blk("soul_sand", "Soul Sand", "soul_sand", "soul_sand", "soul_sand", { hardness: 0.5, tool: "shovel", category: "dimension" });
blk("glowstone", "Glowstone", "glow_stone", "glow_stone", "glow_stone", { hardness: 0.3, render: "emissive", light: 15, drop: "glowstone_dust", category: "dimension" });
blk("shroomlight", "Shroomlight", "shroomlight", "shroomlight", "shroomlight", { hardness: 1, render: "emissive", light: 15, category: "dimension" });
blk("prism_stone", "Prism Stone", "prism_stone", "prism_stone", "prism_stone", { hardness: 2, blast: 6, category: "dimension" });
blk("sift_grass", "Sift Grass", "sift_grass_top", "sift_grass_side", "dirt", { hardness: 0.6, tool: "shovel", drop: "dirt", tint: "grass", category: "dimension" });
blk("toxic_moss", "Toxic Moss", "toxic_moss", "toxic_moss", "toxic_moss", { hardness: 0.2, tool: "hoe", category: "dimension" });

// ---- Functional ----
blk("crafting_table", "Crafting Table", "crafting_top", "crafting_side", "oak_planks", { hardness: 2.5, tool: "axe", category: "functional", special: "crafting", flammable: true });
blk("furnace", "Furnace", "furnace_top", "furnace_front", "furnace_top", { hardness: 3.5, blast: 6, category: "functional", special: "furnace" });
blk("chest", "Chest", "chest_top", "chest_side", "chest_top", { hardness: 2.5, tool: "axe", category: "functional", special: "chest", flammable: true });
blk("tnt", "TNT", "tnt_top", "tnt_side", "tnt_bottom", { hardness: 0, tool: "none", blast: 0, category: "functional", special: "tnt", flammable: true });
blk("torch", "Torch", "torch", "torch", "torch", { render: "torch", solid: false, hardness: 0, tool: "none", blast: 0, light: 14, category: "functional" });
blk("lantern", "Lantern", "lantern", "lantern", "lantern", { render: "emissive", hardness: 0.5, light: 15, category: "functional" });
blk("nether_portal", "Nether Portal", "portal", "portal", "portal", { render: "portal", solid: false, hardness: -1, tool: "none", drop: null, blast: 0, light: 11, category: "none" });
blk("portal_frame", "Ancient Frame", "portal_frame", "portal_frame", "portal_frame", { hardness: 50, tier: 3, blast: 1200, category: "dimension", special: "portal_frame" });
blk("spawn_pedestal", "Spawner Pedestal", "bricks", "stone_bricks", "stone_bricks", { hardness: 3, category: "functional" });
blk("wool_white", "White Wool", "wool_white", "wool_white", "wool_white", { hardness: 0.8, tool: "shears", category: "decoration", flammable: true });
blk("wool_red", "Red Wool", "wool_red", "wool_red", "wool_red", { hardness: 0.8, tool: "shears", category: "decoration", flammable: true });
blk("wool_blue", "Blue Wool", "wool_blue", "wool_blue", "wool_blue", { hardness: 0.8, tool: "shears", category: "decoration", flammable: true });
blk("wool_yellow", "Yellow Wool", "wool_yellow", "wool_yellow", "wool_yellow", { hardness: 0.8, tool: "shears", category: "decoration", flammable: true });
blk("wool_green", "Green Wool", "wool_green", "wool_green", "wool_green", { hardness: 0.8, tool: "shears", category: "decoration", flammable: true });
blk("cobble_wall", "Mossy Cobblestone", "mossy_cobble", "mossy_cobble", "mossy_cobble", { hardness: 2, blast: 6, category: "building" });
blk("lantern_post", "Lamp Post", "post_wood", "post_wood", "post_wood", { hardness: 2, tool: "axe", category: "decoration" });
blk("ladder", "Ladder", "ladder", "ladder", "ladder", { render: "cutout", solid: false, hardness: 0.4, tool: "axe", category: "functional", flammable: true });
blk("sign_board", "Village Sign", "sign_board", "sign_board", "oak_planks", { hardness: 1, tool: "axe", category: "decoration", flammable: true });
blk("snow_layer", "Snow Layer", "snow", "snow", "snow", { render: "plant", solid: false, hardness: 0.1, tool: "shovel", drop: "snowball", blast: 0, category: "natural" });
blk("bed_block", "Bedroll", "wool_red", "wool_red", "oak_planks", { hardness: 0.6, tool: "axe", category: "functional" });

// ---- Foliage additions ----
blk("fern", "Fern", "fern", "fern", "fern", { render: "plant", solid: false, hardness: 0, tool: "none", drop: null, tint: "grass", blast: 0, category: "natural", flammable: true });
blk("dandelion", "Dandelion", "dandelion", "dandelion", "dandelion", { render: "plant", solid: false, hardness: 0, tool: "none", blast: 0, category: "natural" });
blk("allium", "Allium", "allium", "allium", "allium", { render: "plant", solid: false, hardness: 0, tool: "none", blast: 0, category: "natural" });
blk("cobweb", "Cobweb", "cobweb", "cobweb", "cobweb", { render: "plant", solid: false, hardness: 4, tool: "shears", drop: "string", blast: 4, category: "decoration" });

// ---- Coloured lamps (structures, decoration) ----
blk("lamp_red", "Ruby Lamp", "lamp_red", "lamp_red", "lamp_red", { render: "emissive", hardness: 0.3, light: 15, tool: "none", category: "decoration" });
blk("lamp_blue", "Sapphire Lamp", "lamp_blue", "lamp_blue", "lamp_blue", { render: "emissive", hardness: 0.3, light: 15, tool: "none", category: "decoration" });
blk("lamp_green", "Emerald Lamp", "lamp_green", "lamp_green", "lamp_green", { render: "emissive", hardness: 0.3, light: 15, tool: "none", category: "decoration" });
blk("lamp_gold", "Amber Lamp", "lamp_gold", "lamp_gold", "lamp_gold", { render: "emissive", hardness: 0.3, light: 15, tool: "none", category: "decoration" });
blk("lamp_purple", "Amethyst Lamp", "lamp_purple", "lamp_purple", "lamp_purple", { render: "emissive", hardness: 0.3, light: 15, tool: "none", category: "decoration" });

// ---- Structure blocks ----
blk("chiseled_sandstone", "Chiseled Sandstone", "sandstone_top", "chiseled_sandstone", "sandstone_top", { hardness: 0.8, category: "building" });
blk("tomb_block", "Sarcophagus", "tomb_top", "tomb_side", "sandstone_top", { hardness: 3, blast: 9, category: "decoration" });
blk("magma", "Magma Block", "magma", "magma", "magma", { render: "emissive", hardness: 0.5, light: 4, damage: 1, category: "natural" });
blk("blackstone", "Blackstone", "blackstone", "blackstone", "blackstone", { hardness: 1.5, blast: 6, category: "building" });

/** Coloured light per emitter. Blocks with `light` but no entry here emit warm white. */
const LIGHT_COLORS: Record<string, [number, number, number]> = {
  torch: [1.0, 0.62, 0.3],
  lantern: [1.0, 0.75, 0.4],
  glowstone: [1.0, 0.85, 0.5],
  shroomlight: [1.0, 0.55, 0.25],
  lava: [1.0, 0.38, 0.08],
  magma: [1.0, 0.3, 0.05],
  crystal_blue: [0.3, 0.8, 1.0],
  amethyst: [0.7, 0.35, 1.0],
  nether_portal: [0.6, 0.2, 1.0],
  sift_water: [0.4, 1.0, 0.85],
  prism_glass: [1.0, 0.6, 0.95],
  lamp_red: [1.0, 0.12, 0.1],
  lamp_blue: [0.15, 0.35, 1.0],
  lamp_green: [0.15, 1.0, 0.3],
  lamp_gold: [1.0, 0.7, 0.15],
  lamp_purple: [0.75, 0.2, 1.0],
  red_mushroom: [1.0, 0.4, 0.4],
  brown_mushroom: [0.9, 0.6, 0.4],
};
for (const b of list) {
  if (b.light > 0) b.lightColor = LIGHT_COLORS[b.key] ?? [1, 0.9, 0.75];
  if (b.key === "sand" || b.key === "red_sand" || b.key === "gravel") b.gravity = true;
}

export const BLOCKS: BlockDef[] = list;
export const BLOCK_COUNT = list.length;

/** Key -> numeric id (typed loosely so content can refer to blocks by key). */
export const BID: Record<string, number> = {};
for (const b of list) BID[b.key] = b.id;

export function blockDef(id: number): BlockDef {
  return BLOCKS[id] ?? BLOCKS[0];
}

export function blockIdByKey(key: string): number {
  const id = BID[key];
  return id === undefined ? 0 : id;
}

/** Full opaque cube that hides neighbouring faces. */
export function occludes(id: number): boolean {
  const r = BLOCKS[id]?.render;
  return r === "solid" || r === "emissive";
}

export function isSolidId(id: number): boolean {
  return BLOCKS[id]?.solid ?? false;
}

export function isFluidId(id: number): boolean {
  return BLOCKS[id]?.fluid === true;
}

export function isReplaceable(id: number): boolean {
  const b = BLOCKS[id];
  return !b || b.id === 0 || b.fluid === true || b.render === "plant" || b.render === "torch" || b.render === "portal";
}
