// Entities: voxel model builder (64x64 MC-style skins), mob definitions, AI, combat, spawning, ground items, villagers.

import {
  Color3, Mesh, MeshBuilder, Scene, ShadowGenerator, StandardMaterial, Texture, TransformNode, Vector3, VertexData, InstancedMesh, Material,
} from "../rendering/babylon";
import { BLOCKS, BID, isSolidId } from "../blocks/blocks";
import type { World } from "../world/world";
import type { ItemStack } from "../inventory/inventory";
import { hash2, mulberry32 } from "../world/noise";

// ---- Character & skins -----------------------------------------------------
export interface CharacterOpts {
  skin: string;
  eyes: string;
  hair: string;
  hairStyle: "short" | "ponytail" | "buzz";
  top: string;
  pants: string;
  shoes: string;
  name: string;
}

export const DEFAULT_CHARACTER: CharacterOpts = {
  skin: "#c79a72", eyes: "#4a3420", hair: "#5a3b22", hairStyle: "short",
  top: "#3f7ad0", pants: "#2c3a7a", shoes: "#2a2a2a", name: "Steve",
};

/** Paints a 64x64 MC-layout skin canvas from character options. */
export function paintPlayerSkin(c: CharacterOpts): HTMLCanvasElement {
  const cv = document.createElement("canvas");
  cv.width = 64;
  cv.height = 64;
  const g = cv.getContext("2d")!;
  const rect = (x: number, y: number, w: number, h: number, col: string) => { g.fillStyle = col; g.fillRect(x, y, w, h); };
  const shade = (col: string, k: number) => {
    const n = parseInt(col.slice(1), 16);
    const r = Math.min(255, Math.round(((n >> 16) & 255) * k)), gg = Math.min(255, Math.round(((n >> 8) & 255) * k)), b = Math.min(255, Math.round((n & 255) * k));
    return `rgb(${r},${gg},${b})`;
  };
  // head
  rect(0, 8, 8, 8, c.skin); rect(8, 0, 8, 8, c.skin); rect(16, 8, 8, 8, c.skin); rect(24, 8, 8, 8, c.skin);
  rect(8, 8, 8, 8, c.skin); rect(0, 0, 8, 8, shade(c.skin, 0.95)); rect(16, 0, 8, 8, shade(c.skin, 0.9));
  // face features (front face at 8,8)
  rect(10, 12, 2, 2, "#ffffff"); rect(14, 12, 2, 2, "#ffffff");
  rect(11, 12, 1, 2, c.eyes); rect(14, 12, 1, 2, c.eyes);
  rect(11, 16, 4, 1, shade(c.skin, 0.7));
  // hair (top + front fringe)
  rect(8, 0, 8, 8, c.hair); rect(0, 0, 8, 8, shade(c.hair, 0.8)); rect(16, 0, 8, 8, shade(c.hair, 0.8));
  rect(8, 8, 8, 2, c.hair);
  if (c.hairStyle === "ponytail") rect(24, 8, 8, 6, c.hair);
  if (c.hairStyle === "buzz") rect(8, 0, 8, 2, shade(c.hair, 0.6));
  // body
  rect(20, 20, 8, 12, c.top); rect(16, 20, 4, 12, shade(c.top, 0.85)); rect(28, 20, 4, 12, shade(c.top, 0.85));
  rect(20, 16, 8, 4, c.top); rect(28, 16, 8, 4, c.top);
  rect(24, 20, 4, 12, shade(c.top, 0.92));
  rect(16, 32, 8, 4, shade(c.top, 0.9));
  // belt
  rect(16, 30, 24, 2, "#3a2a1a");
  // arms (right arm 40,16 / left arm 32,48) — sleeves use top color
  rect(44, 20, 4, 12, c.top); rect(48, 20, 4, 12, c.top); rect(40, 20, 4, 12, c.skin); rect(52, 20, 4, 12, c.skin);
  rect(44, 16, 4, 4, c.top); rect(48, 16, 4, 4, c.top);
  rect(36, 20, 4, 12, c.top); rect(32, 20, 4, 12, c.top); rect(40, 52, 4, 12, c.top);
  rect(36, 48, 4, 4, c.top);
  rect(32, 52, 4, 12, c.skin); rect(36, 52, 4, 12, c.skin);
  rect(44, 52, 4, 12, c.skin);
  // hands
  rect(44, 32, 4, 4, c.skin); rect(36, 32, 4, 4, c.skin);
  // legs (right leg 4,20 / left leg 20,52)
  for (const [x, y] of [[4, 20], [20, 52]] as const) {
    rect(x, y, 4, 12, c.pants);
    rect(x + 4, y, 4, 12, shade(c.pants, 0.9));
    rect(x + 8, y, 4, 12, shade(c.pants, 0.95));
    rect(x - 4, y, 4, 12, shade(c.pants, 0.85));
    rect(x, y + 8, 12, 4, shade(c.pants, 0.7));
  }
  rect(0, 16, 4, 4, c.pants); rect(4, 16, 4, 4, c.pants); rect(8, 16, 4, 4, c.pants); rect(12, 16, 4, 4, c.pants);
  rect(0, 28, 4, 4, c.shoes); rect(4, 28, 4, 4, c.shoes); rect(16, 28, 4, 4, c.shoes); rect(20, 28, 4, 4, c.shoes);
  rect(4, 20, 4, 12, c.pants); rect(20, 52, 4, 12, c.pants);
  rect(4, 28, 4, 4, c.shoes); rect(20, 60, 4, 4, c.shoes);
  return cv;
}

// ---- Mob definitions -----------------------------------------------------------
type Anim = "legA" | "legB" | "armA" | "armB" | "head" | "wingL" | "wingR" | "orbit" | "bob" | null;
interface PartSpec {
  n: string;
  s: [number, number, number];
  p: [number, number, number];
  uv: [number, number];
  a?: Anim;
  glow?: boolean;
}

export interface MobDef {
  key: string;
  name: string;
  hp: number;
  speed: number;
  damage: number;
  hostile: boolean;
  flying?: boolean;
  ranged?: "arrow" | "fireball";
  explodes?: boolean;
  teleports?: boolean;
  drops: [string, number, number][];
  xp: number;
  height: number;
  parts: PartSpec[];
  color: string;
  accent: string;
  sound: { idle: string; hurt: string; death: string; step: string };
  scale?: number;
}

const HUMAN_PARTS: PartSpec[] = [
  { n: "legR", s: [0.25, 0.75, 0.25], p: [-0.125, 0.75, 0], uv: [0, 16], a: "legB" },
  { n: "legL", s: [0.25, 0.75, 0.25], p: [0.125, 0.75, 0], uv: [16, 48], a: "legA" },
  { n: "body", s: [0.5, 0.75, 0.25], p: [0, 1.5, 0], uv: [16, 16] },
  { n: "armR", s: [0.25, 0.75, 0.25], p: [-0.375, 1.5, 0], uv: [40, 16], a: "armA" },
  { n: "armL", s: [0.25, 0.75, 0.25], p: [0.375, 1.5, 0], uv: [32, 48], a: "armB" },
  { n: "head", s: [0.5, 0.5, 0.5], p: [0, 1.5, 0], uv: [0, 0], a: "head" },
];

const QUAD_PARTS = (bodyColorUV: [number, number]): PartSpec[] => [
  { n: "legFR", s: [0.22, 0.45, 0.22], p: [-0.25, 0.45, -0.38], uv: [0, 16], a: "legA" },
  { n: "legFL", s: [0.22, 0.45, 0.22], p: [0.25, 0.45, -0.38], uv: [16, 48], a: "legB" },
  { n: "legBR", s: [0.22, 0.45, 0.22], p: [-0.25, 0.45, 0.38], uv: [0, 16], a: "legB" },
  { n: "legBL", s: [0.22, 0.45, 0.22], p: [0.25, 0.45, 0.38], uv: [16, 48], a: "legA" },
  { n: "body", s: [0.7, 0.62, 1.0], p: [0, 1.07, 0], uv: bodyColorUV },
  { n: "head", s: [0.5, 0.5, 0.5], p: [0, 1.1, -0.62], uv: [0, 0], a: "head" },
];

export const MOBS: Record<string, MobDef> = {
  pig: {
    key: "pig", name: "Pig", hp: 10, speed: 1.1, damage: 0, hostile: false, drops: [["raw_porkchop", 1, 3]], xp: 1, height: 0.9,
    parts: QUAD_PARTS([0, 32]), color: "#e8a0a0", accent: "#c07070", sound: { idle: "oink", hurt: "oink", death: "oink", step: "step_grass" },
  },
  cow: {
    key: "cow", name: "Cow", hp: 10, speed: 1.0, damage: 0, hostile: false, drops: [["raw_beef", 1, 3], ["leather", 0, 2]], xp: 1, height: 1.3,
    parts: QUAD_PARTS([0, 32]).map((p) => (p.n === "body" ? { ...p, s: [0.85, 0.9, 1.4] as [number, number, number], p: [0, 1.25, 0] as [number, number, number] } : p.n === "head" ? { ...p, p: [0, 1.35, -0.85] as [number, number, number], s: [0.6, 0.6, 0.6] as [number, number, number] } : p)),
    color: "#f2f2f2", accent: "#3a2a1a", sound: { idle: "moo", hurt: "moo", death: "moo", step: "step_grass" }, scale: 1.1,
  },
  sheep: {
    key: "sheep", name: "Sheep", hp: 8, speed: 1.0, damage: 0, hostile: false, drops: [["wool_white", 1, 1]], xp: 1, height: 1.0,
    parts: QUAD_PARTS([0, 32]), color: "#eaeaea", accent: "#c0b080", sound: { idle: "baa", hurt: "baa", death: "baa", step: "step_grass" },
  },
  chicken: {
    key: "chicken", name: "Chicken", hp: 4, speed: 1.2, damage: 0, hostile: false, drops: [["raw_chicken", 1, 1], ["feather", 0, 2]], xp: 1, height: 0.7,
    parts: [
      { n: "legL", s: [0.08, 0.25, 0.08], p: [0.08, 0.25, 0], uv: [0, 16], a: "legA" },
      { n: "legR", s: [0.08, 0.25, 0.08], p: [-0.08, 0.25, 0], uv: [16, 48], a: "legB" },
      { n: "body", s: [0.35, 0.35, 0.45], p: [0, 0.6, 0], uv: [0, 32] },
      { n: "wingL", s: [0.05, 0.25, 0.3], p: [0.2, 0.6, 0], uv: [40, 16], a: "wingL" },
      { n: "wingR", s: [0.05, 0.25, 0.3], p: [-0.2, 0.6, 0], uv: [40, 16], a: "wingR" },
      { n: "head", s: [0.25, 0.28, 0.28], p: [0, 0.78, -0.22], uv: [0, 0], a: "head" },
    ],
    color: "#f2f2f2", accent: "#d43a2a", sound: { idle: "cluck", hurt: "cluck", death: "cluck", step: "step_grass" }, scale: 1,
  },
  zombie: {
    key: "zombie", name: "Zombie", hp: 20, speed: 1.6, damage: 3, hostile: true, drops: [["rotten_flesh", 0, 2], ["iron_ingot", 0, 1]], xp: 5, height: 1.95,
    parts: HUMAN_PARTS, color: "#4a8a4a", accent: "#2a4a6a", sound: { idle: "zombie", hurt: "hurt", death: "death", step: "step_grass" },
  },
  skeleton: {
    key: "skeleton", name: "Skeleton", hp: 20, speed: 1.4, damage: 2, hostile: true, ranged: "arrow", drops: [["bone", 0, 2], ["arrow", 0, 2]], xp: 5, height: 1.95,
    parts: HUMAN_PARTS, color: "#dedad0", accent: "#7a7a7a", sound: { idle: "skeleton", hurt: "hurt", death: "death", step: "step_stone" },
  },
  creeper: {
    key: "creeper", name: "Creeper", hp: 20, speed: 1.5, damage: 0, hostile: true, explodes: true, drops: [["gunpowder", 0, 2]], xp: 5, height: 1.7,
    parts: [
      { n: "legFR", s: [0.25, 0.5, 0.25], p: [-0.15, 0.5, -0.15], uv: [0, 16], a: "legA" },
      { n: "legFL", s: [0.25, 0.5, 0.25], p: [0.15, 0.5, -0.15], uv: [16, 48], a: "legB" },
      { n: "legBR", s: [0.25, 0.5, 0.25], p: [-0.15, 0.5, 0.15], uv: [0, 16], a: "legB" },
      { n: "legBL", s: [0.25, 0.5, 0.25], p: [0.15, 0.5, 0.15], uv: [16, 48], a: "legA" },
      { n: "body", s: [0.5, 0.9, 0.25], p: [0, 1.4, 0], uv: [16, 16] },
      { n: "head", s: [0.5, 0.5, 0.5], p: [0, 1.7, 0], uv: [0, 0], a: "head" },
    ],
    color: "#4aa84a", accent: "#1a3a1a", sound: { idle: "hiss", hurt: "hurt", death: "death", step: "step_grass" },
  },
  spider: {
    key: "spider", name: "Spider", hp: 16, speed: 2.1, damage: 2, hostile: true, drops: [["string", 0, 2]], xp: 5, height: 0.9,
    parts: [
      { n: "legA", s: [0.9, 0.08, 0.08], p: [0.2, 0.55, 0.35], uv: [0, 16], a: "legA" },
      { n: "legB", s: [0.9, 0.08, 0.08], p: [-0.2, 0.55, 0.35], uv: [0, 16], a: "legB" },
      { n: "legC", s: [0.9, 0.08, 0.08], p: [0.2, 0.55, -0.1], uv: [0, 16], a: "legB" },
      { n: "legD", s: [0.9, 0.08, 0.08], p: [-0.2, 0.55, -0.1], uv: [0, 16], a: "legA" },
      { n: "body", s: [0.7, 0.5, 0.9], p: [0, 0.8, 0.1], uv: [0, 32] },
      { n: "head", s: [0.5, 0.45, 0.5], p: [0, 0.8, -0.5], uv: [0, 0], a: "head" },
    ],
    color: "#3a2a2a", accent: "#c03a2a", sound: { idle: "hiss", hurt: "hurt", death: "death", step: "step_stone" }, scale: 1.2,
  },
  enderman: {
    key: "enderman", name: "Enderman", hp: 40, speed: 2.0, damage: 7, hostile: true, teleports: true, drops: [["ender_pearl", 0, 1]], xp: 15, height: 2.9,
    parts: [
      { n: "legR", s: [0.2, 1.4, 0.2], p: [-0.1, 1.4, 0], uv: [0, 16], a: "legB" },
      { n: "legL", s: [0.2, 1.4, 0.2], p: [0.1, 1.4, 0], uv: [16, 48], a: "legA" },
      { n: "body", s: [0.45, 0.8, 0.25], p: [0, 2.2, 0], uv: [16, 16] },
      { n: "armR", s: [0.14, 1.3, 0.14], p: [-0.3, 2.2, 0], uv: [40, 16], a: "armA" },
      { n: "armL", s: [0.14, 1.3, 0.14], p: [0.3, 2.2, 0], uv: [32, 48], a: "armB" },
      { n: "head", s: [0.5, 0.5, 0.5], p: [0, 2.9, 0], uv: [0, 0], a: "head" },
    ],
    color: "#1a1a22", accent: "#c06ae0", sound: { idle: "enderman", hurt: "enderman", death: "death", step: "step_stone" },
  },
  blaze: {
    key: "blaze", name: "Blaze", hp: 20, speed: 1.2, damage: 4, hostile: true, flying: true, ranged: "fireball", drops: [["glowstone_dust", 0, 2]], xp: 10, height: 1.8,
    parts: [
      { n: "core", s: [0.4, 0.4, 0.4], p: [0, 1.8, 0], uv: [0, 0], glow: true, a: "bob" },
      { n: "r1", s: [0.18, 0.18, 0.18], p: [0.5, 1.8, 0], uv: [0, 0], glow: true, a: "orbit" },
      { n: "r2", s: [0.18, 0.18, 0.18], p: [-0.5, 1.8, 0], uv: [0, 0], glow: true, a: "orbit" },
      { n: "r3", s: [0.18, 0.18, 0.18], p: [0, 1.8, 0.5], uv: [0, 0], glow: true, a: "orbit" },
    ],
    color: "#f6c03a", accent: "#ff7a1a", sound: { idle: "hiss", hurt: "hurt", death: "death", step: "step_stone" },
  },
  prism_jelly: {
    key: "prism_jelly", name: "Prism Jelly", hp: 12, speed: 0.8, damage: 0, hostile: false, flying: true, drops: [["prism_shard", 1, 2]], xp: 3, height: 0.8,
    parts: [{ n: "core", s: [0.7, 0.7, 0.7], p: [0, 0.9, 0], uv: [0, 0], glow: true, a: "bob" }],
    color: "#ff9ad6", accent: "#7af0ff", sound: { idle: "pop", hurt: "pop", death: "pop", step: "step_grass" },
  },
  wisp: {
    key: "wisp", name: "Aether Wisp", hp: 6, speed: 0.9, damage: 0, hostile: false, flying: true, drops: [["crystal_shard", 1, 1]], xp: 2, height: 0.5,
    parts: [{ n: "core", s: [0.3, 0.3, 0.3], p: [0, 0.8, 0], uv: [0, 0], glow: true, a: "bob" }],
    color: "#9ff0ff", accent: "#ffffff", sound: { idle: "pop", hurt: "pop", death: "pop", step: "step_grass" },
  },
  sky_ray: {
    key: "sky_ray", name: "Sky Ray", hp: 14, speed: 1.2, damage: 2, hostile: false, flying: true, drops: [["feather", 1, 2]], xp: 3, height: 0.6,
    parts: [
      { n: "wingL", s: [1.2, 0.08, 0.6], p: [0.5, 0.9, 0], uv: [0, 0], a: "wingL" },
      { n: "wingR", s: [1.2, 0.08, 0.6], p: [-0.5, 0.9, 0], uv: [0, 0], a: "wingR" },
      { n: "body", s: [0.3, 0.2, 0.5], p: [0, 0.95, 0], uv: [0, 0], a: "bob" },
    ],
    color: "#6ab0e0", accent: "#e8f4ff", sound: { idle: "pop", hurt: "pop", death: "pop", step: "step_grass" },
  },
  villager: {
    key: "villager", name: "Villager", hp: 20, speed: 0.9, damage: 0, hostile: false, drops: [], xp: 0, height: 1.95,
    parts: HUMAN_PARTS, color: "#8a6a4a", accent: "#e8c8a0", sound: { idle: "dialogue", hurt: "hurt", death: "death", step: "step_stone" },
  },
};

export const VILLAGER_LINES: Record<string, string[]> = {
  default: [
    "Welcome, traveller! The night is restless this season.",
    "Have you seen the Nether portal? Built from obsidian, lit with flint and steel.",
    "The lake to the north glows at dawn. Worth the walk.",
    "Keep torches near your beds. Zombies don't like the light.",
    "Our chests hold more than you think. Ask nicely.",
  ],
  weather: [
    "Thunder over the hills again. Stay inside when the sky cracks!",
    "Snow comes in winter. Grass turns pale and the lakes freeze over.",
    "Autumn leaves smell like cinnamon. Or maybe that's the bakery.",
  ],
  dimension: [
    "The Sift is said to hum after dark. Its water stings, though!",
    "The Aether frames glow with the ender pearl's blessing.",
    "Some say the End hides a dragon. I have never met one, thankfully.",
  ],
};

// ---- Model building -------------------------------------------------------------
function boxData(s: [number, number, number], uv: [number, number], tex = 64): VertexData {
  const [w0, h0, d0] = s;
  const hw = w0 / 2, hd = d0 / 2;
  const h = h0;
  // MC-style UV layout at (u,v); sizes in skin pixels (16 px per block), not world units
  const w = Math.max(1, Math.round(w0 * 16)), d = Math.max(1, Math.round(d0 * 16));
  const hp = Math.max(1, Math.round(h0 * 16));
  const [u, v] = uv;
  const rects: Record<string, [number, number, number, number]> = {
    top: [u + d, v, u + d + w, v + d],
    bottom: [u + d + w, v, u + d + 2 * w, v + d],
    right: [u, v + d, u + d, v + d + h],
    front: [u + d, v + d, u + d + w, v + d + h],
    left: [u + d + w, v + d, u + 2 * d + w, v + d + hp],
    back: [u + 2 * d + w, v + d, u + 2 * d + 2 * w, v + d + hp],
  };
  rects.right[3] = v + d + hp;
  rects.front[3] = v + d + hp;
  const pos: number[] = [], nor: number[] = [], uvs: number[] = [], idx: number[] = [];
  const quad = (p: number[][], n: number[], r: [number, number, number, number]) => {
    const base = pos.length / 3;
    const [u0, v0, u1, v1] = [r[0] / tex, r[1] / tex, r[2] / tex, r[3] / tex];
    const t = [[u0, v1], [u1, v1], [u1, v0], [u0, v0]];
    for (let i = 0; i < 4; i++) {
      pos.push(p[i][0], p[i][1], p[i][2]);
      nor.push(n[0], n[1], n[2]);
      uvs.push(t[i][0], t[i][1]);
    }
    idx.push(base, base + 2, base + 1, base, base + 3, base + 2);
  };
  quad([[-hw, h, -hd], [hw, h, -hd], [hw, h, hd], [-hw, h, hd]], [0, 1, 0], rects.top);
  quad([[-hw, 0, hd], [hw, 0, hd], [hw, 0, -hd], [-hw, 0, -hd]], [0, -1, 0], rects.bottom);
  quad([[-hw, 0, -hd], [-hw, h, -hd], [-hw, h, hd], [-hw, 0, hd]], [-1, 0, 0], rects.right);
  quad([[-hw, 0, -hd], [hw, 0, -hd], [hw, h, -hd], [-hw, h, -hd]], [0, 0, -1], rects.front);
  quad([[hw, 0, -hd], [hw, 0, hd], [hw, h, hd], [hw, h, -hd]], [1, 0, 0], rects.left);
  quad([[hw, 0, hd], [-hw, 0, hd], [-hw, h, hd], [hw, h, hd]], [0, 0, 1], rects.back);
  const vd = new VertexData();
  vd.positions = pos;
  vd.normals = nor;
  vd.uvs = uvs;
  vd.indices = idx;
  return vd;
}

/** Template: part meshes keyed by name, all hanging from their pivot (top-centre, y=0 at top). */
interface Template {
  parts: Map<string, Mesh>;
  def: MobDef;
}
const templates = new Map<string, Template>();
const skinTextures = new Map<string, Texture>();
let skinCacheOwner: Scene | null = null;

function mobSkinCanvas(def: MobDef): HTMLCanvasElement {
  const cv = document.createElement("canvas");
  cv.width = 64;
  cv.height = 64;
  const g = cv.getContext("2d")!;
  g.fillStyle = def.color;
  g.fillRect(0, 0, 64, 64);
  const rnd = mulberry32(hash2(def.color.length, def.name.length, 9) * 1e6 | 0);
  for (let i = 0; i < 40; i++) {
    g.fillStyle = `rgba(${Math.floor(rnd() * 255)},${Math.floor(rnd() * 255)},${Math.floor(rnd() * 255)},0.12)`;
    g.fillRect(Math.floor(rnd() * 64), Math.floor(rnd() * 64), 2, 2);
  }
  // accent detailing
  g.fillStyle = def.accent;
  g.fillRect(8, 0, 8, 8);
  g.fillRect(0, 16, 16, 4);
  g.fillStyle = "#101010";
  if (def.hostile || def.key === "pig" || def.key === "cow" || def.key === "villager" || def.key === "creeper") {
    g.fillRect(10, 12, 2, 2);
    g.fillRect(14, 12, 2, 2);
  }
  if (def.key === "creeper") {
    g.fillStyle = "#1a3a1a";
    g.fillRect(10, 16, 4, 4);
  }
  return cv;
}

export function skinTextureFor(scene: Scene, key: string, canvas: HTMLCanvasElement): Texture {
  let t = skinTextures.get(key);
  if (!t || skinCacheOwner !== scene) {
    t = new Texture(canvas.toDataURL("image/png"), scene, false, false, Texture.NEAREST_NEAREST_MIPLINEAR);
    skinTextures.set(key, t);
    skinCacheOwner = scene;
  }
  return t;
}

const EYE_GLOW: Record<string, string> = {
  zombie: "#8aff5a", skeleton: "#c8e8ff", creeper: "#3aff3a", spider: "#ff2a2a", enderman: "#e070ff", blaze: "#ffcf40",
  villager: "#5aa0ff", pig: "#ff9ab0", cow: "#ffffff", sheep: "#d8d8ff", chicken: "#ffd040",
  prism_jelly: "#ff9ae0", wisp: "#bff6ff", sky_ray: "#a0e0ff",
};

function eyeCanvas(def: MobDef): HTMLCanvasElement {
  const cv = document.createElement("canvas");
  cv.width = 64;
  cv.height = 64;
  const g = cv.getContext("2d")!;
  g.fillStyle = "#000000";
  g.fillRect(0, 0, 64, 64);
  g.fillStyle = EYE_GLOW[def.key] ?? "#ffffff";
  g.globalAlpha = def.hostile ? 1 : 0.45;
  g.fillRect(10, 12, 2, 2);
  g.fillRect(14, 12, 2, 2);
  if (def.key === "spider") { g.fillRect(9, 10, 1, 1); g.fillRect(16, 10, 1, 1); g.fillRect(11, 14, 1, 1); g.fillRect(14, 14, 1, 1); }
  if (def.key === "enderman") { g.fillRect(9, 12, 7, 1); }
  return cv;
}

function getTemplate(scene: Scene, def: MobDef): Template {
  const cached = templates.get(def.key);
  if (cached && skinCacheOwner === scene) return cached;
  const tex = skinTextureFor(scene, `mob_${def.key}`, mobSkinCanvas(def));
  const mat = new StandardMaterial(`mat_mob_${def.key}`, scene);
  mat.diffuseTexture = tex;
  mat.specularColor = new Color3(0, 0, 0);
  mat.backFaceCulling = false;
  // emissive eyes: a black texture with only the eye pixels coloured, so eyes glow in the dark (and bloom)
  mat.emissiveTexture = skinTextureFor(scene, `eyes_${def.key}`, eyeCanvas(def));
  const glowMat = new StandardMaterial(`mat_glow_${def.key}`, scene);
  glowMat.diffuseTexture = tex;
  glowMat.emissiveColor = new Color3(0.9, 0.7, 0.3);
  glowMat.disableLighting = true;
  const parts = new Map<string, Mesh>();
  for (const p of def.parts) {
    const vd = boxData(p.s, p.uv);
    const m = new Mesh(`tpl_${def.key}_${p.n}`, scene);
    vd.applyToMesh(m);
    // pivot at top-centre: shift so y=0 is the top of the part
    m.position.y = -p.s[1] / 2 * 0; // boxData is already anchored from y=0 (bottom) to h (top)
    m.material = p.glow ? glowMat : mat;
    m.isVisible = false;
    m.isPickable = false;
    m.alwaysSelectAsActiveMesh = false;
    parts.set(p.n, m);
  }
  const tpl = { parts, def };
  templates.set(def.key, tpl);
  return tpl;
}

// ---- Entities ----------------------------------------------------------------------
let nextId = 1;

export class Mob {
  id = nextId++;
  readonly def: MobDef;
  root: TransformNode;
  pos: Vector3;
  vel = new Vector3();
  yaw = Math.random() * Math.PI * 2;
  hp: number;
  onGround = false;
  walkPhase = 0;
  wanderTimer = 0;
  wanderTarget: Vector3 | null = null;
  attackCd = 0;
  fuse = 0;
  shootCd = 2 + Math.random() * 2;
  fleeTimer = 0;
  hurtFlash = 0;
  dead = false;
  home: Vector3;
  dialogueIdx = 0;
  nodes: { node: TransformNode; part: PartSpec }[] = [];
  age = 0;
  constructor(scene: Scene, def: MobDef, pos: Vector3) {
    this.def = def;
    this.hp = def.hp;
    this.pos = pos.clone();
    this.home = pos.clone();
    this.root = new TransformNode(`mob_${def.key}_${this.id}`, scene);
    const tpl = getTemplate(scene, def);
    for (const p of def.parts) {
      const src = tpl.parts.get(p.n)!;
      const inst = src.createInstance(`${def.key}_${this.id}_${p.n}`);
      const pivot = new TransformNode(`piv_${this.id}_${p.n}`, scene);
      pivot.parent = this.root;
      pivot.position.set(p.p[0], p.p[1] - p.s[1], p.p[2]);
      inst.parent = pivot;
      inst.position.set(0, 0, 0);
      inst.isPickable = false;
      this.nodes.push({ node: pivot, part: p });
    }
    const sc = def.scale ?? 1;
    this.root.scaling.setAll(sc);
  }
}

export interface ItemEntityRec {
  id: number;
  stack: ItemStack;
  root: Mesh;
  pos: Vector3;
  vel: Vector3;
  age: number;
  onGround: boolean;
}

export interface ArrowRec {
  mesh: Mesh;
  pos: Vector3;
  vel: Vector3;
  life: number;
  damage: number;
  fireball: boolean;
}

export interface EntityHooks {
  damagePlayer(amount: number, source: string, from: Vector3): void;
  explode(pos: Vector3, radius: number, sourceId: number): void;
  isPlayerSleepingOrCreative(): boolean;
  playerPos(): Vector3;
  playerLookingAt(pos: Vector3): boolean;
  dayFraction(): number;
  difficulty(): string;
  sound(name: string, pos: Vector3, pitch?: number): void;
  xp(amount: number): void;
  iconFor(key: string): string;
  spawnDrops(pos: Vector3, key: string, count: number): void;
}

export class EntityManager {
  mobs: Mob[] = [];
  items: ItemEntityRec[] = [];
  projectiles: ArrowRec[] = [];
  private scene: Scene;
  private world: World;
  private hooks: EntityHooks;
  private shadowGen: ShadowGenerator | null = null;
  private iconTex = new Map<string, Texture>();
  private spawnTimer = 0;
  private villagerLineIdx = 0;

  constructor(scene: Scene, world: World, hooks: EntityHooks) {
    this.scene = scene;
    this.world = world;
    this.hooks = hooks;
  }

  setWorld(world: World): void {
    this.world = world;
  }

  setShadowGenerator(sg: ShadowGenerator): void {
    this.shadowGen = sg;
  }

  spawnKind(kind: string, x: number, y: number, z: number): Mob | null {
    const def = MOBS[kind];
    if (!def) return null;
    const m = new Mob(this.scene, def, new Vector3(x, y, z));
    this.mobs.push(m);
    return m;
  }

  /** Spawns from chunk generation records (villagers, animals). */
  spawnFromRecords(records: { kind: string; x: number; y: number; z: number }[]): void {
    for (const r of records) {
      if (r.kind === "villager") this.spawnKind("villager", r.x, r.y, r.z);
      else if (r.kind.startsWith("animal:")) {
        if (Math.random() < 0.7) this.spawnKind(r.kind.slice(7), r.x, r.y, r.z);
      } else if (r.kind.startsWith("hostile:")) {
        if (Math.random() < 0.4) this.spawnKind(r.kind.slice(8), r.x, r.y, r.z);
      }
    }
  }

  spawnItem(stack: ItemStack, pos: Vector3, vel?: Vector3): void {
    const root = Mesh.CreatePlane(`drop_${nextId}`, 0.42, this.scene);
    root.billboardMode = Mesh.BILLBOARDMODE_Y;
    const mat = new StandardMaterial(`dropMat_${nextId}`, this.scene);
    mat.diffuseTexture = this.iconTexture(stack.key);
    mat.useAlphaFromDiffuseTexture = true;
    mat.transparencyMode = Material.MATERIAL_ALPHATEST;
    mat.emissiveColor = new Color3(0.25, 0.25, 0.25);
    mat.backFaceCulling = false;
    root.material = mat;
    root.isPickable = false;
    this.items.push({ id: nextId++, stack, root, pos: pos.clone(), vel: vel ? vel.clone() : new Vector3((Math.random() - 0.5) * 2, 3, (Math.random() - 0.5) * 2), age: 0, onGround: false });
  }

  private iconTexture(key: string): Texture {
    let t = this.iconTex.get(key);
    if (!t) {
      t = new Texture(this.hooks.iconFor(key), this.scene, false, false, Texture.NEAREST_NEAREST_MIPLINEAR);
      this.iconTex.set(key, t);
    }
    return t;
  }

  /** Main update. Returns the number of hostile mobs alive (for spawn caps). */
  update(dt: number, time: number, peaceful: boolean): void {
    const pp = this.hooks.playerPos();
    this.updateMobs(dt, pp, peaceful);
    this.updateDying(dt);
    this.updateItems(dt, pp);
    this.updateProjectiles(dt, pp);
    this.spawnTimer -= dt;
    if (this.spawnTimer <= 0 && !peaceful) {
      this.spawnTimer = 1.2;
      this.trySpawnHostile(pp);
    }
    // despawn far hostiles
    for (const m of this.mobs) {
      if (m.dead) continue;
      if (m.def.hostile && Vector3.Distance(m.pos, pp) > 96) this.kill(m, false);
    }
    this.mobs = this.mobs.filter((m) => !m.dead);
    void time;
  }

  private trySpawnHostile(pp: Vector3): void {
    const hostileCount = this.mobs.filter((m) => m.def.hostile).length;
    const cap = this.hooks.dayFraction() > 0.5 && this.hooks.dayFraction() < 1 ? 16 : 6;
    if (hostileCount >= cap) return;
    const ang = Math.random() * Math.PI * 2;
    const dist = 22 + Math.random() * 14;
    const x = Math.floor(pp.x + Math.cos(ang) * dist), z = Math.floor(pp.z + Math.sin(ang) * dist);
    const top = this.world.surfaceY(x, z);
    if (top < 3) return;
    const biomeDark = this.hooks.dayFraction() > 0.5 && this.hooks.dayFraction() < 1;
    const kinds = biomeDark ? ["zombie", "skeleton", "creeper", "spider"] : ["zombie", "skeleton", "spider"];
    const kind = kinds[Math.floor(Math.random() * kinds.length)];
    const mob = this.spawnKind(kind, x + 0.5, top + 1, z + 0.5);
    if (mob && this.world.getBlock(x, top, z) === BID.water) mob.def; // water spawns are ignored by design
  }

  private updateMobs(dt: number, pp: Vector3, peaceful: boolean): void {
    for (const m of this.mobs) {
      if (m.dead) continue;
      m.age += dt;
      const def = m.def;
      const toPlayer = pp.subtract(m.pos);
      toPlayer.y = 0;
      const distP = toPlayer.length();
      let target: Vector3 | null = null;
      let speed = def.speed;
      m.attackCd -= dt;
      m.shootCd -= dt;
      m.hurtFlash = Math.max(0, m.hurtFlash - dt);

      if (def.key === "villager") {
        m.wanderTimer -= dt;
        if (m.wanderTimer <= 0) {
          m.wanderTimer = 4 + Math.random() * 6;
          const a = Math.random() * Math.PI * 2, r = Math.random() * 6;
          m.wanderTarget = new Vector3(m.home.x + Math.cos(a) * r, m.home.y, m.home.z + Math.sin(a) * r);
        }
        if (distP < 3.2 && distP > 0.01) {
          m.yaw = Math.atan2(toPlayer.x, toPlayer.z);
          m.wanderTarget = null;
        }
        target = m.wanderTarget;
        speed = 0.9;
      } else if (def.hostile && !peaceful && distP < 18 && !def.flying) {
        target = pp;
        speed = def.speed;
      } else if (def.flying && def.hostile && !peaceful && distP < 20) {
        target = pp;
        speed = def.speed * 0.9;
      } else if (m.fleeTimer > 0) {
        m.fleeTimer -= dt;
        target = m.pos.add(m.pos.subtract(pp));
        speed = def.speed * 1.9;
      } else {
        m.wanderTimer -= dt;
        if (m.wanderTimer <= 0) {
          m.wanderTimer = 2.5 + Math.random() * 4;
          if (Math.random() < 0.55) {
            const a = Math.random() * Math.PI * 2, r = 4 + Math.random() * 6;
            m.wanderTarget = new Vector3(m.home.x + Math.cos(a) * r, m.pos.y, m.home.z + Math.sin(a) * r);
          } else m.wanderTarget = null;
        }
        target = m.wanderTarget;
        speed = def.speed * 0.6;
      }

      // creeper: fuse when close
      if (def.explodes && !peaceful && distP < 3.2) {
        m.fuse += dt;
        this.hooks.sound("creeper_fuse", m.pos);
        if (m.fuse > 1.5) {
          this.hooks.explode(m.pos.add(new Vector3(0, 0.9, 0)), 3.2, m.id);
          this.kill(m, false);
          continue;
        }
      } else if (def.explodes) m.fuse = Math.max(0, m.fuse - dt);

      // enderman teleports when hit or when watched
      if (def.teleports && !peaceful && this.hooks.playerLookingAt(m.pos.add(new Vector3(0, 1.5, 0))) && distP < 20 && Math.random() < dt * 0.6) {
        this.teleportMob(m, 10);
      }

      // ranged attacks
      if (def.ranged && !peaceful && distP < 14 && distP > 3 && m.shootCd <= 0) {
        m.shootCd = def.ranged === "fireball" ? 2.8 : 2.2;
        this.fireProjectile(m, pp, def.ranged === "fireball");
      }

      // movement
      if (target) {
        const dir = target.subtract(m.pos);
        dir.y = 0;
        const d = dir.length();
        if (d > 0.6) {
          dir.scaleInPlace(1 / d);
          m.yaw = Math.atan2(dir.x, dir.z);
          m.vel.x = dir.x * speed;
          m.vel.z = dir.z * speed;
        } else {
          m.vel.x *= 0.6;
          m.vel.z *= 0.6;
          if (target === pp && m.attackCd <= 0 && def.damage > 0 && distP < 2) {
            m.attackCd = 1.0;
            this.hooks.damagePlayer(def.damage, def.key, m.pos);
          }
        }
        if (target === pp && def.damage > 0 && distP < 1.8 && m.attackCd <= 0 && !def.explodes) {
          m.attackCd = 1.0;
          this.hooks.damagePlayer(def.damage, def.key, m.pos);
        }
      } else {
        m.vel.x *= 0.7;
        m.vel.z *= 0.7;
      }
      if (def.flying) {
        // hover around 2.2 blocks above ground
        const ground = this.world.surfaceY(Math.floor(m.pos.x), Math.floor(m.pos.z));
        const desired = ground + (def.key === "blaze" ? 4 : def.key === "sky_ray" ? 6 : 2.5);
        m.vel.y += (desired - m.pos.y) * dt * 2;
        m.vel.y *= 0.92;
      } else {
        this.applyPhysics(m, dt);
      }
      // move with collision
      this.moveEntity(m, dt);
      // walk animation
      const horizSpeed = Math.hypot(m.vel.x, m.vel.z);
      m.walkPhase += horizSpeed * dt * 4.2;
      this.animate(m, horizSpeed, dt);
      m.root.position.copyFrom(m.pos);
      m.root.rotation.y = m.yaw;
      if (m.hurtFlash > 0) m.root.scaling.setAll((def.scale ?? 1) * (1 + Math.sin(m.hurtFlash * 40) * 0.03));
      else m.root.scaling.setAll(def.scale ?? 1);
    }
  }

  private applyPhysics(m: Mob, dt: number): void {
    const inWater = this.isFluidAt(m.pos.x, m.pos.y + 0.5, m.pos.z);
    if (inWater) {
      m.vel.y += 6 * dt;
      m.vel.y = Math.min(m.vel.y, 2.5);
    } else {
      m.vel.y -= 28 * dt;
    }
    if (m.onGround && m.vel.y < 0) m.vel.y = 0;
  }

  private isFluidAt(x: number, y: number, z: number): boolean {
    const id = this.world.getBlock(Math.floor(x), Math.floor(y), Math.floor(z));
    return id === BID.water || id === BID.toxic_water || id === BID.sift_water;
  }

  private moveEntity(m: Mob, dt: number): void {
    const hw = 0.3 * (m.def.scale ?? 1), h = m.def.height * (m.def.scale ?? 1);
    const solid = (x: number, y: number, z: number) => {
      const id = this.world.getBlock(Math.floor(x), Math.floor(y), Math.floor(z));
      return id === -1 ? true : isSolidId(id);
    };
    const blockedBox = (x: number, y: number, z: number) => {
      for (const [ox, oz] of [[-hw, -hw], [hw, -hw], [-hw, hw], [hw, hw]]) {
        if (solid(x + ox, y, z + oz) || solid(x + ox, y + 0.9, z + oz)) return true;
      }
      return false;
    };
    const p = m.pos;
    // X
    let nx = p.x + m.vel.x * dt;
    if (blockedBox(nx, p.y + 0.05, p.z)) {
      if (m.onGround && !m.def.flying) m.vel.y = 6.2;
      else m.vel.x = 0;
      nx = p.x;
    }
    // Z
    let nz = p.z + m.vel.z * dt;
    if (blockedBox(nx, p.y + 0.05, nz)) {
      if (m.onGround && !m.def.flying) m.vel.y = 6.2;
      else m.vel.z = 0;
      nz = p.z;
    }
    // Y
    let ny = p.y + m.vel.y * dt;
    m.onGround = false;
    if (m.vel.y <= 0) {
      const feetBlocked = [[-hw, -hw], [hw, -hw], [-hw, hw], [hw, hw]].some(([ox, oz]) => solid(nx + ox, ny, nz + oz));
      if (feetBlocked) {
        ny = Math.floor(ny) + 1;
        m.vel.y = 0;
        m.onGround = true;
      }
    } else {
      const headBlocked = [[-hw, -hw], [hw, -hw], [-hw, hw], [hw, hw]].some(([ox, oz]) => solid(nx + ox, ny + h, nz + oz));
      if (headBlocked) m.vel.y = 0;
    }
    p.set(nx, ny, nz);
    if (p.y < -20) this.kill(m, false);
  }

  private animate(m: Mob, speed: number, dt: number): void {
    const amp = Math.min(0.9, speed * 0.6);
    m.nodes.forEach(({ node, part }) => {
      const a = part.a;
      const s = Math.sin(m.walkPhase);
      switch (a) {
        case "legA": node.rotation.x = s * amp; break;
        case "legB": node.rotation.x = -s * amp; break;
        case "armA": node.rotation.x = -s * amp * 0.8; break;
        case "armB": node.rotation.x = s * amp * 0.8; break;
        case "head": node.rotation.x = 0.05; break;
        case "wingL": node.rotation.z = Math.sin(m.age * 14) * 0.7 - 0.2; break;
        case "wingR": node.rotation.z = -Math.sin(m.age * 14) * 0.7 + 0.2; break;
        case "bob": node.position.y = (part.p[1] - part.s[1]) + Math.sin(m.age * 2.4) * 0.12; break;
        case "orbit": {
          const r = part.p[0] !== 0 ? part.p[0] : part.p[2];
          const ang = m.age * 2.2 + (part.p[0] !== 0 ? 0 : 1.6);
          node.position.x = Math.cos(ang) * r;
          node.position.z = Math.sin(ang) * r;
          node.position.y = (part.p[1] - part.s[1]) + Math.sin(m.age * 3) * 0.15;
          break;
        }
        default: break;
      }
    });
    void dt;
  }

  private teleportMob(m: Mob, range: number): void {
    const a = Math.random() * Math.PI * 2;
    const nx = m.pos.x + Math.cos(a) * range, nz = m.pos.z + Math.sin(a) * range;
    const top = this.world.surfaceY(Math.floor(nx), Math.floor(nz));
    if (top < 3) return;
    this.hooks.sound("enderman", m.pos, 1);
    m.pos.set(nx, top + 1, nz);
  }

  private fireProjectile(m: Mob, pp: Vector3, fireball: boolean): void {
    const origin = m.pos.add(new Vector3(0, m.def.height * 0.7, 0));
    const dir = pp.add(new Vector3(0, 1.2, 0)).subtract(origin);
    const len = Math.max(0.01, dir.length());
    dir.scaleInPlace(1 / len);
    const mesh = MeshBuilder.CreateSphere(`proj_${nextId}`, { diameter: fireball ? 0.5 : 0.12, segments: 4 }, this.scene);
    const mat = new StandardMaterial(`projMat_${nextId}`, this.scene);
    mat.emissiveColor = fireball ? new Color3(1, 0.6, 0.1) : new Color3(0.9, 0.9, 0.8);
    mat.disableLighting = true;
    mesh.material = mat;
    mesh.isPickable = false;
    this.projectiles.push({ mesh, pos: origin, vel: dir.scale(fireball ? 9 : 22), life: 5, damage: fireball ? 4 : 3, fireball });
    this.hooks.sound(fireball ? "hiss" : "shoot", origin);
    nextId++;
  }

  private updateProjectiles(dt: number, pp: Vector3): void {
    for (const pr of this.projectiles) {
      pr.life -= dt;
      pr.vel.y -= pr.fireball ? 0 : 6 * dt;
      pr.pos.addInPlace(pr.vel.scale(dt));
      pr.mesh.position.copyFrom(pr.pos);
      const id = this.world.getBlock(Math.floor(pr.pos.x), Math.floor(pr.pos.y), Math.floor(pr.pos.z));
      const hitsWorld = id !== 0 && isSolidId(id);
      if (Vector3.Distance(pr.pos, pp.add(new Vector3(0, 1, 0))) < 0.9) {
        this.hooks.damagePlayer(pr.damage, pr.fireball ? "blaze" : "skeleton", pr.pos);
        pr.life = 0;
      }
      if (hitsWorld || pr.life <= 0) {
        pr.life = 0;
        pr.mesh.dispose();
      }
    }
    this.projectiles = this.projectiles.filter((p) => p.life > 0);
  }

  private updateItems(dt: number, pp: Vector3): void {
    for (const it of this.items) {
      it.age += dt;
      it.vel.y -= 20 * dt;
      if (it.onGround) { it.vel.x *= 0.85; it.vel.z *= 0.85; }
      const nx = it.pos.x + it.vel.x * dt;
      const nz = it.pos.z + it.vel.z * dt;
      if (isSolidId(this.world.getBlock(Math.floor(nx), Math.floor(it.pos.y), Math.floor(it.pos.z)))) it.vel.x = -it.vel.x * 0.3;
      else it.pos.x = nx;
      if (isSolidId(this.world.getBlock(Math.floor(it.pos.x), Math.floor(it.pos.y), Math.floor(nz)))) it.vel.z = -it.vel.z * 0.3;
      else it.pos.z = nz;
      const ny = it.pos.y + it.vel.y * dt;
      const under = this.world.getBlock(Math.floor(it.pos.x), Math.floor(ny), Math.floor(it.pos.z));
      if (isSolidId(under)) {
        it.pos.y = Math.floor(ny) + 1;
        it.vel.y = 0;
        it.onGround = true;
      } else {
        it.pos.y = ny;
        it.onGround = false;
      }
      it.root.position.set(it.pos.x, it.pos.y + 0.25 + Math.sin(it.age * 3) * 0.06, it.pos.z);
      it.root.rotation.y = it.age * 1.5;
    }
    // pick up
    for (const it of this.items) {
      if (it.age < 0.6) continue;
      if (Vector3.Distance(it.pos, pp) < 1.4) {
        const taken = this.hooks.spawnDrops === undefined ? false : false;
        void taken;
        it.stack.count = -1;
      }
    }
    const remaining: ItemEntityRec[] = [];
    for (const it of this.items) {
      if (it.stack.count === -1) {
        it.root.dispose();
        continue;
      }
      if (it.age > 300) { it.root.dispose(); continue; }
      remaining.push(it);
    }
    this.items = remaining;
  }

  /** Collects items that the player is close enough to pick up. Returns the picked stacks. */
  collectNearby(pp: Vector3): ItemStack[] {
    return [];
    void pp;
  }

  /** Applies damage to a mob. Returns true if it died. */
  damageMob(m: Mob, amount: number, from: Vector3 | null, knock = 0.6): boolean {
    if (m.dead) return false;
    m.hp -= amount;
    m.hurtFlash = 0.3;
    this.hooks.sound(m.def.sound.hurt, m.pos);
    if (from && !m.def.flying) {
      const d = m.pos.subtract(from);
      d.y = 0;
      const l = d.length() || 1;
      m.vel.x += (d.x / l) * 5 * knock;
      m.vel.z += (d.z / l) * 5 * knock;
      m.vel.y = 4 * knock;
    }
    if (!m.def.hostile && m.def.key !== "villager") m.fleeTimer = 6;
    if (m.def.hostile) m.wanderTarget = null;
    if (m.def.teleports) this.teleportMob(m, 8);
    if (m.hp <= 0) {
      this.kill(m, true);
      return true;
    }
    return false;
  }

  kill(m: Mob, byPlayer: boolean): void {
    if (m.dead) return;
    m.dead = true;
    if (byPlayer) {
      this.hooks.sound(m.def.sound.death, m.pos);
      for (const [key, min, max] of m.def.drops) {
        const n = min + Math.floor(Math.random() * (max - min + 1));
        if (n > 0) this.hooks.spawnDrops(m.pos.add(new Vector3(0, 0.5, 0)), key, n);
      }
      if (m.def.xp) this.hooks.xp(m.def.xp);
    }
    if (byPlayer) {
      // ragdoll-style tumble: keep momentum, topple over, then vanish
      this.dying.push({ m, t: 0, spin: (Math.random() < 0.5 ? -1 : 1) * (2.5 + Math.random() * 2) });
      return;
    }
    m.root.getChildMeshes().forEach((c) => c.dispose());
    m.root.dispose();
  }

  private dying: { m: Mob; t: number; spin: number }[] = [];

  private updateDying(dt: number): void {
    for (const d of this.dying) {
      d.t += dt;
      const m = d.m;
      if (!m.def.flying) m.vel.y -= 28 * dt;
      else m.vel.y -= 10 * dt;
      m.vel.x *= m.onGround ? 0.85 : 0.99;
      m.vel.z *= m.onGround ? 0.85 : 0.99;
      this.moveEntity(m, dt);
      m.root.position.copyFrom(m.pos);
      const fall = Math.min(Math.PI / 2, d.t * d.spin * (m.onGround ? 1.6 : 1));
      m.root.rotation.z = Math.abs(fall) > Math.PI / 2 ? Math.sign(fall) * Math.PI / 2 : fall;
      // limbs go limp
      for (const { node, part } of m.nodes) if (part.a === "legA" || part.a === "legB" || part.a === "armA" || part.a === "armB") node.rotation.x *= 0.9;
      const flash = Math.sin(d.t * 30) > 0 ? 1.08 : 1;
      m.root.scaling.setAll((m.def.scale ?? 1) * (d.t > 0.9 ? Math.max(0.01, 1 - (d.t - 0.9) * 4) : flash));
    }
    const done = this.dying.filter((d) => d.t > 1.15);
    for (const d of done) {
      d.m.root.getChildMeshes().forEach((c) => c.dispose());
      d.m.root.dispose();
    }
    this.dying = this.dying.filter((d) => d.t <= 1.15);
  }

  /** Mobs within radius, used for melee targeting by the player. */
  mobsNear(pos: Vector3, radius: number): Mob[] {
    return this.mobs.filter((m) => !m.dead && Vector3.Distance(m.pos.add(new Vector3(0, m.def.height / 2, 0)), pos) <= radius);
  }

  /** Villager interaction: returns the next line for a nearby villager. */
  talkTo(m: Mob): string {
    const pools = [VILLAGER_LINES.default, VILLAGER_LINES.weather, VILLAGER_LINES.dimension];
    const pool = pools[(this.villagerLineIdx++ + m.id) % pools.length];
    const line = pool[m.dialogueIdx % pool.length];
    m.dialogueIdx++;
    this.hooks.sound("dialogue", m.pos);
    return line;
  }

  /** Explosion impulse + damage for mobs within radius (falloff). */
  blastMobs(center: Vector3, radius: number, damage: number): void {
    for (const m of this.mobs) {
      if (m.dead) continue;
      const d = Vector3.Distance(m.pos.add(new Vector3(0, 0.9, 0)), center);
      if (d > radius) continue;
      const f = 1 - d / radius;
      const dir = m.pos.subtract(center);
      dir.normalize();
      m.vel.addInPlace(dir.scale(14 * f));
      m.vel.y += 6 * f;
      this.damageMob(m, Math.ceil(damage * f), null, 0);
    }
  }

  get aliveHostiles(): number {
    return this.mobs.filter((m) => m.def.hostile && !m.dead).length;
  }

  dispose(): void {
    for (const d of this.dying) d.m.root.dispose();
    this.dying = [];
    for (const m of this.mobs) m.root.dispose();
    for (const it of this.items) it.root.dispose();
    for (const p of this.projectiles) p.mesh.dispose();
    this.mobs = [];
    this.items = [];
    this.projectiles = [];
    templates.clear();
    skinTextures.clear();
    this.iconTex.clear();
  }
}

/** Builds a player figure (third-person model + first-person arm) from character options. */
export function buildPlayerFigure(scene: Scene, opts: CharacterOpts): { root: TransformNode; parts: Record<string, TransformNode>; mats: StandardMaterial[] } {
  const tex = new Texture(paintPlayerSkin(opts).toDataURL("image/png"), scene, false, false, Texture.NEAREST_NEAREST_MIPLINEAR);
  const mat = new StandardMaterial(`mat_player_${Math.random().toString(36).slice(2, 6)}`, scene);
  mat.diffuseTexture = tex;
  mat.specularColor = new Color3(0, 0, 0);
  mat.backFaceCulling = false;
  const root = new TransformNode("playerFigure", scene);
  const parts: Record<string, TransformNode> = {};
  const layout: { n: string; s: [number, number, number]; p: [number, number, number]; uv: [number, number] }[] = [
    { n: "legR", s: [0.25, 0.75, 0.25], p: [-0.125, 0.75, 0], uv: [0, 16] },
    { n: "legL", s: [0.25, 0.75, 0.25], p: [0.125, 0.75, 0], uv: [16, 48] },
    { n: "body", s: [0.5, 0.75, 0.25], p: [0, 1.5, 0], uv: [16, 16] },
    { n: "armR", s: [0.25, 0.75, 0.25], p: [-0.375, 1.5, 0], uv: [40, 16] },
    { n: "armL", s: [0.25, 0.75, 0.25], p: [0.375, 1.5, 0], uv: [32, 48] },
    { n: "head", s: [0.5, 0.5, 0.5], p: [0, 1.5, 0], uv: [0, 0] },
  ];
  for (const l of layout) {
    const piv = new TransformNode(`pl_${l.n}`, scene);
    piv.parent = root;
    piv.position.set(l.p[0], l.p[1] - l.s[1], l.p[2]);
    const vd = boxData(l.s, l.uv);
    const m = new Mesh(`pm_${l.n}`, scene);
    vd.applyToMesh(m);
    m.material = mat;
    m.parent = piv;
    m.isPickable = false;
    parts[l.n] = piv;
  }
  return { root, parts, mats: [mat] };
}

export { BLOCKS, InstancedMesh, VertexData };
