// Procedural audio: every sound is synthesized with Web Audio (original, no sample files).
// Buses: master / music / sfx / ambient. Positional sounds attenuate with distance and pan by bearing.

import type { Settings } from "../core/settings";

type Recipe = (ctx: AudioContext, out: AudioNode, t: number, pitch: number) => void;

function noiseBuffer(ctx: AudioContext, seconds = 1.5): AudioBuffer {
  const len = Math.floor(ctx.sampleRate * seconds);
  const buf = ctx.createBuffer(1, len, ctx.sampleRate);
  const d = buf.getChannelData(0);
  let last = 0;
  for (let i = 0; i < len; i++) {
    last = last * 0.92 + (Math.random() * 2 - 1) * 0.08; // brown-ish noise
    d[i] = last * 6 * (1 - i / len * 0.2);
  }
  return buf;
}

function burst(ctx: AudioContext, out: AudioNode, t: number, dur: number, freq: number, q: number, gain: number, type: BiquadFilterType = "bandpass", noise: AudioBuffer | null = null): void {
  const src = ctx.createBufferSource();
  src.buffer = noise ?? noiseBuffer(ctx, 0.5);
  const f = ctx.createBiquadFilter();
  f.type = type;
  f.frequency.setValueAtTime(freq, t);
  f.Q.value = q;
  const g = ctx.createGain();
  g.gain.setValueAtTime(0.0001, t);
  g.gain.exponentialRampToValueAtTime(gain, t + 0.005);
  g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
  src.connect(f).connect(g).connect(out);
  src.start(t);
  src.stop(t + dur + 0.05);
}

function tone(ctx: AudioContext, out: AudioNode, t: number, dur: number, f0: number, f1: number, gain: number, type: OscillatorType = "square"): void {
  const o = ctx.createOscillator();
  o.type = type;
  o.frequency.setValueAtTime(f0, t);
  o.frequency.exponentialRampToValueAtTime(Math.max(20, f1), t + dur);
  const g = ctx.createGain();
  g.gain.setValueAtTime(0.0001, t);
  g.gain.exponentialRampToValueAtTime(gain, t + 0.01);
  g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
  o.connect(g).connect(out);
  o.start(t);
  o.stop(t + dur + 0.05);
}

export class AudioEngine {
  private ctx: AudioContext | null = null;
  private master!: GainNode;
  private musicBus!: GainNode;
  private sfxBus!: GainNode;
  private ambBus!: GainNode;
  private noise: AudioBuffer | null = null;
  private listener = { x: 0, y: 0, z: 0, yaw: 0 };
  private windGain!: GainNode;
  private rainGain!: GainNode;
  private waterGain!: GainNode;
  private musicTimer = 0;
  private musicOn = false;
  private recipes: Record<string, Recipe>;
  private lastPlayed = new Map<string, number>();
  private settings: Settings | null = null;

  constructor() {
    this.recipes = this.buildRecipes();
  }

  /** Must be called from a user gesture (click) before audio can play. */
  ensure(): void {
    if (this.ctx) {
      if (this.ctx.state === "suspended") void this.ctx.resume();
      return;
    }
    const AC = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    this.ctx = new AC();
    const ctx = this.ctx;
    this.master = ctx.createGain();
    this.master.connect(ctx.destination);
    this.musicBus = ctx.createGain();
    this.sfxBus = ctx.createGain();
    this.ambBus = ctx.createGain();
    this.musicBus.connect(this.master);
    this.sfxBus.connect(this.master);
    this.ambBus.connect(this.master);
    this.noise = noiseBuffer(ctx, 3);
    // ambience loops
    const mkLoop = (type: BiquadFilterType, freq: number, q: number) => {
      const src = ctx.createBufferSource();
      src.buffer = this.noise;
      src.loop = true;
      const f = ctx.createBiquadFilter();
      f.type = type;
      f.frequency.value = freq;
      f.Q.value = q;
      const g = ctx.createGain();
      g.gain.value = 0;
      src.connect(f).connect(g).connect(this.ambBus);
      src.start();
      return g;
    };
    this.windGain = mkLoop("lowpass", 700, 0.5);
    this.rainGain = mkLoop("highpass", 3200, 0.3);
    this.waterGain = mkLoop("bandpass", 500, 0.8);
    this.applyVolumes();
  }

  applySettings(s: Settings): void {
    this.settings = s;
    this.applyVolumes();
  }

  private applyVolumes(): void {
    if (!this.ctx || !this.settings) return;
    const s = this.settings;
    const t = this.ctx.currentTime;
    this.master.gain.setTargetAtTime(s.volumeMaster, t, 0.05);
    this.musicBus.gain.setTargetAtTime(s.volumeMusic, t, 0.05);
    this.sfxBus.gain.setTargetAtTime(s.volumeSfx, t, 0.05);
    this.ambBus.gain.setTargetAtTime(s.volumeAmbient, t, 0.05);
  }

  setListener(x: number, y: number, z: number, yaw: number): void {
    this.listener = { x, y, z, yaw };
  }

  /** Plays a named sound. Optional world position enables distance attenuation and panning. */
  play(name: string, opts: { pos?: { x: number; y: number; z: number }; volume?: number; pitch?: number; cooldown?: number } = {}): void {
    if (!this.ctx) return;
    const recipe = this.recipes[name];
    if (!recipe) return;
    const now = performance.now();
    const cd = opts.cooldown ?? 0;
    const last = this.lastPlayed.get(name) ?? 0;
    if (cd && now - last < cd) return;
    this.lastPlayed.set(name, now);
    const ctx = this.ctx;
    const t = ctx.currentTime + 0.001;
    const bus = this.ctx.createGain();
    let gain = opts.volume ?? 1;
    const panner = ctx.createStereoPanner();
    if (opts.pos) {
      const dx = opts.pos.x - this.listener.x, dy = opts.pos.y - this.listener.y, dz = opts.pos.z - this.listener.z;
      const dist = Math.sqrt(dx * dx + dy * dy + dz * dz);
      gain *= Math.max(0, 1 - dist / 42);
      const bearing = Math.atan2(dx, dz) - this.listener.yaw;
      panner.pan.value = Math.max(-1, Math.min(1, Math.sin(bearing) * 0.9));
      if (gain <= 0.01) return;
    }
    bus.gain.value = gain;
    bus.connect(panner).connect(this.sfxBus);
    recipe(ctx, bus, t, opts.pitch ?? 1);
    setTimeout(() => { try { bus.disconnect(); panner.disconnect(); } catch { /* already gone */ } }, 4000);
  }

  /** Updates ambience by weather, dimension and nearby water. */
  updateAmbience(weather: string, nearWater: number, windy: number, dimension: string, rainy: boolean): void {
    if (!this.ctx) return;
    const t = this.ctx.currentTime;
    const dim = dimension === "nether" ? 0.5 : 1;
    this.windGain.gain.setTargetAtTime((0.05 + windy * 0.18) * dim, t, 0.6);
    this.rainGain.gain.setTargetAtTime(rainy ? (weather === "thunder" ? 0.16 : 0.1) : 0, t, 0.8);
    this.waterGain.gain.setTargetAtTime(nearWater * 0.12, t, 0.5);
  }

  private ambTimers: Record<string, number> = {};

  /** Biome soundscape: schedules synthesized one-shots (birds, crickets, waves, frogs, drips, owls, lava). */
  ambientTick(dt: number, env: { biome: string; day: number; underground: boolean; ocean: number; rain: boolean; dimension: string; underwater: boolean }): void {
    if (!this.ctx) return;
    const due = (key: string, min: number, max: number) => {
      this.ambTimers[key] = (this.ambTimers[key] ?? Math.random() * max) - dt;
      if (this.ambTimers[key] > 0) return false;
      this.ambTimers[key] = min + Math.random() * (max - min);
      return true;
    };
    const v = (x: number) => ({ volume: x, pitch: 0.85 + Math.random() * 0.3 });
    if (env.underwater) { if (due("bubble", 1.5, 4)) this.playAmb("bubbles", v(0.5)); return; }
    if (env.dimension === "nether") { if (due("lava", 2, 6)) this.playAmb("lava_pop", v(0.6)); if (due("rumble", 10, 22)) this.playAmb("cave_rumble", v(0.6)); return; }
    if (env.dimension === "end") { if (due("void", 8, 16)) this.playAmb("void_hum", v(0.4)); return; }
    if (env.underground) {
      if (due("drip", 2, 7)) this.playAmb("drip", v(0.6));
      if (due("rumble", 14, 30)) this.playAmb("cave_rumble", v(0.5));
      return;
    }
    if (env.ocean > 0.2 && due("wave", 3, 6)) this.playAmb("wave", v(0.35 + env.ocean * 0.5));
    if (env.rain) return;
    const b = env.biome;
    const forest = /forest|woods|grove|jungle|taiga|plains|meadow|savanna/.test(b);
    if (env.day > 0.5) {
      if (forest && due("bird", 1.2, 4.5)) this.playAmb(Math.random() < 0.5 ? "bird" : "bird2", v(0.4));
      if (/jungle/.test(b) && due("parrot", 4, 9)) this.playAmb("bird2", { volume: 0.5, pitch: 1.4 });
    } else {
      if ((forest || /swamp/.test(b)) && due("cricket", 0.6, 1.8)) this.playAmb("cricket", v(0.25));
      if (/forest|taiga|woods/.test(b) && due("owl", 12, 25)) this.playAmb("owl", v(0.4));
    }
    if (/swamp|marsh/.test(b) && due("frog", 2, 6)) this.playAmb("frog", v(0.45));
    if (/desert|badlands|peaks|mountains|snowy/.test(b) && due("gust", 6, 12)) this.playAmb("gust", v(0.4));
  }

  private playAmb(name: string, opts: { volume: number; pitch: number }): void {
    if (!this.ctx) return;
    const recipe = this.recipes[name];
    if (!recipe) return;
    const g = this.ctx.createGain();
    g.gain.value = opts.volume;
    const pan = this.ctx.createStereoPanner();
    pan.pan.value = Math.random() * 1.6 - 0.8;
    g.connect(pan).connect(this.ambBus);
    recipe(this.ctx, g, this.ctx.currentTime + 0.01, opts.pitch);
    setTimeout(() => { try { g.disconnect(); pan.disconnect(); } catch { /* gone */ } }, 6000);
  }

  /** Thunder: a sharp crack (close strikes) followed by a long rolling rumble, delayed by distance (~343 m/s). */
  thunder(distance: number): void {
    if (!this.ctx) return;
    const delay = Math.min(4, distance / 343 * 3);
    const near = Math.max(0, 1 - distance / 120);
    setTimeout(() => {
      if (!this.ctx) return;
      const t = this.ctx.currentTime;
      const g = this.ctx.createGain();
      g.gain.value = 0.5 + near * 0.6;
      g.connect(this.ambBus);
      if (near > 0.2) burst(this.ctx, g, t, 0.35, 2200, 0.6, near, "highpass", this.noise);
      // rolling rumble: several low-passed noise swells
      for (let i = 0; i < 5; i++) {
        const src = this.ctx.createBufferSource();
        src.buffer = this.noise;
        const f = this.ctx.createBiquadFilter();
        f.type = "lowpass";
        f.frequency.setValueAtTime(260 - i * 30, t);
        f.frequency.exponentialRampToValueAtTime(60, t + 3.5);
        const gg = this.ctx.createGain();
        const st = t + i * 0.35 + Math.random() * 0.2;
        gg.gain.setValueAtTime(0.0001, st);
        gg.gain.exponentialRampToValueAtTime(0.9 - i * 0.12, st + 0.15);
        gg.gain.exponentialRampToValueAtTime(0.0001, st + 2.5 + Math.random());
        src.connect(f).connect(gg).connect(g);
        src.start(st);
        src.stop(st + 4);
      }
      setTimeout(() => { try { g.disconnect(); } catch { /* gone */ } }, 7000);
    }, delay * 1000);
  }

  /** Simple generative ambient music: slow pad chords + sparse pentatonic notes. */
  tickMusic(dt: number, dayFrac: number, enabled: boolean): void {
    if (!this.ctx) return;
    if (!enabled) {
      this.musicOn = false;
      return;
    }
    this.musicOn = true;
    this.musicTimer -= dt;
    if (this.musicTimer > 0) return;
    this.musicTimer = 9 + Math.random() * 6;
    const ctx = this.ctx;
    const t = ctx.currentTime + 0.05;
    const night = dayFrac > 0.5 && dayFrac < 1.0;
    const roots = night ? [220, 196, 174.6, 261.6] : [261.6, 293.7, 329.6, 392];
    const root = roots[Math.floor(Math.random() * roots.length)];
    const chord = [1, 1.25, 1.5, 2];
    for (const r of chord) {
      const o = ctx.createOscillator();
      o.type = "sine";
      o.frequency.value = root * r;
      const g = ctx.createGain();
      g.gain.setValueAtTime(0.0001, t);
      g.gain.exponentialRampToValueAtTime(0.05, t + 3);
      g.gain.exponentialRampToValueAtTime(0.0001, t + 8);
      o.connect(g).connect(this.musicBus);
      o.start(t);
      o.stop(t + 8.5);
    }
    const penta = [0, 2, 4, 7, 9];
    for (let i = 0; i < 3; i++) {
      const nt = root * 2 * Math.pow(2, penta[Math.floor(Math.random() * penta.length)] / 12);
      tone(ctx, this.musicBus, t + 1.5 + i * 1.4 + Math.random() * 0.3, 1.2, nt, nt * 0.99, 0.02, "triangle");
    }
  }

  private buildRecipes(): Record<string, Recipe> {
    const step = (kind: "grass" | "stone" | "sand" | "wood" | "snow") => (ctx: AudioContext, out: AudioNode, t: number) => {
      const map = { grass: [900, 0.9], stone: [1500, 2.5], sand: [1200, 0.7], wood: [700, 4], snow: [2200, 0.5] } as Record<string, number[]>;
      const [f, q] = map[kind];
      burst(ctx, out, t, 0.09, f, q, 0.35, "bandpass", this.noise);
    };
    const pop = (ctx: AudioContext, out: AudioNode, t: number, p: number) => tone(ctx, out, t, 0.12, 620 * p, 310 * p, 0.2, "triangle");
    return {
      "step_grass": step("grass"),
      "step_stone": step("stone"),
      "step_sand": step("sand"),
      "step_wood": step("wood"),
      "step_snow": step("snow"),
      "jump": (c, o, t) => tone(c, o, t, 0.15, 260, 520, 0.12, "sine"),
      "land": (c, o, t) => { burst(c, o, t, 0.12, 300, 0.8, 0.3, "lowpass", this.noise); },
      "break": (c, o, t, p) => { burst(c, o, t, 0.22, 1200 * p, 1.4, 0.6, "bandpass", this.noise); tone(c, o, t, 0.1, 180 * p, 90, 0.1, "triangle"); },
      "place": (c, o, t, p) => { burst(c, o, t, 0.12, 800 * p, 2, 0.35, "bandpass", this.noise); tone(c, o, t, 0.06, 240 * p, 150, 0.12, "triangle"); },
      "hit": (c, o, t, p) => { burst(c, o, t, 0.08, 1000 * p, 3, 0.25, "bandpass", this.noise); },
      "pop": (c, o, t, p) => pop(c, o, t, p),
      "click": (c, o, t) => tone(c, o, t, 0.04, 1200, 900, 0.08, "square"),
      "open": (c, o, t) => { burst(c, o, t, 0.2, 600, 1, 0.25, "lowpass", this.noise); tone(c, o, t, 0.1, 400, 600, 0.06, "triangle"); },
      "collect": (c, o, t) => { tone(c, o, t, 0.08, 880, 1320, 0.12, "sine"); tone(c, o, t + 0.07, 0.1, 1320, 1760, 0.1, "sine"); },
      "xp": (c, o, t) => { tone(c, o, t, 0.1, 1320, 1900, 0.08, "sine"); },
      "levelup": (c, o, t) => { [523, 659, 784, 1046].forEach((f, i) => tone(c, o, t + i * 0.09, 0.2, f, f, 0.14, "triangle")); },
      "eat": (c, o, t) => { burst(c, o, t, 0.1, 900, 2, 0.3, "bandpass", this.noise); burst(c, o, t + 0.13, 0.1, 800, 2, 0.3, "bandpass", this.noise); },
      "hurt": (c, o, t) => tone(c, o, t, 0.25, 420, 140, 0.25, "sawtooth"),
      "death": (c, o, t) => tone(c, o, t, 0.9, 300, 60, 0.3, "triangle"),
      "explode": (c, o, t, p) => { burst(c, o, t, 1.2, 180 * p, 0.6, 1.0, "lowpass", this.noise); burst(c, o, t + 0.02, 0.6, 900, 0.5, 0.4, "bandpass", this.noise); },
      "fuse": (c, o, t) => { for (let i = 0; i < 6; i++) burst(c, o, t + i * 0.08, 0.03, 3000, 4, 0.15, "highpass", this.noise); },
      "flint": (c, o, t) => { burst(c, o, t, 0.15, 2600, 3, 0.5, "highpass", this.noise); tone(c, o, t, 0.2, 500, 900, 0.1, "triangle"); },
      "portal": (c, o, t) => { tone(c, o, t, 1.6, 180, 720, 0.16, "sine"); tone(c, o, t + 0.2, 1.4, 240, 960, 0.1, "sine"); },
      "portal_done": (c, o, t) => { tone(c, o, t, 0.5, 900, 300, 0.2, "sine"); },
      "thunder": (c, o, t) => { burst(c, o, t, 2.4, 120, 0.5, 1.0, "lowpass", this.noise); },
      "splash": (c, o, t) => { burst(c, o, t, 0.4, 900, 0.8, 0.5, "bandpass", this.noise); },
      "moo": (c, o, t, p) => tone(c, o, t, 0.8, 140 * p, 110 * p, 0.2, "sawtooth"),
      "oink": (c, o, t, p) => tone(c, o, t, 0.25, 320 * p, 250 * p, 0.2, "square"),
      "baa": (c, o, t, p) => tone(c, o, t, 0.6, 360 * p, 300 * p, 0.15, "triangle"),
      "cluck": (c, o, t, p) => { tone(c, o, t, 0.08, 900 * p, 700 * p, 0.12, "square"); tone(c, o, t + 0.1, 0.08, 800 * p, 600 * p, 0.12, "square"); },
      "zombie": (c, o, t, p) => tone(c, o, t, 1.0, 110 * p, 70 * p, 0.2, "sawtooth"),
      "skeleton": (c, o, t) => { burst(c, o, t, 0.15, 2000, 2, 0.25, "bandpass", this.noise); },
      "creeper_fuse": (c, o, t) => { tone(c, o, t, 1.2, 600, 900, 0.1, "square"); },
      "hiss": (c, o, t) => { burst(c, o, t, 0.8, 5000, 1, 0.3, "highpass", this.noise); },
      "shoot": (c, o, t) => { tone(c, o, t, 0.15, 900, 300, 0.12, "triangle"); },
      "enderman": (c, o, t) => tone(c, o, t, 0.9, 200, 500, 0.18, "sine"),
      "chest": (c, o, t) => { burst(c, o, t, 0.12, 500, 1, 0.3, "lowpass", this.noise); },
      "dialogue": (c, o, t, p) => { for (let i = 0; i < 4; i++) tone(c, o, t + i * 0.05, 0.05, (400 + Math.random() * 120) * p, 300 * p, 0.05, "square"); },
      "boss_roar": (c, o, t) => tone(c, o, t, 2.4, 80, 40, 0.4, "sawtooth"),
      "tornado": (c, o, t) => burst(c, o, t, 2.5, 300, 0.5, 0.4, "lowpass", this.noise),
      "bird": (c, o, t, p) => { for (let i = 0; i < 3; i++) tone(c, o, t + i * 0.13, 0.09, 2600 * p, 3600 * p, 0.08, "sine"); },
      "bird2": (c, o, t, p) => { tone(c, o, t, 0.18, 3200 * p, 1800 * p, 0.07, "sine"); tone(c, o, t + 0.22, 0.12, 2200 * p, 3400 * p, 0.07, "sine"); },
      "cricket": (c, o, t, p) => { for (let i = 0; i < 4; i++) tone(c, o, t + i * 0.05, 0.03, 4400 * p, 4300 * p, 0.04, "square"); },
      "owl": (c, o, t, p) => { tone(c, o, t, 0.35, 420 * p, 380 * p, 0.12, "sine"); tone(c, o, t + 0.5, 0.6, 400 * p, 340 * p, 0.12, "sine"); },
      "frog": (c, o, t, p) => { tone(c, o, t, 0.12, 180 * p, 140 * p, 0.15, "sawtooth"); tone(c, o, t + 0.16, 0.12, 190 * p, 150 * p, 0.12, "sawtooth"); },
      "wave": (c, o, t) => {
        const src = c.createBufferSource(); src.buffer = this.noise;
        const f = c.createBiquadFilter(); f.type = "lowpass"; f.frequency.setValueAtTime(300, t); f.frequency.linearRampToValueAtTime(1400, t + 1.4); f.frequency.linearRampToValueAtTime(250, t + 3.6);
        const g = c.createGain(); g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(0.6, t + 1.3); g.gain.exponentialRampToValueAtTime(0.0001, t + 3.8);
        src.connect(f).connect(g).connect(o); src.start(t); src.stop(t + 4);
      },
      "gust": (c, o, t) => burst(c, o, t, 2.2, 500, 0.4, 0.35, "bandpass", this.noise),
      "drip": (c, o, t, p) => tone(c, o, t, 0.12, 1800 * p, 900 * p, 0.12, "sine"),
      "cave_rumble": (c, o, t) => burst(c, o, t, 3.0, 90, 0.5, 0.5, "lowpass", this.noise),
      "bubbles": (c, o, t, p) => { for (let i = 0; i < 5; i++) tone(c, o, t + i * 0.07, 0.06, 500 * p + i * 90, 900 * p + i * 90, 0.06, "sine"); },
      "lava_pop": (c, o, t, p) => { burst(c, o, t, 0.2, 400 * p, 2, 0.4, "lowpass", this.noise); tone(c, o, t, 0.1, 160, 90, 0.1, "sine"); },
      "void_hum": (c, o, t) => tone(c, o, t, 4, 70, 60, 0.1, "sine"),
      "eruption": (c, o, t) => { burst(c, o, t, 4, 70, 0.4, 1.0, "lowpass", this.noise); burst(c, o, t + 0.3, 2.5, 400, 0.4, 0.5, "bandpass", this.noise); },
    };
  }
}

export const audio = new AudioEngine();
