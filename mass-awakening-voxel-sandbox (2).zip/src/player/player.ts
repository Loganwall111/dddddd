// Player controller: AABB collision, gravity, jumping, sprinting, sneaking (edge-safe), swimming, flight,
// fall damage, first-person camera with held items and optional third-person figure. Also block raycasting.

import { FreeCamera, Mesh, MeshBuilder, Scene, StandardMaterial, Texture, TransformNode, Vector3, Vector4, Color3 } from "../rendering/babylon";
import { BLOCKS, isSolidId, isFluidId } from "../blocks/blocks";
import { tileUV } from "../blocks/textures";
import type { World } from "../world/world";
import { buildPlayerFigure, type CharacterOpts } from "../entities/entities";

export const PLAYER_WIDTH = 0.6;
export const PLAYER_HEIGHT = 1.8;
export const PLAYER_CROUCH_HEIGHT = 1.5;
export const EYE_HEIGHT = 1.62;
export const EYE_CROUCH = 1.32;

export interface InputState {
  keys: Set<string>;
  mouseDX: number;
  mouseDY: number;
  leftDown: boolean;
  rightDown: boolean;
  wheel: number;
}

export interface PhysicsEvents {
  landedFall: number; // fall distance in blocks when landing (0 if none)
  jumped: boolean;
  stepped: boolean;
  inWater: boolean;
  headInWater: boolean;
  inLava: boolean;
  fluidKind: string | null;
  moving: boolean;
  sprinting: boolean;
  landedSurfaceKey: string | null;
}

export interface RayHit {
  x: number;
  y: number;
  z: number;
  nx: number;
  ny: number;
  nz: number;
  id: number;
  px: number; // cell before the hit (placement target)
  py: number;
  pz: number;
  dist: number;
}

/** Amanatides-Woo voxel traversal. Fluids are skipped unless includeFluids. */
export function raycastBlocks(world: World, ox: number, oy: number, oz: number, dx: number, dy: number, dz: number, maxDist: number, includeFluids = false): RayHit | null {
  let x = Math.floor(ox), y = Math.floor(oy), z = Math.floor(oz);
  const stepX = dx > 0 ? 1 : -1, stepY = dy > 0 ? 1 : -1, stepZ = dz > 0 ? 1 : -1;
  const tDeltaX = dx !== 0 ? Math.abs(1 / dx) : Infinity;
  const tDeltaY = dy !== 0 ? Math.abs(1 / dy) : Infinity;
  const tDeltaZ = dz !== 0 ? Math.abs(1 / dz) : Infinity;
  let tMaxX = dx > 0 ? (x + 1 - ox) * tDeltaX : dx < 0 ? (ox - x) * tDeltaX : Infinity;
  let tMaxY = dy > 0 ? (y + 1 - oy) * tDeltaY : dy < 0 ? (oy - y) * tDeltaY : Infinity;
  let tMaxZ = dz > 0 ? (z + 1 - oz) * tDeltaZ : dz < 0 ? (oz - z) * tDeltaZ : Infinity;
  let px = x, py = y, pz = z;
  let nx = 0, ny = 0, nz = 0;
  let t = 0;
  for (let i = 0; i < 200 && t <= maxDist; i++) {
    const id = world.getBlock(x, y, z);
    if (id > 0) {
      const def = BLOCKS[id];
      const hittable = def && def.render !== "none" && (includeFluids || !def.fluid);
      if (hittable && (id !== -1)) {
        return { x, y, z, nx, ny, nz, id, px, py, pz, dist: t };
      }
    }
    px = x; py = y; pz = z;
    if (tMaxX < tMaxY) {
      if (tMaxX < tMaxZ) { t = tMaxX; tMaxX += tDeltaX; x += stepX; nx = -stepX; ny = 0; nz = 0; }
      else { t = tMaxZ; tMaxZ += tDeltaZ; z += stepZ; nx = 0; ny = 0; nz = -stepZ; }
    } else {
      if (tMaxY < tMaxZ) { t = tMaxY; tMaxY += tDeltaY; y += stepY; nx = 0; ny = -stepY; nz = 0; }
      else { t = tMaxZ; tMaxZ += tDeltaZ; z += stepZ; nx = 0; ny = 0; nz = -stepZ; }
    }
    if (y < 0 || y > 255) break;
  }
  return null;
}

export class Player {
  pos = new Vector3(0, 80, 0); // feet position
  vel = new Vector3();
  yaw = 0;
  pitch = 0;
  onGround = false;
  flying = false;
  creative = false;
  crouching = false;
  sprinting = false;
  thirdPerson = false;
  fallStart = 0;
  wasFalling = false;
  bobT = 0;
  stepDist = 0;
  flyTapTimer = 0;
  lastSpaceDown = false;
  camera: FreeCamera;
  private scene: Scene;
  cameraRoot: TransformNode;
  figure: { root: TransformNode; parts: Record<string, TransformNode> };
  fpArm: { root: TransformNode; parts: Record<string, TransformNode> };
  held: Mesh | null = null;
  heldMat: StandardMaterial | null = null;
  swingT = 0;
  hurtT = 0;
  fov = 70;
  sensitivity = 1;
  invertY = false;
  bobbing = true;
  moveSpeedScale = 1;

  constructor(scene: Scene, character: CharacterOpts) {
    this.scene = scene;
    this.camera = new FreeCamera("playerCam", new Vector3(0, 80, 0), scene);
    this.camera.inputs.clear();
    this.camera.minZ = 0.08;
    this.camera.maxZ = 2400;
    this.camera.fov = this.fov * Math.PI / 180;
    scene.activeCamera = this.camera;
    this.cameraRoot = new TransformNode("camRoot", scene);
    this.figure = buildPlayerFigure(scene, character);
    this.figure.root.setEnabled(false);
    this.fpArm = buildPlayerFigure(scene, character);
    this.fpArm.root.parent = this.camera;
    this.fpArm.root.position.set(0.42, -0.55, 0.25);
    this.fpArm.root.rotation.set(0, 0, 0);
    this.fpArm.root.scaling.set(0.85, 1, 0.85);
    for (const k of Object.keys(this.fpArm.parts)) if (k !== "armR") this.fpArm.parts[k].setEnabled(false);
    this.fpArm.parts.armR.position.set(0, 0, 0);
    this.fpArm.parts.armR.rotation.set(1.25, -0.15, 0.12);
    // own render group (depth cleared) so the arm never clips into blocks; flatter, Minecraft-like lighting
    scene.setRenderingAutoClearDepthStencil(1, true, true, true);
    for (const m of this.fpArm.root.getChildMeshes()) {
      m.renderingGroupId = 1;
      const mat = m.material as StandardMaterial | null;
      if (mat) mat.emissiveColor = new Color3(0.38, 0.38, 0.38);
    }
    const hand = this.fpArm.parts.armR;
    void hand;
  }

  get eyeY(): number {
    return this.pos.y + (this.crouching ? EYE_CROUCH : EYE_HEIGHT);
  }

  get height(): number {
    return this.crouching ? PLAYER_CROUCH_HEIGHT : PLAYER_HEIGHT;
  }

  /** Forward/right unit vectors on the horizontal plane. */
  forward(): Vector3 {
    return new Vector3(Math.sin(this.yaw), 0, Math.cos(this.yaw));
  }

  lookDir(): Vector3 {
    const cp = Math.cos(this.pitch);
    return new Vector3(Math.sin(this.yaw) * cp, -Math.sin(this.pitch), Math.cos(this.yaw) * cp);
  }

  private solidAt(world: World, x: number, y: number, z: number): boolean {
    const id = world.getBlock(x, y, z);
    if (id === -1) return true; // unloaded chunks act as solid so the player never falls through
    return isSolidId(id);
  }

  private boxHits(world: World, minX: number, minY: number, minZ: number, maxX: number, maxY: number, maxZ: number): boolean {
    const x0 = Math.floor(minX), x1 = Math.floor(maxX - 1e-4);
    const y0 = Math.floor(minY), y1 = Math.floor(maxY - 1e-4);
    const z0 = Math.floor(minZ), z1 = Math.floor(maxZ - 1e-4);
    for (let x = x0; x <= x1; x++) for (let y = y0; y <= y1; y++) for (let z = z0; z <= z1; z++) {
      if (this.solidAt(world, x, y, z)) return true;
    }
    return false;
  }

  /** Physics step. input is consumed by the caller; wish is the desired movement direction (x,z). */
  step(dt: number, world: World, input: InputState, settings: { survival: boolean }): PhysicsEvents {
    const ev: PhysicsEvents = { landedFall: 0, jumped: false, stepped: false, inWater: false, headInWater: false, inLava: false, fluidKind: null, moving: false, sprinting: false, landedSurfaceKey: null };
    const keys = input.keys;
    const fwd = (keys.has("KeyW") ? 1 : 0) - (keys.has("KeyS") ? 1 : 0);
    const strafe = (keys.has("KeyD") ? 1 : 0) - (keys.has("KeyA") ? 1 : 0);
    const wantCrouch = keys.has("ControlLeft") || keys.has("ControlRight") || (keys.has("ShiftLeft") && this.flying && !this.creative);

    // double-tap space toggles flight in creative
    const spaceDown = keys.has("Space");
    if (spaceDown && !this.lastSpaceDown && this.creative) {
      if (this.flyTapTimer > 0) this.flying = !this.flying;
      this.flyTapTimer = 0.3;
      if (this.flying) this.vel.y = 0;
    }
    this.lastSpaceDown = spaceDown;
    this.flyTapTimer = Math.max(0, this.flyTapTimer - dt);

    // movement input
    const f = this.forward();
    const r = new Vector3(f.z, 0, -f.x);
    const wish = f.scale(fwd).add(r.scale(strafe));
    const wishLen = wish.length();
    if (wishLen > 1) wish.scaleInPlace(1 / wishLen);
    ev.moving = wishLen > 0.01;

    const headBody = this.feetInFluid(world);
    ev.inWater = headBody.body;
    ev.headInWater = headBody.head;
    ev.inLava = headBody.lava;
    ev.fluidKind = headBody.kind;

    const sprintKey = keys.has("ShiftLeft") || keys.has("ShiftRight");
    this.sprinting = sprintKey && fwd > 0 && !wantCrouch && !this.crouching;
    this.crouching = wantCrouch && !this.flying ? true : (this.crouching && wantCrouch) ? true : false;
    if (!wantCrouch && this.crouching) {
      // try to stand up
      if (!this.boxHits(world, this.pos.x - PLAYER_WIDTH / 2, this.pos.y, this.pos.z - PLAYER_WIDTH / 2, this.pos.x + PLAYER_WIDTH / 2, this.pos.y + PLAYER_HEIGHT, this.pos.z + PLAYER_WIDTH / 2)) this.crouching = false;
      else this.crouching = false;
    }
    if (this.flying) this.crouching = wantCrouch;

    let speed = this.sprinting ? 5.6 : this.crouching ? 1.4 : 4.3;
    if (this.flying) speed = (this.sprinting ? 22 : 10) * this.moveSpeedScale;
    if (ev.inWater && !this.flying) speed *= 0.55;
    speed *= this.moveSpeedScale;

    const accel = this.onGround ? 14 : (this.flying ? 9 : 3.5);
    const targetX = wish.x * speed, targetZ = wish.z * speed;
    this.vel.x += (targetX - this.vel.x) * Math.min(1, accel * dt);
    this.vel.z += (targetZ - this.vel.z) * Math.min(1, accel * dt);

    if (this.flying) {
      const up = (keys.has("Space") ? 1 : 0) - (keys.has("ShiftLeft") ? 1 : 0);
      this.vel.y += (up * 10 - this.vel.y) * Math.min(1, 8 * dt);
    } else if (ev.inWater) {
      this.vel.y += (-2.2 - this.vel.y) * Math.min(1, 3 * dt);
      if (keys.has("Space")) this.vel.y = Math.min(this.vel.y + 22 * dt, 3.2);
    } else {
      this.vel.y -= 32 * dt;
      if (this.vel.y < -55) this.vel.y = -55;
      if (keys.has("Space") && this.onGround && !this.crouching) {
        this.vel.y = 9.3;
        this.onGround = false;
        ev.jumped = true;
      }
    }

    // track fall distance
    if (!this.flying && !this.onGround && this.vel.y < 0 && !this.wasFalling) {
      this.fallStart = this.pos.y;
      this.wasFalling = true;
    }

    // integrate with axis-separated collision
    const hw = PLAYER_WIDTH / 2;
    const h = this.height;
    const beforeY = this.pos.y;
    const sub = Math.max(1, Math.ceil(Math.max(Math.abs(this.vel.x), Math.abs(this.vel.z), Math.abs(this.vel.y)) * dt / 0.25));
    const sdt = dt / sub;
    for (let i = 0; i < sub; i++) {
      // X
      let nx = this.pos.x + this.vel.x * sdt;
      if (this.boxHits(world, nx - hw, this.pos.y, this.pos.z - hw, nx + hw, this.pos.y + h, this.pos.z + hw)) {
        if (this.onGround && this.crouching) { /* keep */ }
        nx = this.pos.x;
        this.vel.x = 0;
      }
      // crouch edge guard
      if (this.crouching && this.onGround && !this.flying) {
        if (!this.boxHits(world, nx - hw, this.pos.y - 0.6, this.pos.z - hw, nx + hw, this.pos.y - 0.05, this.pos.z + hw)) nx = this.pos.x;
      }
      this.pos.x = nx;
      // Z
      let nz = this.pos.z + this.vel.z * sdt;
      if (this.boxHits(world, this.pos.x - hw, this.pos.y, nz - hw, this.pos.x + hw, this.pos.y + h, nz + hw)) {
        nz = this.pos.z;
        this.vel.z = 0;
      }
      if (this.crouching && this.onGround && !this.flying) {
        if (!this.boxHits(world, this.pos.x - hw, this.pos.y - 0.6, nz - hw, this.pos.x + hw, this.pos.y - 0.05, nz + hw)) nz = this.pos.z;
      }
      this.pos.z = nz;
      // Y
      let ny = this.pos.y + this.vel.y * sdt;
      if (this.boxHits(world, this.pos.x - hw, ny, this.pos.z - hw, this.pos.x + hw, ny + h, this.pos.z + hw)) {
        if (this.vel.y < 0) {
          // landing: snap to the top of the solid block below
          ny = Math.floor(ny) + 1;
          this.onGround = true;
          const below = world.getBlock(Math.floor(this.pos.x), Math.floor(ny) - 1, Math.floor(this.pos.z));
          ev.landedSurfaceKey = BLOCKS[below]?.key ?? null;
        } else {
          ny = this.pos.y;
        }
        this.vel.y = 0;
      } else {
        this.onGround = false;
      }
      this.pos.y = ny;
    }
    // ground probe (slightly below feet) for steady grounded state
    if (!this.onGround && this.vel.y <= 0 && this.boxHits(world, this.pos.x - hw, this.pos.y - 0.05, this.pos.z - hw, this.pos.x + hw, this.pos.y, this.pos.z + hw)) {
      this.onGround = true;
    }
    if (this.onGround && this.wasFalling) {
      const fall = this.fallStart - this.pos.y;
      this.wasFalling = false;
      if (!this.flying && !ev.inWater && fall > 3) ev.landedFall = fall;
      if (!this.flying && !ev.inWater && fall > 0.3) ev.stepped = false;
    }
    if (this.onGround) this.vel.y = Math.min(this.vel.y, 0);
    void beforeY;

    // footsteps
    const horiz = Math.hypot(this.vel.x, this.vel.z);
    if (this.onGround && horiz > 0.5) {
      this.stepDist += horiz * dt;
      const stride = this.sprinting ? 2.2 : this.crouching ? 1.2 : 1.9;
      if (this.stepDist > stride) {
        this.stepDist = 0;
        ev.stepped = true;
      }
    }
    this.bobT += horiz * dt * (this.onGround ? 1 : 0);
    ev.sprinting = this.sprinting;
    void settings;
    return ev;
  }

  feetInFluid(world: World): { body: boolean; head: boolean; lava: boolean; kind: string | null } {
    const x = Math.floor(this.pos.x), z = Math.floor(this.pos.z);
    const yb = Math.floor(this.pos.y + 0.2), yh = Math.floor(this.pos.y + this.height - 0.1);
    const bodyId = world.getBlock(x, yb, z);
    const headId = world.getBlock(x, yh, z);
    const kind = isFluidId(bodyId) || isFluidId(headId) ? BLOCKS[isFluidId(headId) ? headId : bodyId].key : null;
    return {
      body: isFluidId(bodyId),
      head: isFluidId(headId),
      lava: bodyId === BLOCKS.find((b) => b.key === "lava")?.id || headId === BLOCKS.find((b) => b.key === "lava")?.id,
      kind,
    };
  }

  /** Whether the eye is under water (for underwater rendering). */
  headUnderwater(world: World): string | null {
    const id = world.getBlock(Math.floor(this.camera.position.x), Math.floor(this.camera.position.y), Math.floor(this.camera.position.z));
    if (id > 0 && isFluidId(id)) return BLOCKS[id].key;
    return null;
  }

  /** Applies mouse look and sets the camera transform. */
  applyLook(input: InputState, sensitivity: number, invertY: boolean): void {
    const k = 0.0022 * sensitivity;
    this.yaw += input.mouseDX * k;
    this.pitch += (invertY ? -1 : 1) * input.mouseDY * k;
    this.pitch = Math.max(-1.5, Math.min(1.5, this.pitch));
    input.mouseDX = 0;
    input.mouseDY = 0;
  }

  /** Updates camera, figures and held item. */
  updateCamera(dt: number, fov: number, bobbing: boolean, shakeAmount: number): void {
    const eye = new Vector3(this.pos.x, this.pos.y + (this.crouching ? EYE_CROUCH : EYE_HEIGHT), this.pos.z);
    const look = this.lookDir();
    let bobY = 0, bobX = 0;
    if (bobbing && this.onGround && !this.thirdPerson) {
      bobY = Math.abs(Math.sin(this.bobT * 1.8)) * 0.045;
      bobX = Math.cos(this.bobT * 1.8) * 0.03;
    }
    const shake = (Math.random() - 0.5) * shakeAmount;
    this.camera.position.set(eye.x + bobX + shake, eye.y - bobY + shake * 0.5, eye.z);
    if (this.thirdPerson) {
      const back = 4.2;
      const target = eye.add(look.scale(back));
      this.camera.position.copyFrom(target.scale(1).add(new Vector3(0, 0, 0)));
      this.camera.position.set(eye.x - look.x * back, eye.y - look.y * back + 0.2, eye.z - look.z * back);
      this.camera.setTarget(eye);
    } else {
      this.camera.rotation.set(this.pitch, this.yaw, 0);
    }
    this.camera.fov = fov * Math.PI / 180;

    // third-person figure
    this.figure.root.setEnabled(this.thirdPerson);
    if (this.thirdPerson) {
      this.figure.root.position.set(this.pos.x, this.pos.y, this.pos.z);
      this.figure.root.rotation.y = this.yaw + Math.PI;
      const sw = Math.sin(this.bobT * 1.8) * (this.onGround ? 0.8 : 0.1);
      this.figure.parts.legR.rotation.x = sw;
      this.figure.parts.legL.rotation.x = -sw;
      this.figure.parts.armR.rotation.x = -sw * 0.8 - (this.swingT > 0 ? 1.4 : 0);
      this.figure.parts.armL.rotation.x = sw * 0.8;
      this.figure.parts.head.rotation.x = this.pitch * 0.8;
    }
    this.fpArm.root.setEnabled(!this.thirdPerson);
    this.swingT = Math.max(0, this.swingT - dt * 4);
    const sw2 = this.swingT > 0 ? Math.sin((1 - this.swingT) * Math.PI) : 0;
    const bob2 = Math.sin(this.bobT * 1.8) * 0.02;
    this.fpArm.root.position.set(0.42 + bobX * 0.5, -0.55 + bob2 - sw2 * 0.08, 0.25 + sw2 * 0.14);
    this.fpArm.parts.armR.rotation.x = 1.25 - sw2 * 0.9 + (this.sprinting ? 0.12 : 0);
    this.fpArm.parts.armR.rotation.z = 0.12 + sw2 * 0.3;
    this.hurtT = Math.max(0, this.hurtT - dt);
  }

  /** Swaps the held item visual (block cube or flat icon). */
  setHeld(kind: "block" | "item" | "none", key: string, makeBlockMat: (u: [number, number, number, number]) => StandardMaterial, iconTexture: () => Texture | null): void {
    if (this.held) {
      this.held.dispose();
      this.held = null;
    }
    if (kind === "none") return;
    if (kind === "block") {
      const def = BLOCKS.find((b) => b.key === key);
      if (!def) return;
      const uv = tileUV(def.side);
      const faceUV = new Array(6).fill(0).map(() => new Vector4(uv[0], uv[1], uv[2], uv[3]));
      const m = MeshBuilder.CreateBox(`held_${key}`, { size: 0.32, faceUV }, this.scene);
      m.material = makeBlockMat(uv);
      m.parent = this.fpArm.parts.armR;
      m.position.set(0, 0.82, -0.12);
      m.rotation.set(0.3, 0.6, 0.2);
      m.isPickable = false;
      m.renderingGroupId = 1;
      this.held = m;
      return;
    }
    const tex = iconTexture();
    const plane = MeshBuilder.CreatePlane(`held_${key}`, { size: 0.5 }, this.scene);
    const mat = new StandardMaterial(`heldMat_${key}`, this.scene);
    mat.diffuseTexture = tex;
    mat.useAlphaFromDiffuseTexture = true;
    mat.emissiveColor = new Color3(0.4, 0.4, 0.4);
    mat.backFaceCulling = false;
    plane.material = mat;
    plane.parent = this.fpArm.parts.armR;
    plane.position.set(0, 0.85, -0.15);
    plane.rotation.set(-1.0, 0.2, 0);
    plane.isPickable = false;
    plane.renderingGroupId = 1;
    this.held = plane;
  }

  dispose(): void {
    this.held?.dispose();
    this.figure.root.dispose();
    this.fpArm.root.dispose();
    this.camera.dispose();
  }
}

export function forwardVector(yaw: number, pitch: number): Vector3 {
  const cp = Math.cos(pitch);
  return new Vector3(Math.sin(yaw) * cp, -Math.sin(pitch), Math.cos(yaw) * cp);
}
