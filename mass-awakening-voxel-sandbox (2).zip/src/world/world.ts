// World: chunk streaming, worker-based generation, budgeted meshing, block edits and persistence hooks.
// One World instance exists per dimension. The Game swaps instances when the player changes dimension.

import { Mesh, Scene, TransformNode, VertexData, AbstractMesh } from "../rendering/babylon";
import type { Material } from "../rendering/babylon";
import { EMITTER_STRIDE, LIGHT_RADIUS } from "./mesher";
import GenWorker from "./generator.worker.ts?worker&inline";
import { CHUNK_SIZE, WORLD_HEIGHT, type DimId, type GenParams, type SpawnRec } from "./generator";
import { fillPadded, meshChunk, PAD_VOLUME, type Buckets, type TintTables } from "./mesher";
import { BIOME_BY_ID } from "./biomes";
import { climateAt } from "./generator";
import { BID, BLOCKS } from "../blocks/blocks";

export interface ChunkStore {
  load(dim: DimId, cx: number, cz: number): Promise<Uint16Array | null>;
  save(dim: DimId, cx: number, cz: number, blocks: Uint16Array): Promise<void>;
  keys(dim: DimId): Promise<Set<string>>;
}

export interface SeasonTint {
  grass: [number, number, number];
  foliage: [number, number, number];
}

export type MaterialMap = Record<string, Material>;

export function ckey(cx: number, cz: number): number {
  return ((cx + 0x8000) << 16) | ((cz + 0x8000) & 0xffff);
}

class Chunk {
  blocks: Uint16Array | null = null;
  meshes: Mesh[] = [];
  root: TransformNode;
  modified = false;
  dirty = true;
  spawned = false;
  spawns: SpawnRec[] = [];
  biomeTint: Float32Array; // per-column base tint (r,g,b) x 256
  emitters: Float32Array = new Float32Array(0); // light sources in this chunk (world coords), stride 7
  constructor(public cx: number, public cz: number, scene: Scene) {
    this.root = new TransformNode(`chunk_${cx}_${cz}`, scene);
    this.root.position.set(cx * CHUNK_SIZE, 0, cz * CHUNK_SIZE);
    this.biomeTint = new Float32Array(256 * 3).fill(1);
  }
}

export interface WorldOptions {
  scene: Scene;
  dim: DimId;
  params: GenParams;
  store: ChunkStore;
  materials: MaterialMap;
  workerCount: number;
  onChunkSpawns?: (spawns: SpawnRec[], cx: number, cz: number) => void;
  onChunkReady?: (cx: number, cz: number) => void;
}

const DEFAULT_TINT: SeasonTint = { grass: [1, 1, 1], foliage: [1, 1, 1] };
export const SEASON_TINTS: SeasonTint[] = [
  { grass: [0.9, 1.05, 0.62], foliage: [0.98, 1.08, 0.66] }, // spring
  { grass: [1, 1, 1], foliage: [0.86, 1.02, 0.72] }, // summer
  { grass: [1.12, 0.9, 0.62], foliage: [1.2, 0.72, 0.38] }, // autumn
  { grass: [0.86, 0.94, 0.98], foliage: [0.66, 0.8, 0.78] }, // winter
];

const BIOME_TINT: Record<string, [number, number, number]> = {
  swamp: [0.7, 0.82, 0.5],
  jungle: [0.75, 1.0, 0.55],
  taiga: [0.78, 0.9, 0.85],
  savanna: [1.12, 1.06, 0.6],
  dark_forest: [0.68, 0.8, 0.58],
  toxic_marsh: [0.55, 0.92, 0.38],
  sky_isles: [0.9, 1.05, 0.9],
};

export class World {
  readonly dim: DimId;
  readonly params: GenParams;
  readonly chunks = new Map<number, Chunk>();
  radius = 6;
  season = 1;
  seasonTint: SeasonTint = DEFAULT_TINT;
  private scene: Scene;
  private store: ChunkStore;
  private materials: MaterialMap;
  private workers: Worker[] = [];
  private nextReq = 1;
  private pending = new Map<number, { chunk: Chunk; worker: number }>();
  private loadingStore = new Set<number>();
  private savedKeys = new Set<string>();
  private padded = new Uint16Array(PAD_VOLUME);
  private opts: WorldOptions;
  private inflight = 0;
  private maxInflight: number;
  private saveQueue: Promise<void> = Promise.resolve();
  private disposed = false;
  private dirtyCount = 0;

  constructor(opts: WorldOptions) {
    this.opts = opts;
    this.dim = opts.dim;
    this.params = opts.params;
    this.scene = opts.scene;
    this.store = opts.store;
    this.materials = opts.materials;
    const n = Math.max(1, opts.workerCount);
    for (let i = 0; i < n; i++) {
      const w = new GenWorker();
      const idx = i;
      w.onmessage = (e: MessageEvent) => this.onWorkerMessage(idx, e.data);
      this.workers.push(w);
    }
    this.maxInflight = n * 3;
    this.store.keys(this.dim).then((keys) => (this.savedKeys = keys)).catch(() => undefined);
  }

  /** Sets season for tinting; remeshes everything gradually. */
  setSeason(season: number): void {
    if (season === this.season) return;
    this.season = season;
    this.seasonTint = SEASON_TINTS[season] ?? DEFAULT_TINT;
    for (const c of this.chunks.values()) if (c.blocks) c.dirty = true;
  }

  /** Streams chunks around (px,pz) and meshes dirty chunks within a time budget (ms). */
  update(px: number, pz: number, budgetMs: number, radius: number): void {
    if (this.disposed) return;
    this.radius = radius;
    const pcx = Math.floor(px / CHUNK_SIZE), pcz = Math.floor(pz / CHUNK_SIZE);
    // request missing chunks, nearest first
    const offsets = ringOffsets(radius);
    for (const [dx, dz] of offsets) {
      if (this.inflight >= this.maxInflight && this.loadingStore.size > 16) break;
      const cx = pcx + dx, cz = pcz + dz;
      const k = ckey(cx, cz);
      if (this.chunks.has(k)) continue;
      this.requestChunk(cx, cz);
    }
    // unload far chunks
    const unloadR = radius + 2;
    for (const [k, c] of this.chunks) {
      const dx = c.cx - pcx, dz = c.cz - pcz;
      if (Math.abs(dx) > unloadR || Math.abs(dz) > unloadR) this.unloadChunk(k, c);
    }
    // mesh dirty chunks (nearest first, time-budgeted)
    const t0 = performance.now();
    let built = 0;
    while (true) {
      let best: Chunk | null = null;
      let bestD = Infinity;
      for (const c of this.chunks.values()) {
        if (!c.dirty || !c.blocks) continue;
        const d = (c.cx - pcx) * (c.cx - pcx) + (c.cz - pcz) * (c.cz - pcz);
        if (d < bestD) { bestD = d; best = c; }
      }
      if (!best) break;
      this.buildMesh(best);
      built++;
      if (performance.now() - t0 > budgetMs) break;
    }
    void built;
    this.dirtyCount = 0;
  }

  private requestChunk(cx: number, cz: number): void {
    const k = ckey(cx, cz);
    const chunk = new Chunk(cx, cz, this.scene);
    this.chunks.set(k, chunk);
    const sk = `${cx},${cz}`;
    if (this.savedKeys.has(sk) && !this.loadingStore.has(k)) {
      this.loadingStore.add(k);
      this.store.load(this.dim, cx, cz).then((data) => {
        this.loadingStore.delete(k);
        if (this.chunks.get(k) !== chunk) return;
        if (data) this.setChunkData(chunk, data, false);
        else this.generate(chunk);
      }).catch(() => {
        this.loadingStore.delete(k);
        if (this.chunks.get(k) === chunk) this.generate(chunk);
      });
      return;
    }
    this.generate(chunk);
  }

  private generate(chunk: Chunk): void {
    if (this.workers.length === 0) return;
    const id = this.nextReq++;
    const widx = this.inflight % this.workers.length;
    this.inflight++;
    this.pending.set(id, { chunk, worker: widx });
    this.workers[widx].postMessage({ id, params: this.params, cx: chunk.cx, cz: chunk.cz });
  }

  private onWorkerMessage(_widx: number, msg: { id: number; blocks?: Uint16Array; spawns?: SpawnRec[]; error?: string }): void {
    const p = this.pending.get(msg.id);
    if (!p) return;
    this.pending.delete(msg.id);
    this.inflight = Math.max(0, this.inflight - 1);
    if (this.chunks.get(ckey(p.chunk.cx, p.chunk.cz)) !== p.chunk || this.disposed) return;
    if (msg.error || !msg.blocks) {
      console.error("Chunk generation failed", msg.error);
      this.chunks.delete(ckey(p.chunk.cx, p.chunk.cz));
      return;
    }
    p.chunk.spawns = msg.spawns ?? [];
    this.setChunkData(p.chunk, msg.blocks, true);
  }

  private setChunkData(chunk: Chunk, blocks: Uint16Array, fresh: boolean): void {
    chunk.blocks = blocks;
    chunk.modified = !fresh;
    chunk.dirty = true;
    this.computeBiomeTint(chunk);
    this.scanEmitters(chunk);
    // neighbours get re-meshed so seams close up (diagonals too when this chunk emits light)
    const near = chunk.emitters.length > 0
      ? [[1, 0], [-1, 0], [0, 1], [0, -1], [1, 1], [1, -1], [-1, 1], [-1, -1]]
      : [[1, 0], [-1, 0], [0, 1], [0, -1]];
    for (const [dx, dz] of near) {
      const n = this.chunks.get(ckey(chunk.cx + dx, chunk.cz + dz));
      if (n && n.blocks) n.dirty = true;
    }
    if (!chunk.spawned && fresh && chunk.spawns.length) {
      chunk.spawned = true;
      this.opts.onChunkSpawns?.(chunk.spawns, chunk.cx, chunk.cz);
    }
    chunk.spawned = true;
    this.opts.onChunkReady?.(chunk.cx, chunk.cz);
  }

  private computeBiomeTint(chunk: Chunk): void {
    if (this.dim !== "overworld") return;
    for (let lz = 0; lz < 16; lz++) for (let lx = 0; lx < 16; lx++) {
      const wx = chunk.cx * 16 + lx, wz = chunk.cz * 16 + lz;
      const c = climateAt(this.params, wx, wz);
      const t = BIOME_TINT[c.biome] ?? [1, 1, 1];
      const o = (lz * 16 + lx) * 3;
      chunk.biomeTint[o] = t[0];
      chunk.biomeTint[o + 1] = t[1];
      chunk.biomeTint[o + 2] = t[2];
    }
  }

  private buildMesh(chunk: Chunk): void {
    chunk.dirty = false;
    if (!chunk.blocks || this.disposed) return;
    const center = chunk.blocks;
    fillPadded(this.padded, center, (dx, dz) => {
      const n = this.chunks.get(ckey(chunk.cx + dx, chunk.cz + dz));
      return n && n.blocks ? n.blocks : null;
    });
    const tints = this.buildTints(chunk);
    const buckets = meshChunk(this.padded, tints, this.gatherEmitters(chunk));
    this.applyBuckets(chunk, buckets);
  }

  /** Finds light-emitting blocks in a chunk. Lava is subsampled (surface only, 1 in 3) to bound cost. */
  private scanEmitters(chunk: Chunk): void {
    const b = chunk.blocks;
    if (!b) return;
    const out: number[] = [];
    const lavaId = BID.lava;
    for (let i = 0; i < b.length; i++) {
      const id = b[i];
      if (id === 0) continue;
      const def = BLOCKS[id];
      if (!def || def.light <= 0 || !def.lightColor) continue;
      const x = i & 15, z = (i >> 4) & 15, y = i >> 8;
      if (id === lavaId) {
        if (y < 255 && b[i + 256] === lavaId) continue;
        if ((x + z * 2) % 3 !== 0) continue;
      }
      out.push(chunk.cx * 16 + x + 0.5, y + 0.5, chunk.cz * 16 + z + 0.5, def.lightColor[0], def.lightColor[1], def.lightColor[2], def.light / 15);
      if (out.length > 7 * 600) break;
    }
    chunk.emitters = Float32Array.from(out);
  }

  /** Emitters from the 3x3 neighbourhood that can reach this chunk, in chunk-local coords, nearest first, capped. */
  private gatherEmitters(chunk: Chunk): Float32Array {
    const list: { d: number; o: number; src: Float32Array }[] = [];
    const x0 = chunk.cx * 16, z0 = chunk.cz * 16;
    for (let dx = -1; dx <= 1; dx++) for (let dz = -1; dz <= 1; dz++) {
      const c = this.chunks.get(ckey(chunk.cx + dx, chunk.cz + dz));
      if (!c || c.emitters.length === 0) continue;
      const e = c.emitters;
      for (let i = 0; i < e.length; i += EMITTER_STRIDE) {
        const ex = e[i] - x0, ez = e[i + 2] - z0;
        const ox = ex < 0 ? -ex : ex > 16 ? ex - 16 : 0;
        const oz = ez < 0 ? -ez : ez > 16 ? ez - 16 : 0;
        if (ox > LIGHT_RADIUS || oz > LIGHT_RADIUS) continue;
        list.push({ d: ox * ox + oz * oz, o: i, src: e });
      }
    }
    if (list.length === 0) return new Float32Array(0);
    list.sort((a, b) => a.d - b.d);
    const n = Math.min(list.length, 48);
    const out = new Float32Array(n * EMITTER_STRIDE);
    for (let k = 0; k < n; k++) {
      const { o, src } = list[k];
      out[k * 7] = src[o] - x0; out[k * 7 + 1] = src[o + 1]; out[k * 7 + 2] = src[o + 2] - z0;
      out[k * 7 + 3] = src[o + 3]; out[k * 7 + 4] = src[o + 4]; out[k * 7 + 5] = src[o + 5]; out[k * 7 + 6] = src[o + 6];
    }
    return out;
  }

  private buildTints(chunk: Chunk): TintTables {
    const grass = new Float32Array(256 * 3);
    const foliage = new Float32Array(256 * 3);
    const s = this.seasonTint;
    for (let i = 0; i < 256; i++) {
      const b = chunk.biomeTint;
      grass[i * 3] = b[i * 3] * s.grass[0];
      grass[i * 3 + 1] = b[i * 3 + 1] * s.grass[1];
      grass[i * 3 + 2] = b[i * 3 + 2] * s.grass[2];
      foliage[i * 3] = b[i * 3] * s.foliage[0];
      foliage[i * 3 + 1] = b[i * 3 + 1] * s.foliage[1];
      foliage[i * 3 + 2] = b[i * 3 + 2] * s.foliage[2];
    }
    return { grass, foliage };
  }

  private applyBuckets(chunk: Chunk, buckets: Buckets): void {
    for (const m of chunk.meshes) m.dispose();
    chunk.meshes = [];
    for (const name of Object.keys(buckets)) {
      const data = buckets[name];
      if (data.positions.length === 0) continue;
      const vd = new VertexData();
      vd.positions = data.positions;
      vd.normals = data.normals;
      vd.uvs = data.uvs;
      vd.colors = data.colors;
      vd.indices = data.indices;
      const mesh = new Mesh(`c_${chunk.cx}_${chunk.cz}_${name}`, this.scene);
      vd.applyToMesh(mesh, false);
      mesh.parent = chunk.root;
      mesh.material = this.materials[name] ?? this.materials.solid;
      mesh.isPickable = false;
      mesh.receiveShadows = name === "solid" || name === "emissive" || name === "cutout";
      mesh.metadata = { chunkKey: ckey(chunk.cx, chunk.cz), bucket: name };
      mesh.doNotSyncBoundingInfo = true;
      mesh.alwaysSelectAsActiveMesh = false;
      chunk.meshes.push(mesh);
    }
  }

  private unloadChunk(k: number, c: Chunk): void {
    this.chunks.delete(k);
    if (c.modified && c.blocks) this.persist(c);
    for (const m of c.meshes) m.dispose();
    c.root.dispose();
    c.meshes = [];
  }

  private persist(c: Chunk): void {
    if (!c.blocks) return;
    const data = c.blocks.slice(); // copy so later edits don't race the async write
    c.modified = false;
    this.savedKeys.add(`${c.cx},${c.cz}`);
    this.saveQueue = this.saveQueue
      .then(() => this.store.save(this.dim, c.cx, c.cz, data))
      .catch((err) => console.error("Chunk save failed", err));
  }

  /** Flushes all modified chunks to storage. Resolves when writes complete. */
  async flush(): Promise<void> {
    for (const c of this.chunks.values()) if (c.modified && c.blocks) this.persist(c);
    await this.saveQueue;
  }

  // ---- Block access -----------------------------------------------------------
  /** Returns block id, 0 for air outside the world height, or -1 when the chunk is not loaded. */
  getBlock(x: number, y: number, z: number): number {
    if (y < 0) return BID.bedrock;
    if (y >= WORLD_HEIGHT) return 0;
    const cx = Math.floor(x / CHUNK_SIZE), cz = Math.floor(z / CHUNK_SIZE);
    const c = this.chunks.get(ckey(cx, cz));
    if (!c || !c.blocks) return -1;
    return c.blocks[(y << 8) | (((z - cz * 16) & 15) << 4) | ((x - cx * 16) & 15)];
  }

  isChunkLoaded(x: number, z: number): boolean {
    const c = this.chunks.get(ckey(Math.floor(x / CHUNK_SIZE), Math.floor(z / CHUNK_SIZE)));
    return !!(c && c.blocks);
  }

  /** Sets a block. Returns false if the target chunk is not loaded. */
  setBlock(x: number, y: number, z: number, id: number): boolean {
    if (y < 0 || y >= WORLD_HEIGHT) return false;
    const cx = Math.floor(x / CHUNK_SIZE), cz = Math.floor(z / CHUNK_SIZE);
    const c = this.chunks.get(ckey(cx, cz));
    if (!c || !c.blocks) return false;
    const lx = (x - cx * 16) & 15, lz = (z - cz * 16) & 15;
    const old = c.blocks[(y << 8) | (lz << 4) | lx];
    c.blocks[(y << 8) | (lz << 4) | lx] = id;
    c.modified = true;
    c.dirty = true;
    if ((BLOCKS[old]?.light ?? 0) > 0 || (BLOCKS[id]?.light ?? 0) > 0) {
      this.scanEmitters(c);
      for (let dx = -1; dx <= 1; dx++) for (let dz = -1; dz <= 1; dz++) this.markDirty(cx + dx, cz + dz);
    }
    if (lx === 0) this.markDirty(cx - 1, cz);
    if (lx === 15) this.markDirty(cx + 1, cz);
    if (lz === 0) this.markDirty(cx, cz - 1);
    if (lz === 15) this.markDirty(cx, cz + 1);
    return true;
  }

  private markDirty(cx: number, cz: number): void {
    const n = this.chunks.get(ckey(cx, cz));
    if (n && n.blocks) n.dirty = true;
  }

  /** Iterates currently built meshes (for shadows / reflections). */
  forEachMesh(fn: (m: AbstractMesh, cx: number, cz: number) => void): void {
    for (const c of this.chunks.values()) for (const m of c.meshes) fn(m, c.cx, c.cz);
  }

  /** Collects opaque terrain meshes within `radius` chunks of a point (for mirrored reflections). */
  collectMeshes(px: number, pz: number, radius: number, bucketFilter: (name: string) => boolean): Mesh[] {
    const out: Mesh[] = [];
    const pcx = Math.floor(px / CHUNK_SIZE), pcz = Math.floor(pz / CHUNK_SIZE);
    for (const c of this.chunks.values()) {
      if (Math.abs(c.cx - pcx) > radius || Math.abs(c.cz - pcz) > radius) continue;
      for (const m of c.meshes) if (bucketFilter((m.metadata as { bucket: string }).bucket)) out.push(m);
    }
    return out;
  }

  /** Surface height (first solid from top) for a column using loaded data; -1 if unknown. */
  surfaceY(x: number, z: number): number {
    for (let y = WORLD_HEIGHT - 1; y > 0; y--) {
      const id = this.getBlock(x, y, z);
      if (id === -1) return -1;
      if (id !== 0 && BLOCKS[id] && BLOCKS[id].solid) return y;
    }
    return 0;
  }

  chunkCount(): number {
    return this.chunks.size;
  }

  loadedChunkCount(): number {
    let n = 0;
    for (const c of this.chunks.values()) if (c.blocks) n++;
    return n;
  }

  /** Counts chunks within a radius that are ready (for the loading screen). */
  readyAround(px: number, pz: number, radius: number): { ready: number; total: number } {
    const pcx = Math.floor(px / CHUNK_SIZE), pcz = Math.floor(pz / CHUNK_SIZE);
    let ready = 0, total = 0;
    for (let dx = -radius; dx <= radius; dx++) for (let dz = -radius; dz <= radius; dz++) {
      if (dx * dx + dz * dz > radius * radius) continue;
      total++;
      const c = this.chunks.get(ckey(pcx + dx, pcz + dz));
      if (c && c.blocks && !c.dirty) ready++;
    }
    return { ready, total };
  }

  dispose(): void {
    if (this.disposed) return;
    for (const c of this.chunks.values()) if (c.modified && c.blocks) this.persist(c);
    this.disposed = true;
    for (const c of this.chunks.values()) {
      for (const m of c.meshes) m.dispose();
      c.root.dispose();
    }
    this.chunks.clear();
    this.pending.clear();
    for (const w of this.workers) w.terminate();
    this.workers = [];
  }

  /** Biome name at a column (overworld only). */
  biomeAt(x: number, z: number): string {
    if (this.dim !== "overworld") return this.dim;
    return climateAt(this.params, x, z).biome;
  }

  biomeName(x: number, z: number): string {
    return BIOME_BY_ID[this.biomeAt(x, z)]?.name ?? this.dim;
  }
}

const ringCache = new Map<number, [number, number][]>();
function ringOffsets(radius: number): [number, number][] {
  let arr = ringCache.get(radius);
  if (arr) return arr;
  arr = [];
  for (let dx = -radius; dx <= radius; dx++) for (let dz = -radius; dz <= radius; dz++) {
    if (dx * dx + dz * dz <= radius * radius + 1) arr.push([dx, dz]);
  }
  arr.sort((a, b) => a[0] * a[0] + a[1] * a[1] - (b[0] * b[0] + b[1] * b[1]));
  ringCache.set(radius, arr);
  return arr;
}
