// Biome registry. Data-driven: add an entry to BIOMES and extend selectBiome() to make it appear.
// Biome ids are indices into BIOME_LIST (stored in generated chunks only via block data, never persisted).

export type TreeKind = "oak" | "birch" | "spruce" | "cherry" | "jungle" | "dead" | "mushroom" | "cactus" | "palm" | "none"
  | "big_oak" | "mega_spruce" | "tall_birch" | "acacia" | "mixed";

export interface Biome {
  id: string;
  name: string;
  top: string; // surface block key
  under: string; // subsurface block key
  tint: "grass" | "none"; // vertex tint type
  trees: TreeKind;
  treeDensity: number; // chance per column of a tree root (0-1)
  tallGrass: number;
  flowers: number;
  flowerKinds: string[];
  fog: [number, number, number];
  passive: string[];
  hostile: string[];
  snowy: boolean;
  water: "water" | "toxic_water" | "sift_water";
  structures: string[]; // structure ids allowed here
  ambient: string; // ambient soundscape id
}

export const BIOMES: Biome[] = [
  { id: "plains", name: "Plains", top: "grass_block", under: "dirt", tint: "grass", trees: "oak", treeDensity: 0.006, tallGrass: 0.25, flowers: 0.02, flowerKinds: ["poppy", "cornflower"], fog: [0.72, 0.84, 0.92], passive: ["cow", "pig", "sheep", "chicken"], hostile: ["zombie", "skeleton", "creeper"], snowy: false, water: "water", structures: ["village", "ruin", "balloon"], ambient: "meadow" },
  { id: "forest", name: "Forest", top: "grass_block", under: "dirt", tint: "grass", trees: "oak", treeDensity: 0.07, tallGrass: 0.3, flowers: 0.03, flowerKinds: ["poppy", "cornflower"], fog: [0.68, 0.8, 0.88], passive: ["pig", "cow", "chicken"], hostile: ["zombie", "spider", "skeleton"], snowy: false, water: "water", structures: ["ruin", "village"], ambient: "forest" },
  { id: "birch_forest", name: "Birch Forest", top: "grass_block", under: "dirt", tint: "grass", trees: "birch", treeDensity: 0.06, tallGrass: 0.3, flowers: 0.02, flowerKinds: ["cornflower"], fog: [0.7, 0.82, 0.9], passive: ["sheep", "cow"], hostile: ["zombie", "skeleton"], snowy: false, water: "water", structures: ["ruin"], ambient: "forest" },
  { id: "dark_forest", name: "Dark Forest", top: "grass_block", under: "dirt", tint: "grass", trees: "oak", treeDensity: 0.14, tallGrass: 0.4, flowers: 0.01, flowerKinds: ["poppy"], fog: [0.36, 0.4, 0.42], passive: ["pig"], hostile: ["zombie", "spider", "creeper", "skeleton"], snowy: false, water: "water", structures: ["ruin", "village"], ambient: "night_forest" },
  { id: "autumn_woods", name: "Autumn Woods", top: "grass_block", under: "dirt", tint: "grass", trees: "oak", treeDensity: 0.05, tallGrass: 0.25, flowers: 0.01, flowerKinds: ["poppy"], fog: [0.82, 0.7, 0.55], passive: ["cow", "sheep"], hostile: ["zombie", "skeleton"], snowy: false, water: "water", structures: ["ruin"], ambient: "forest" },
  { id: "cherry_grove", name: "Cherry Grove", top: "grass_block", under: "dirt", tint: "grass", trees: "cherry", treeDensity: 0.05, tallGrass: 0.3, flowers: 0.04, flowerKinds: ["cornflower", "poppy"], fog: [0.92, 0.78, 0.86], passive: ["pig", "sheep", "chicken"], hostile: ["zombie"], snowy: false, water: "water", structures: ["village", "balloon"], ambient: "meadow" },
  { id: "taiga", name: "Taiga", top: "grass_block", under: "dirt", tint: "grass", trees: "spruce", treeDensity: 0.07, tallGrass: 0.15, flowers: 0.0, flowerKinds: [], fog: [0.55, 0.68, 0.78], passive: ["sheep", "cow", "chicken"], hostile: ["zombie", "skeleton", "spider"], snowy: false, water: "water", structures: ["ruin", "village"], ambient: "night_forest" },
  { id: "snowy_plains", name: "Snowy Plains", top: "snow_grass", under: "dirt", tint: "none", trees: "spruce", treeDensity: 0.003, tallGrass: 0, flowers: 0, flowerKinds: [], fog: [0.8, 0.88, 0.95], passive: ["sheep", "chicken"], hostile: ["zombie", "skeleton"], snowy: true, water: "water", structures: ["village", "ruin"], ambient: "wind" },
  { id: "snowy_peaks", name: "Snowy Peaks", top: "snow_block", under: "packed_ice", tint: "none", trees: "none", treeDensity: 0, tallGrass: 0, flowers: 0, flowerKinds: [], fog: [0.85, 0.9, 0.97], passive: ["sheep"], hostile: ["skeleton"], snowy: true, water: "water", structures: ["balloon"], ambient: "wind" },
  { id: "mountains", name: "Stony Peaks", top: "stone", under: "stone", tint: "none", trees: "none", treeDensity: 0, tallGrass: 0, flowers: 0, flowerKinds: [], fog: [0.6, 0.7, 0.8], passive: ["sheep", "chicken"], hostile: ["skeleton", "zombie"], snowy: false, water: "water", structures: ["ruin", "balloon"], ambient: "wind" },
  { id: "desert", name: "Desert", top: "sand", under: "sandstone", tint: "none", trees: "cactus", treeDensity: 0.01, tallGrass: 0, flowers: 0, flowerKinds: [], fog: [0.95, 0.85, 0.65], passive: ["rabbit_like_none"].filter(() => false), hostile: ["zombie", "skeleton"], snowy: false, water: "water", structures: ["pyramid", "ruin"], ambient: "desert" },
  { id: "savanna", name: "Savanna", top: "grass_block", under: "dirt", tint: "grass", trees: "oak", treeDensity: 0.004, tallGrass: 0.35, flowers: 0.0, flowerKinds: [], fog: [0.9, 0.84, 0.66], passive: ["cow", "sheep"], hostile: ["zombie", "skeleton"], snowy: false, water: "water", structures: ["village"], ambient: "desert" },
  { id: "badlands", name: "Badlands", top: "terracotta", under: "terracotta", tint: "none", trees: "dead", treeDensity: 0.003, tallGrass: 0, flowers: 0, flowerKinds: [], fog: [0.9, 0.7, 0.55], passive: [], hostile: ["zombie", "skeleton"], snowy: false, water: "water", structures: ["pyramid", "ruin"], ambient: "desert" },
  { id: "swamp", name: "Swamp", top: "grass_block", under: "dirt", tint: "grass", trees: "oak", treeDensity: 0.02, tallGrass: 0.5, flowers: 0.01, flowerKinds: ["cornflower"], fog: [0.5, 0.6, 0.5], passive: ["sheep", "chicken"], hostile: ["zombie", "spider", "creeper"], snowy: false, water: "water", structures: ["ruin"], ambient: "swamp" },
  { id: "toxic_marsh", name: "Toxic Marsh", top: "moss_block", under: "mud", tint: "grass", trees: "dead", treeDensity: 0.02, tallGrass: 0.2, flowers: 0.02, flowerKinds: ["dead_bush"], fog: [0.42, 0.3, 0.5], passive: [], hostile: ["zombie", "spider", "creeper", "enderman"], snowy: false, water: "toxic_water", structures: ["ruin"], ambient: "swamp" },
  { id: "mushroom_valley", name: "Mushroom Valley", top: "podzol", under: "dirt", tint: "none", trees: "mushroom", treeDensity: 0.012, tallGrass: 0, flowers: 0.02, flowerKinds: ["red_mushroom", "brown_mushroom"], fog: [0.7, 0.6, 0.78], passive: ["cow", "chicken"], hostile: ["zombie", "skeleton"], snowy: false, water: "water", structures: ["ruin"], ambient: "night_forest" },
  { id: "boneyard", name: "Boneyard", top: "ash", under: "bone_block", tint: "none", trees: "dead", treeDensity: 0.02, tallGrass: 0.05, flowers: 0.01, flowerKinds: ["dead_bush"], fog: [0.48, 0.46, 0.46], passive: [], hostile: ["skeleton", "zombie", "spider"], snowy: false, water: "water", structures: ["ruin", "boneyard"], ambient: "wind" },
  { id: "jungle", name: "Jungle", top: "grass_block", under: "dirt", tint: "grass", trees: "jungle", treeDensity: 0.1, tallGrass: 0.6, flowers: 0.05, flowerKinds: ["poppy", "cornflower"], fog: [0.6, 0.85, 0.7], passive: ["chicken", "pig"], hostile: ["zombie", "spider", "creeper"], snowy: false, water: "water", structures: ["ruin"], ambient: "forest" },
  { id: "beach", name: "Beach", top: "sand", under: "sand", tint: "none", trees: "palm", treeDensity: 0.002, tallGrass: 0, flowers: 0, flowerKinds: [], fog: [0.8, 0.9, 0.96], passive: ["chicken"], hostile: ["zombie"], snowy: false, water: "water", structures: [], ambient: "ocean" },
  { id: "ocean", name: "Ocean", top: "sand", under: "gravel", tint: "none", trees: "none", treeDensity: 0, tallGrass: 0, flowers: 0, flowerKinds: [], fog: [0.45, 0.72, 0.85], passive: [], hostile: ["zombie"], snowy: false, water: "water", structures: ["shipwreck"], ambient: "ocean" },
  { id: "deep_ocean", name: "Deep Ocean", top: "gravel", under: "stone", tint: "none", trees: "none", treeDensity: 0, tallGrass: 0, flowers: 0, flowerKinds: [], fog: [0.2, 0.42, 0.6], passive: [], hostile: ["zombie"], snowy: false, water: "water", structures: [], ambient: "ocean" },
  { id: "river", name: "River", top: "sand", under: "gravel", tint: "none", trees: "none", treeDensity: 0, tallGrass: 0, flowers: 0, flowerKinds: [], fog: [0.55, 0.75, 0.9], passive: [], hostile: [], snowy: false, water: "water", structures: [], ambient: "ocean" },
  { id: "sky_isles", name: "Sky Isles", top: "grass_block", under: "dirt", tint: "grass", trees: "oak", treeDensity: 0.05, tallGrass: 0.2, flowers: 0.02, flowerKinds: ["cornflower"], fog: [0.7, 0.85, 1.0], passive: ["sheep", "chicken"], hostile: ["skeleton"], snowy: false, water: "water", structures: [], ambient: "wind" },
];

// Additional biomes and denser, more varied forests (appended so existing indices stay stable).
BIOMES.push(
  { id: "flower_forest", name: "Flower Forest", top: "grass_block", under: "dirt", tint: "grass", trees: "mixed", treeDensity: 0.05, tallGrass: 0.35, flowers: 0.22, flowerKinds: ["poppy", "dandelion", "allium", "cornflower"], fog: [0.75, 0.85, 0.92], passive: ["pig", "sheep", "chicken"], hostile: ["zombie", "skeleton"], snowy: false, water: "water", structures: ["village", "ruin"], ambient: "forest" },
  { id: "old_growth_taiga", name: "Old Growth Taiga", top: "podzol", under: "dirt", tint: "grass", trees: "mega_spruce", treeDensity: 0.07, tallGrass: 0.3, flowers: 0.02, flowerKinds: ["brown_mushroom", "red_mushroom"], fog: [0.5, 0.62, 0.7], passive: ["sheep", "cow"], hostile: ["zombie", "spider", "skeleton"], snowy: false, water: "water", structures: ["ruin", "mansion"], ambient: "night_forest" },
  { id: "meadow", name: "Meadow", top: "grass_block", under: "dirt", tint: "grass", trees: "big_oak", treeDensity: 0.004, tallGrass: 0.55, flowers: 0.12, flowerKinds: ["dandelion", "allium", "cornflower", "poppy"], fog: [0.78, 0.88, 0.96], passive: ["sheep", "cow", "pig"], hostile: ["zombie"], snowy: false, water: "water", structures: ["village", "balloon"], ambient: "meadow" },
);
for (const b of BIOMES) {
  if (b.id === "forest") { b.trees = "mixed"; b.treeDensity = 0.09; b.tallGrass = 0.4; }
  if (b.id === "dark_forest") { b.trees = "big_oak"; b.treeDensity = 0.16; b.structures = ["mansion", "ruin"]; }
  if (b.id === "birch_forest") { b.trees = "tall_birch"; b.treeDensity = 0.09; }
  if (b.id === "taiga") { b.treeDensity = 0.09; b.flowerKinds = ["fern"]; b.flowers = 0.15; }
  if (b.id === "savanna") { b.trees = "acacia"; b.treeDensity = 0.008; b.tallGrass = 0.5; }
  if (b.id === "jungle") { b.treeDensity = 0.14; b.tallGrass = 0.7; b.flowerKinds = ["fern", "poppy"]; }
  if (b.id === "plains") { b.tallGrass = 0.45; b.flowers = 0.04; b.flowerKinds = ["poppy", "dandelion", "cornflower"]; }
  if (b.id === "desert") b.structures = ["giant_pyramid", "fossil", "ruin"];
  if (b.id === "badlands") b.structures = ["volcano", "fossil", "ruin"];
  if (b.id === "mountains") b.structures = ["volcano", "ruin"];
  if (b.id === "snowy_plains") b.structures = ["village", "mansion"];
}

export const BIOME_BY_ID: Record<string, Biome> = {};
BIOMES.forEach((b) => (BIOME_BY_ID[b.id] = b));

export function biomeIndex(id: string): number {
  return BIOMES.findIndex((b) => b.id === id);
}

export interface ClimateSample {
  temp: number; // -1..1
  humid: number; // -1..1
  cont: number; // continentalness -1..1 (negative = ocean)
  erosion: number; // -1..1
  weird: number; // -1..1 (mushroom valleys, boneyards, toxic marsh...)
  height: number;
  seaLevel: number;
}

/** Deterministic biome selection from climate fields. Pure; used by the generator. */
export function selectBiome(c: ClimateSample): string {
  const { temp, humid, cont, weird, height, seaLevel } = c;
  if (cont < -0.42) return "deep_ocean";
  if (cont < -0.2) return "ocean";
  if (cont < -0.1 && height < seaLevel + 2) return "ocean";
  if (height < seaLevel + 2 && height > seaLevel - 4 && Math.abs(cont) < 0.12) return "beach";
  if (height > 150) return temp < -0.1 ? "snowy_peaks" : "mountains";
  if (height > 112) return temp < -0.35 ? "snowy_peaks" : "mountains";
  if (height < seaLevel - 1 && weird > 0.45 && humid > 0.1) return "toxic_marsh";
  if (weird > 0.55 && humid > 0.05 && temp > -0.1 && temp < 0.45) return "mushroom_valley";
  if (weird < -0.62 && temp > 0.0 && humid < 0.15) return "boneyard";
  if (temp < -0.4) return humid > 0.1 ? "taiga" : "snowy_plains";
  if (temp < -0.2) return humid > 0.2 ? "taiga" : "snowy_plains";
  if (temp > 0.5 && humid < -0.35) return "badlands";
  if (temp > 0.42 && humid < -0.05) return "desert";
  if (temp > 0.25 && humid > 0.45) return "jungle";
  if (humid > 0.5 && height < seaLevel + 4) return "swamp";
  if (temp > 0.18 && humid < -0.18) return "savanna";
  if (humid > 0.36) return weird > 0.2 ? "birch_forest" : "dark_forest";
  if (weird < -0.32 && temp < 0.1) return "autumn_woods";
  if (weird > 0.3 && humid > 0.0) return "cherry_grove";
  if (humid > 0.1) return weird > 0.0 ? "birch_forest" : "forest";
  return "plains";
}
