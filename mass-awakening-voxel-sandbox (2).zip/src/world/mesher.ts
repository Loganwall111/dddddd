// Chunk mesher: hidden-face culling, per-vertex ambient occlusion, biome/season tint baked into vertex color.
// Produces plain arrays grouped by render bucket; the World converts them into Babylon meshes.
//
// Greedy merging is intentionally NOT used: atlas-based tiling needs a custom shader to repeat tiles.
// Per-face quads + AO keep shadows, fog and normal-mapped lighting on the standard Babylon materials.

import { BLOCKS, BID, occludes } from "../blocks/blocks";
import { tileUV } from "../blocks/textures";
import { CHUNK_SIZE, WORLD_HEIGHT } from "./generator";

export const PAD = CHUNK_SIZE + 2; // 18
export const PAD_H = WORLD_HEIGHT + 2; // 258
export const PAD_VOLUME = PAD * PAD_H * PAD;
export const UNKNOWN = 0xffff;

export interface MeshData {
  positions: number[];
  normals: number[];
  uvs: number[];
  colors: number[];
  indices: number[];
}

export type Buckets = Record<string, MeshData>;

export function padIndex(x: number, y: number, z: number): number {
  return ((y + 1) * PAD + (z + 1)) * PAD + (x + 1);
}

/** Fills a padded (1-block border) copy of a chunk so the mesher can see neighbours. */
export function fillPadded(out: Uint16Array, center: Uint16Array, getNeighbor: (dx: number, dz: number) => Uint16Array | null): void {
  const bedrock = BID.bedrock;
  for (let py = 0; py < PAD_H; py++) {
    const y = py - 1;
    for (let pz = 0; pz < PAD; pz++) {
      const z = pz - 1;
      const dz = z < 0 ? -1 : z > 15 ? 1 : 0;
      const lz = z - dz * 16;
      for (let px = 0; px < PAD; px++) {
        const x = px - 1;
        const dx = x < 0 ? -1 : x > 15 ? 1 : 0;
        const lx = x - dx * 16;
        const o = (py * PAD + pz) * PAD + px;
        if (y < 0) { out[o] = bedrock; continue; }
        if (y >= WORLD_HEIGHT) { out[o] = 0; continue; }
        const src = dx === 0 && dz === 0 ? center : getNeighbor(dx, dz);
        if (!src) { out[o] = UNKNOWN; continue; }
        out[o] = src[(y << 8) | (lz << 4) | lx];
      }
    }
  }
}

// Corner offsets per face (+X,-X,+Y,-Y,+Z,-Z)
const NORMALS: [number, number, number][] = [[1, 0, 0], [-1, 0, 0], [0, 1, 0], [0, -1, 0], [0, 0, 1], [0, 0, -1]];
const FACE_CORNERS: number[][][] = [
  [[1, 0, 0], [1, 1, 0], [1, 1, 1], [1, 0, 1]],
  [[0, 0, 1], [0, 1, 1], [0, 1, 0], [0, 0, 0]],
  [[0, 1, 0], [0, 1, 1], [1, 1, 1], [1, 1, 0]],
  [[0, 0, 1], [0, 0, 0], [1, 0, 0], [1, 0, 1]],
  [[1, 0, 1], [1, 1, 1], [0, 1, 1], [0, 0, 1]],
  [[0, 0, 0], [0, 1, 0], [1, 1, 0], [1, 0, 0]],
];

const TILE_CACHE = new Map<string, [number, number, number, number]>();
function uvOf(name: string): [number, number, number, number] {
  let r = TILE_CACHE.get(name);
  if (!r) {
    r = tileUV(name);
    TILE_CACHE.set(name, r);
  }
  return r;
}

export interface TintTables {
  grass: Float32Array; // 256 columns * 3
  foliage: Float32Array;
}

class BucketSet {
  buckets: Buckets = {};
  get(name: string): MeshData {
    let b = this.buckets[name];
    if (!b) {
      b = { positions: [], normals: [], uvs: [], colors: [], indices: [] };
      this.buckets[name] = b;
    }
    return b;
  }
}

function pushQuad(
  m: MeshData,
  p: number[][], // 4 corners [x,y,z]
  n: number[],
  uv: [number, number, number, number],
  c: number[][], // 4 colors [r,g,b]
  flip: boolean,
): void {
  const base = m.positions.length / 3;
  const [u0, v0, u1, v1] = uv;
  const uvs = [u0, v1, u0, v0, u1, v0, u1, v1];
  for (let i = 0; i < 4; i++) {
    m.positions.push(p[i][0], p[i][1], p[i][2]);
    m.normals.push(n[0], n[1], n[2]);
    m.uvs.push(uvs[i * 2], uvs[i * 2 + 1]);
    m.colors.push(c[i][0], c[i][1], c[i][2], 1);
  }
  if (flip) m.indices.push(base, base + 1, base + 3, base + 1, base + 2, base + 3);
  else m.indices.push(base, base + 1, base + 2, base, base + 2, base + 3);
}

function pushCrossedPlants(m: MeshData, x: number, y: number, z: number, uv: [number, number, number, number], inset: number, height: number, tint: number[]): void {
  const i = inset, j = 1 - inset;
  const colr = [[1, 1, 1], [1, 1, 1], [1, 1, 1], [1, 1, 1]].map((c) => [c[0] * tint[0], c[1] * tint[1], c[2] * tint[2]]);
  const up = [0, 1, 0];
  pushQuad(m, [[x + i, y, z + i], [x + j, y, z + j], [x + j, y + height, z + j], [x + i, y + height, z + i]], up, uv, colr, false);
  pushQuad(m, [[x + j, y, z + i], [x + i, y, z + j], [x + i, y + height, z + j], [x + j, y + height, z + i]], up, uv, colr, false);
}

/** Light emitters near a chunk: flat array of [x, y, z, r, g, b, strength] in chunk-local coordinates. */
export type Emitters = Float32Array;
export const EMITTER_STRIDE = 7;
export const LIGHT_RADIUS = 11;

/** Sums coloured block light at a point (distance falloff, no occlusion: light can leak through thin walls). */
function sampleLight(em: Emitters | undefined, x: number, y: number, z: number, out: number[]): void {
  out[0] = 0; out[1] = 0; out[2] = 0;
  if (!em || em.length === 0) return;
  const R2 = LIGHT_RADIUS * LIGHT_RADIUS;
  for (let i = 0; i < em.length; i += EMITTER_STRIDE) {
    const dx = x - em[i], dy = y - em[i + 1], dz = z - em[i + 2];
    const d2 = dx * dx + dy * dy + dz * dz;
    if (d2 >= R2) continue;
    const f = 1 - Math.sqrt(d2) / LIGHT_RADIUS;
    const k = f * f * em[i + 6];
    out[0] += em[i + 3] * k; out[1] += em[i + 4] * k; out[2] += em[i + 5] * k;
  }
  // soft cap so overlapping lights don't blow out
  const m = Math.max(out[0], out[1], out[2]);
  if (m > 1.6) { const s = 1.6 / m; out[0] *= s; out[1] *= s; out[2] *= s; }
}

/** Meshes one chunk from its padded block array. */
export function meshChunk(padded: Uint16Array, tints: TintTables, emitters?: Emitters): Buckets {
  const set = new BucketSet();
  const occ = (id: number) => id === UNKNOWN || occludes(id);
  const L = [0, 0, 0];
  const hasLight = !!emitters && emitters.length > 0;

  for (let y = 0; y < WORLD_HEIGHT; y++) {
    for (let z = 0; z < 16; z++) {
      for (let x = 0; x < 16; x++) {
        const id = padded[padIndex(x, y, z)];
        if (id === 0) continue;
        const def = BLOCKS[id];
        if (!def) continue;
        const col = z * 16 + x;
        const gr = [tints.grass[col * 3], tints.grass[col * 3 + 1], tints.grass[col * 3 + 2]];
        const fo = [tints.foliage[col * 3], tints.foliage[col * 3 + 1], tints.foliage[col * 3 + 2]];

        switch (def.render) {
          case "plant": {
            let tint = def.tint === "grass" ? gr : def.tint === "foliage" ? fo : [1, 1, 1];
            if (hasLight) {
              sampleLight(emitters, x + 0.5, y + 0.5, z + 0.5, L);
              tint = [tint[0] + L[0] * 1.8, tint[1] + L[1] * 1.8, tint[2] + L[2] * 1.8];
            }
            pushCrossedPlants(set.get("cutout"), x, y, z, uvOf(def.side), 0.08, def.key === "snow_layer" ? 0.2 : 0.95, tint);
            break;
          }
          case "torch": {
            pushCrossedPlants(set.get("emissive_cut"), x, y, z, uvOf("torch"), 0.3, 0.9, [1, 1, 1]);
            break;
          }
          case "water":
          case "lava": {
            const bucket = def.render === "lava" ? "lava" : def.key;
            const m = set.get(bucket);
            const aboveSame = padded[padIndex(x, y + 1, z)] === id;
            const topH = aboveSame ? 1 : 0.875;
            for (let f = 0; f < 6; f++) {
              const n = NORMALS[f];
              const nid = padded[padIndex(x + n[0], y + n[1], z + n[2])];
              if (nid === id) continue;
              if (f !== 2 && occludes(nid)) continue;
              if (f === 2 && nid === id) continue;
              if (f === 3 && nid !== UNKNOWN && nid !== 0 && occludes(nid)) continue;
              const corners = FACE_CORNERS[f].map(([ox, oy, oz]) => [x + ox, y + (oy ? topH : 0) + 0 * oz, z + oz]);
              const cc = [[1, 1, 1], [1, 1, 1], [1, 1, 1], [1, 1, 1]];
              pushQuad(m, corners, n, uvOf(def.top), cc, false);
            }
            break;
          }
          case "portal": {
            const m = set.get("portal");
            for (let f = 0; f < 6; f++) {
              const n = NORMALS[f];
              const nid = padded[padIndex(x + n[0], y + n[1], z + n[2])];
              if (nid === id || occludes(nid)) continue;
              const corners = FACE_CORNERS[f].map(([ox, oy, oz]) => [x + ox, y + oy, z + oz]);
              pushQuad(m, corners, n, uvOf("portal"), [[1, 1, 1], [1, 1, 1], [1, 1, 1], [1, 1, 1]], false);
            }
            break;
          }
          case "solid":
          case "emissive":
          case "glass":
          case "cutout": {
            const bucket = def.render === "solid" ? "solid" : def.render === "emissive" ? "emissive" : def.render === "glass" ? "glass" : "cutout";
            const m = set.get(bucket);
            const isOpaque = def.render === "solid" || def.render === "emissive";
            for (let f = 0; f < 6; f++) {
              const n = NORMALS[f];
              const nx = x + n[0], ny = y + n[1], nz = z + n[2];
              const nid = padded[padIndex(nx, ny, nz)];
              if (nid === id && !isOpaque) continue; // hide internal faces of glass/leaves
              if (occludes(nid) || (nid === UNKNOWN && isOpaque)) continue;
              if (nid === UNKNOWN && !isOpaque) continue;
              const tileName = f === 2 ? def.top : f === 3 ? def.bottom : def.side;
              const uv = uvOf(tileName);
              const tintArr = def.tint === "grass" && f === 2 ? gr : def.tint === "foliage" ? fo : [1, 1, 1];
              const [ax, bx] = tangents(f);
              const corners: number[][] = [];
              const colors: number[][] = [];
              const aoVals: number[] = [];
              for (let c = 0; c < 4; c++) {
                const off = FACE_CORNERS[f][c];
                corners.push([x + off[0], y + off[1], z + off[2]]);
                const da = off[ax] ? 1 : -1;
                const db = off[bx] ? 1 : -1;
                const s1 = occ(padded[padIndex(nx + (ax === 0 ? da : 0), ny + (ax === 1 ? da : 0), nz + (ax === 2 ? da : 0))]) ? 1 : 0;
                const s2 = occ(padded[padIndex(nx + (bx === 0 ? db : 0), ny + (bx === 1 ? db : 0), nz + (bx === 2 ? db : 0))]) ? 1 : 0;
                const cr = occ(padded[padIndex(
                  nx + (ax === 0 ? da : 0) + (bx === 0 ? db : 0),
                  ny + (ax === 1 ? da : 0) + (bx === 1 ? db : 0),
                  nz + (ax === 2 ? da : 0) + (bx === 2 ? db : 0),
                )]) ? 1 : 0;
                const k = s1 && s2 ? 3 : s1 + s2 + cr;
                aoVals.push(k);
                const b = isOpaque ? 1 - k * 0.14 : 1;
                if (hasLight && def.render !== "emissive") {
                  sampleLight(emitters, x + off[0] + n[0] * 0.5, y + off[1] + n[1] * 0.5, z + off[2] + n[2] * 0.5, L);
                  // additive coloured block light (vertex colours > 1 brighten past the sun-lit value)
                  colors.push([tintArr[0] * b + L[0] * 1.8 * b, tintArr[1] * b + L[1] * 1.8 * b, tintArr[2] * b + L[2] * 1.8 * b]);
                } else {
                  colors.push([tintArr[0] * b, tintArr[1] * b, tintArr[2] * b]);
                }
              }
              const flip = aoVals[0] + aoVals[2] > aoVals[1] + aoVals[3];
              pushQuad(m, corners, n, uv, colors, flip);
            }
            break;
          }
          default:
            break;
        }
      }
    }
  }
  return set.buckets;
}

/** Returns the two tangent axis indices (0=x,1=y,2=z) of a face. */
function tangents(f: number): [number, number] {
  switch (f) {
    case 0:
    case 1: return [1, 2];
    case 2:
    case 3: return [0, 2];
    default: return [0, 1];
  }
}

export function emptyBucketMeshes(): Buckets {
  return {};
}
