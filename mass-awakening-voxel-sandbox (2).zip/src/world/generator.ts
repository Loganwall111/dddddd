// Pure, deterministic chunk generator (runs inside Web Workers; no DOM / Babylon access).
// Chunk layout: 16 x 256 x 16, index = (y << 8) | (z << 4) | x, values are block ids (see blocks.ts).
//
// Overworld terrain follows the legacy Minecraft noise router structure:
//   density = heightFalloff(biome depth/scale, blended 5x5) + lerp(low, high, selector) + depth noise
// sampled on a 4x8x4 grid and trilinearly interpolated. Noise octave counts and base frequencies match
// the documented values (low/selector 16 oct @0.00522, high 8 oct @0.00261, depth 16 oct @0.00153);
// octaves above the grid's Nyquist limit are skipped because they only alias into speckle.

import { BID, blockIdByKey } from "../blocks/blocks";
import { BIOME_BY_ID, type Biome } from "./biomes";
import { OctaveNoise, fbm3, hash2, hash3, noise2, noise3, smoothstep, clamp } from "./noise";

export const CHUNK_SIZE = 16;
export const WORLD_HEIGHT = 256;
export const SEA_LEVEL = 63;
export const CHUNK_VOLUME = CHUNK_SIZE * CHUNK_SIZE * WORLD_HEIGHT;

export type DimId = "overworld" | "nether" | "end" | "sift";
export type WorldType = "default" | "amplified" | "flat" | "extreme" | "islands" | "tutorial";

export interface GenParams {
  seed: number;
  dim: DimId;
  type: WorldType;
}

export interface SpawnRec {
  kind: string;
  x: number;
  y: number;
  z: number;
}

export interface GenResult {
  blocks: Uint16Array;
  spawns: SpawnRec[];
}

const B = (k: string) => blockIdByKey(k);
const AIR = 0;
const STONE = BID.stone, DEEPSLATE = BID.deepslate, BEDROCK = BID.bedrock, LAVA = BID.lava, WATER = BID.water;
const TOXIC = BID.toxic_water, SIFTW = BID.sift_water, ICE = BID.ice;

// ---- Noise set (cached per seed inside each worker) --------------------------------------
interface Noises {
  low: OctaveNoise; high: OctaveNoise; sel: OctaveNoise; depth: OctaveNoise;
  temp: OctaveNoise; humid: OctaveNoise; cont: OctaveNoise; ero: OctaveNoise; weird: OctaveNoise; river: OctaveNoise;
  fill: OctaveNoise; flower: OctaveNoise; cheese: OctaveNoise; sp1: OctaveNoise; sp2: OctaveNoise; crystal: OctaveNoise;
  band: OctaveNoise; pillar: OctaveNoise;
}
const noiseCache = new Map<number, Noises>();
function N(seed: number): Noises {
  let n = noiseCache.get(seed);
  if (n) return n;
  n = {
    low: new OctaveNoise(seed + 1, 16, 0.00522, 0.2),
    high: new OctaveNoise(seed + 2, 8, 0.00261, 0.2),
    sel: new OctaveNoise(seed + 3, 16, 0.00522, 0.1),
    depth: new OctaveNoise(seed + 4, 16, 0.00153, 0.05),
    temp: new OctaveNoise(seed + 10, 4, 0.0009),
    humid: new OctaveNoise(seed + 11, 4, 0.0011),
    cont: new OctaveNoise(seed + 12, 5, 0.0007),
    ero: new OctaveNoise(seed + 13, 4, 0.0018),
    weird: new OctaveNoise(seed + 14, 4, 0.0021),
    river: new OctaveNoise(seed + 15, 3, 0.0024),
    fill: new OctaveNoise(seed + 20, 4, 0.00781, 0.5),
    flower: new OctaveNoise(seed + 21, 3, 0.02, 0.5),
    cheese: new OctaveNoise(seed + 30, 3, 0.014, 0.2),
    sp1: new OctaveNoise(seed + 31, 2, 0.028, 0.2),
    sp2: new OctaveNoise(seed + 32, 2, 0.028, 0.2),
    crystal: new OctaveNoise(seed + 33, 2, 0.006, 0.2),
    band: new OctaveNoise(seed + 34, 2, 0.01, 0.2),
    pillar: new OctaveNoise(seed + 35, 2, 0.06, 0.5),
  };
  noiseCache.set(seed, n);
  return n;
}

// ---- Climate & biome selection ----------------------------------------------------------------
interface Climate {
  temp: number; humid: number; cont: number; ero: number; weird: number;
  river: number; // 0..1 river strength
  biome: string;
  h: number; // estimated surface height (for UI / tour / tints; real terrain comes from density)
}

function pickBiome(t: number, h: number, c: number, e: number, w: number): string {
  if (c < -0.45) return "deep_ocean";
  if (c < -0.18) return "ocean";
  if (c < -0.1) return t < -0.4 ? "snowy_plains" : "beach";
  if (c > 0.3 && e < -0.15) return t < -0.25 ? "snowy_peaks" : "mountains";
  if (w > 0.66 && h > 0.1) return "mushroom_valley";
  if (w < -0.7 && t > 0.1 && h < -0.1) return "boneyard";
  if (w > 0.6 && h > 0.5 && c < 0.12) return "toxic_marsh";
  if (t < -0.45) return h > 0.05 ? "taiga" : "snowy_plains";
  if (t < -0.22) return h > 0.35 ? "old_growth_taiga" : h > -0.1 ? "taiga" : "snowy_plains";
  if (t > 0.5) return h < -0.25 ? (t > 0.64 ? "badlands" : "desert") : h < 0.1 ? "savanna" : "jungle";
  if (t > 0.25) return h < -0.3 ? "savanna" : h > 0.45 ? "jungle" : h > 0.15 ? "forest" : "plains";
  if (h > 0.55 && e > 0.25 && c < 0.2) return "swamp";
  if (h > 0.5) return "dark_forest";
  if (h > 0.3) return w > 0.2 ? "flower_forest" : "birch_forest";
  if (h > 0.08) return w < -0.3 ? "autumn_woods" : "forest";
  if (w > 0.38) return "cherry_grove";
  if (w < -0.38) return "meadow";
  return "plains";
}

/** [depth, scale] per biome, legacy-style: depth raises the base height, scale controls hilliness. */
const BIOME_SHAPE: Record<string, [number, number]> = {
  plains: [0.125, 0.05], forest: [0.1, 0.2], birch_forest: [0.1, 0.2], dark_forest: [0.1, 0.2], autumn_woods: [0.2, 0.25],
  cherry_grove: [0.45, 0.35], flower_forest: [0.1, 0.2], taiga: [0.2, 0.2], old_growth_taiga: [0.2, 0.25],
  snowy_plains: [0.125, 0.05], snowy_peaks: [1.7, 0.65], mountains: [1.25, 0.55], desert: [0.125, 0.05], savanna: [0.15, 0.1],
  badlands: [0.35, 0.3], swamp: [-0.2, 0.1], toxic_marsh: [-0.2, 0.1], mushroom_valley: [0.2, 0.3], boneyard: [0.15, 0.15],
  jungle: [0.1, 0.25], beach: [0.0, 0.025], ocean: [-1.0, 0.1], deep_ocean: [-1.8, 0.1], river: [-0.5, 0.0],
  meadow: [0.3, 0.15], sky_isles: [0.125, 0.05],
};

export function climateAt(p: GenParams, wx: number, wz: number): Climate {
  if (p.type === "flat" || p.type === "tutorial") {
    return { temp: 0, humid: 0, cont: 0.2, ero: 0, weird: 0, river: 0, biome: "plains", h: 63 };
  }
  const n = N(p.seed);
  const temp = clamp(n.temp.sample2(wx, wz), -1, 1);
  const humid = clamp(n.humid.sample2(wx, wz), -1, 1);
  const cont = clamp(n.cont.sample2(wx, wz) + 0.12, -1, 1);
  const ero = clamp(n.ero.sample2(wx, wz), -1, 1);
  const weird = clamp(n.weird.sample2(wx, wz), -1, 1);
  const rv = Math.abs(n.river.sample2(wx, wz));
  let biome = pickBiome(temp, humid, cont, ero, weird);
  const river = cont > -0.12 && biome !== "mountains" && biome !== "snowy_peaks" ? smoothstep(0.04, 0.012, rv) : 0;
  if (river > 0.6) biome = temp < -0.4 ? "river" : "river";
  const shape = BIOME_SHAPE[biome] ?? [0.1, 0.1];
  return { temp, humid, cont, ero, weird, river, biome, h: Math.round(64 + shape[0] * 17 * amp(p)) };
}

function amp(p: GenParams): number {
  return p.type === "extreme" ? 2.4 : p.type === "amplified" ? 1.8 : 1;
}

/** Blended [depth, scale] at a column (5x5 parabolic weights over a 4-block grid, like legacy worldgen). */
function blendedShape(p: GenParams, wx: number, wz: number, cache: Map<number, Climate>): [number, number, string] {
  const gx = Math.floor(wx / 4) * 4, gz = Math.floor(wz / 4) * 4;
  let sd = 0, ss = 0, sw = 0;
  let center = "plains";
  for (let a = -2; a <= 2; a++) for (let b = -2; b <= 2; b++) {
    const sx = gx + a * 4, sz = gz + b * 4;
    const key = ((sx + 100000) * 200003 + (sz + 100000)) | 0;
    let c = cache.get(key);
    if (!c) { c = climateAt(p, sx, sz); cache.set(key, c); }
    let [d, s] = BIOME_SHAPE[c.biome] ?? [0.1, 0.1];
    if (c.river > 0) { d = d + (-0.5 - d) * c.river; s = s * (1 - c.river); }
    const wgt = 10 / Math.sqrt(a * a + b * b + 0.2);
    sd += d * wgt; ss += s * wgt; sw += wgt;
    if (a === 0 && b === 0) center = c.biome;
  }
  return [sd / sw, ss / sw, center];
}

function densityAt(p: GenParams, n: Noises, x: number, y: number, z: number, depth: number, scale: number, depthNoise: number): number {
  const A = amp(p);
  const baseH = 64 + depth * 17 * A;
  const spread = 5 + scale * 42 * A;
  let d = (baseH - y) / spread;
  const low = n.low.sample3(x, y, z, 0.6);
  const high = n.high.sample3(x, y, z, 0.6) * 1.35;
  const s = clamp(n.sel.sample3(x, y, z, 0.6) * 2.5 + 0.5, 0, 1);
  d += (low + (high - low) * s) * (0.55 + scale * 1.2) + depthNoise * 0.12;
  if (y > 236) d -= (y - 236) / 6;
  if (y < 4) d += 2;
  return d;
}

/** Estimated surface height at an arbitrary column (used to seat structures and for the world tour). */
const surfaceCache = new Map<string, number>();
export function surfaceAt(p: GenParams, wx: number, wz: number): number {
  if (p.type === "flat" || p.type === "tutorial") return 63;
  const key = `${p.seed}|${p.type}|${wx}|${wz}`;
  const hit = surfaceCache.get(key);
  if (hit !== undefined) return hit;
  if (surfaceCache.size > 20000) surfaceCache.clear();
  const v = surfaceAtUncached(p, wx, wz);
  surfaceCache.set(key, v);
  return v;
}

function surfaceAtUncached(p: GenParams, wx: number, wz: number): number {
  const n = N(p.seed);
  const cache = new Map<number, Climate>();
  const [d, s] = blendedShape(p, wx, wz, cache);
  const dn = n.depth.sample2(wx, wz);
  let prev = densityAt(p, n, wx, 248, wz, d, s, dn);
  for (let y = 244; y > 4; y -= 4) {
    const cur = densityAt(p, n, wx, y, wz, d, s, dn);
    if (cur > 0 && prev <= 0) return Math.round(y + 4 * cur / (cur - prev));
    prev = cur;
  }
  return SEA_LEVEL;
}

// ---- Writer ----------------------------------------------------------------------------------------
class ChunkWriter {
  constructor(public blocks: Uint16Array, public cx: number, public cz: number) {}
  set(lx: number, y: number, lz: number, id: number): void {
    if (lx < 0 || lx > 15 || lz < 0 || lz > 15 || y < 0 || y >= WORLD_HEIGHT) return;
    this.blocks[(y << 8) | (lz << 4) | lx] = id;
  }
  get(lx: number, y: number, lz: number): number {
    if (lx < 0 || lx > 15 || lz < 0 || lz > 15 || y < 0 || y >= WORLD_HEIGHT) return -1;
    return this.blocks[(y << 8) | (lz << 4) | lx];
  }
  wset(wx: number, y: number, wz: number, id: number): void { this.set(wx - this.cx * 16, y, wz - this.cz * 16, id); }
  wget(wx: number, y: number, wz: number): number { return this.get(wx - this.cx * 16, y, wz - this.cz * 16); }
  /** Writes only into air/plants/water (trees never clobber terrain). */
  wsoft(wx: number, y: number, wz: number, id: number): void {
    const cur = this.wget(wx, y, wz);
    if (cur === AIR || cur === BID.tall_grass || cur === BID.fern || cur === WATER) this.wset(wx, y, wz, id);
  }
}

// ---- Ores ------------------------------------------------------------------------------------------
function oreFor(s: number, wx: number, y: number, wz: number, biome: string): number {
  const vein = noise3(wx * 0.13, y * 0.13, wz * 0.13, s + 31);
  const r = hash3(wx, y, wz, s + 32);
  if (vein > 0.52 && r < 0.45) {
    const pick = hash3(wx, y, wz, s + 33);
    if (y < 16 && pick < 0.3) return BID.diamond_ore;
    if (y < 32 && pick < 0.42) return BID.gold_ore;
    if (y < 40 && pick < 0.52) return BID.lapis_ore;
    if (y < 72 && pick < 0.66) return BID.iron_ore;
    if (y < 96 && pick < 0.76) return BID.copper_ore;
    if (y < 132) return BID.coal_ore;
  }
  if (r > 0.9968 && y < 80 && (biome === "mountains" || biome === "snowy_peaks")) return BID.emerald_ore;
  return 0;
}

// ---- Trees (world coordinates; clipped to the current chunk) -------------------------------------
type R = (k: number) => number;

function leafBall(w: ChunkWriter, x: number, y: number, z: number, r: number, leaf: number, rnd: R, k = 0): void {
  const ri = Math.ceil(r);
  for (let dx = -ri; dx <= ri; dx++) for (let dy = -ri; dy <= ri; dy++) for (let dz = -ri; dz <= ri; dz++) {
    const d = Math.sqrt(dx * dx + dy * dy * 1.4 + dz * dz);
    if (d > r) continue;
    if (d > r - 0.8 && rnd(k + dx * 13 + dy * 7 + dz * 3) < 0.35) continue;
    w.wsoft(x + dx, y + dy, z + dz, leaf);
  }
}

function placeTree(w: ChunkWriter, kind: string, x: number, y: number, z: number, seed: number): void {
  const rnd: R = (k) => hash2(x * 7 + k, z * 13 - k, seed + 100);
  if (kind === "mixed") {
    const r = rnd(1);
    kind = r < 0.55 ? "oak" : r < 0.8 ? "birch" : "big_oak";
  }
  switch (kind) {
    case "oak":
    case "cherry": {
      const log = kind === "oak" ? BID.oak_log : BID.cherry_log;
      const leaf = kind === "oak" ? BID.oak_leaves : BID.cherry_leaves;
      const h = 4 + Math.floor(rnd(2) * 3);
      for (let i = 0; i < h; i++) w.wset(x, y + i, z, log);
      leafBall(w, x, y + h - 1, z, kind === "cherry" ? 3.4 : 2.6, leaf, rnd);
      return;
    }
    case "big_oak": {
      const h = 7 + Math.floor(rnd(3) * 4);
      for (let i = 0; i < h; i++) w.wset(x, y + i, z, BID.oak_log);
      const branches = 2 + Math.floor(rnd(4) * 3);
      for (let b = 0; b < branches; b++) {
        const ang = rnd(10 + b) * Math.PI * 2;
        const by = y + Math.floor(h * 0.55) + Math.floor(rnd(20 + b) * (h * 0.4));
        const len = 2 + Math.floor(rnd(30 + b) * 3);
        let bx = x, bz = z;
        for (let s = 1; s <= len; s++) {
          bx = x + Math.round(Math.cos(ang) * s);
          bz = z + Math.round(Math.sin(ang) * s);
          w.wset(bx, by + Math.floor(s / 2), bz, BID.oak_log);
        }
        leafBall(w, bx, by + Math.floor(len / 2) + 1, bz, 2.8, BID.oak_leaves, rnd, b * 31);
      }
      leafBall(w, x, y + h, z, 3.3, BID.oak_leaves, rnd, 99);
      return;
    }
    case "birch":
    case "tall_birch": {
      const h = kind === "tall_birch" ? 8 + Math.floor(rnd(5) * 4) : 5 + Math.floor(rnd(5) * 3);
      for (let i = 0; i < h; i++) w.wset(x, y + i, z, BID.birch_log);
      leafBall(w, x, y + h - 1, z, 2.3, BID.birch_leaves, rnd);
      leafBall(w, x, y + h - 3, z, 2.0, BID.birch_leaves, rnd, 50);
      return;
    }
    case "spruce": {
      const h = 7 + Math.floor(rnd(6) * 5);
      for (let i = 0; i < h; i++) w.wset(x, y + i, z, BID.spruce_log);
      for (let i = 2; i <= h; i++) {
        const fromTop = h - i;
        const r = fromTop % 3 === 0 ? Math.min(3, 1 + Math.floor(fromTop / 3)) : Math.max(1, Math.min(2, Math.floor(fromTop / 3)));
        for (let dx = -r; dx <= r; dx++) for (let dz = -r; dz <= r; dz++) {
          if (dx * dx + dz * dz > r * r + 0.5 || (dx === 0 && dz === 0)) continue;
          w.wsoft(x + dx, y + i, z + dz, BID.spruce_leaves);
        }
      }
      w.wsoft(x, y + h, z, BID.spruce_leaves);
      w.wsoft(x, y + h + 1, z, BID.spruce_leaves);
      return;
    }
    case "mega_spruce": {
      const h = 16 + Math.floor(rnd(7) * 10);
      for (let i = 0; i < h; i++) for (const [ox, oz] of [[0, 0], [1, 0], [0, 1], [1, 1]]) w.wset(x + ox, y + i, z + oz, BID.spruce_log);
      for (let i = Math.floor(h * 0.45); i <= h + 1; i++) {
        const fromTop = h + 1 - i;
        const r = Math.min(5, 1 + fromTop * 0.32 + (fromTop % 3 === 0 ? 1 : 0));
        const ri = Math.ceil(r);
        for (let dx = -ri; dx <= ri + 1; dx++) for (let dz = -ri; dz <= ri + 1; dz++) {
          const ddx = dx - 0.5, ddz = dz - 0.5;
          if (ddx * ddx + ddz * ddz > r * r) continue;
          w.wsoft(x + dx, y + i, z + dz, BID.spruce_leaves);
        }
      }
      return;
    }
    case "jungle": {
      if (rnd(8) < 0.25) {
        const h = 16 + Math.floor(rnd(9) * 8);
        for (let i = 0; i < h; i++) for (const [ox, oz] of [[0, 0], [1, 0], [0, 1], [1, 1]]) w.wset(x + ox, y + i, z + oz, BID.jungle_log);
        leafBall(w, x, y + h, z, 5, BID.jungle_leaves, rnd);
        leafBall(w, x + 4, y + h - 5, z - 2, 2.6, BID.jungle_leaves, rnd, 7);
        leafBall(w, x - 3, y + h - 8, z + 3, 2.6, BID.jungle_leaves, rnd, 9);
      } else {
        const h = 6 + Math.floor(rnd(9) * 5);
        for (let i = 0; i < h; i++) w.wset(x, y + i, z, BID.jungle_log);
        leafBall(w, x, y + h - 1, z, 3, BID.jungle_leaves, rnd);
      }
      return;
    }
    case "acacia": {
      const h = 4 + Math.floor(rnd(10) * 2);
      for (let i = 0; i < h; i++) w.wset(x, y + i, z, BID.oak_log);
      const dir = rnd(11) < 0.5 ? 1 : -1;
      let tx = x, ty = y + h;
      for (let s = 0; s < 3; s++) { tx += dir; w.wset(tx, ty, z, BID.oak_log); ty++; }
      for (let dx = -3; dx <= 3; dx++) for (let dz = -3; dz <= 3; dz++) if (Math.abs(dx) + Math.abs(dz) <= 4) w.wsoft(tx + dx, ty, z + dz, BID.oak_leaves);
      for (let dx = -2; dx <= 2; dx++) for (let dz = -2; dz <= 2; dz++) if (Math.abs(dx) + Math.abs(dz) <= 2) w.wsoft(tx + dx, ty + 1, z + dz, BID.oak_leaves);
      return;
    }
    case "dead": {
      const h = 3 + Math.floor(rnd(12) * 3);
      for (let i = 0; i < h; i++) w.wset(x, y + i, z, BID.dead_log);
      w.wset(x + 1, y + h - 1, z, BID.dead_log);
      w.wset(x - 1, y + h - 2, z, BID.dead_log);
      return;
    }
    case "mushroom": {
      const h = 5 + Math.floor(rnd(13) * 4);
      for (let i = 0; i < h; i++) w.wset(x, y + i, z, BID.mushroom_stem);
      for (let dx = -3; dx <= 3; dx++) for (let dz = -3; dz <= 3; dz++) {
        const d = dx * dx + dz * dz;
        if (d > 11) continue;
        w.wsoft(x + dx, y + h, z + dz, BID.red_mushroom_block);
        if (d < 6) w.wsoft(x + dx, y + h + 1, z + dz, BID.red_mushroom_block);
      }
      return;
    }
    case "cactus": {
      const h = 1 + Math.floor(rnd(14) * 3);
      for (let i = 0; i < h; i++) w.wset(x, y + i, z, BID.cactus);
      return;
    }
    case "palm": {
      const h = 5 + Math.floor(rnd(15) * 3);
      for (let i = 0; i < h; i++) w.wset(x + (i > h - 3 ? 1 : 0), y + i, z, BID.jungle_log);
      for (let dx = -3; dx <= 3; dx++) for (let dz = -3; dz <= 3; dz++) if (dx === 0 || dz === 0 || Math.abs(dx) === Math.abs(dz)) w.wsoft(x + 1 + dx, y + h - (Math.max(Math.abs(dx), Math.abs(dz)) > 2 ? 1 : 0), z + dz, BID.jungle_leaves);
      return;
    }
    case "bush": {
      w.wset(x, y, z, BID.oak_log);
      leafBall(w, x, y, z, 1.7, BID.oak_leaves, rnd);
      return;
    }
    default:
      return;
  }
}

// ---- Structures ----------------------------------------------------------------------------------
/** Stamps a shape function over the part of a structure that overlaps this chunk.
 *  shape(dx,dy,dz) returns a block id, 0 for air, or -1 to leave terrain untouched. */
function stamp(w: ChunkWriter, ox: number, oy: number, oz: number, radius: number, dyMin: number, dyMax: number, shape: (dx: number, dy: number, dz: number) => number): void {
  const x0 = w.cx * 16, z0 = w.cz * 16;
  if (ox + radius < x0 || ox - radius > x0 + 15 || oz + radius < z0 || oz - radius > z0 + 15) return;
  for (let lz = 0; lz < 16; lz++) for (let lx = 0; lx < 16; lx++) {
    const dx = x0 + lx - ox, dz = z0 + lz - oz;
    if (Math.abs(dx) > radius || Math.abs(dz) > radius) continue;
    for (let dy = dyMin; dy <= dyMax; dy++) {
      const y = oy + dy;
      if (y < 1 || y >= WORLD_HEIGHT) continue;
      const id = shape(dx, dy, dz);
      if (id >= 0) w.set(lx, y, lz, id);
    }
  }
}

const LAMPS = () => [BID.lamp_red, BID.lamp_blue, BID.lamp_green, BID.lamp_gold, BID.lamp_purple];

/** Giant desert pyramid: grand hall with coloured lamp pillars, descending stair, tomb chamber with sarcophagi. */
function giantPyramid(seed: number, ox: number, oz: number) {
  const half = 30;
  const lamps = LAMPS();
  return (dx: number, dy: number, dz: number): number => {
    const ax = Math.abs(dx), az = Math.abs(dz), m = Math.max(ax, az);
    const quadLamp = lamps[((dx > 0 ? 1 : 0) + (dz > 0 ? 2 : 0)) % lamps.length];
    // descending stair from the hall (dz = 1..11)
    if (ax <= 1 && dz >= 1 && dz <= 11) {
      const k = dz;
      if (dy === -k) return BID.sandstone;
      if (dy > -k && dy <= -k + 3) return AIR;
    }
    if (dy >= 0) {
      const L = dy, r = half - L;
      if (r < 0 || m > r) return -1;
      if (r <= 1) return BID.gold_block;
      if (dz < 0 && ax <= 1 && L >= 1 && L <= 3 && az > 12) return AIR; // entrance tunnel
      if (dz < 0 && ax <= 2 && L >= 1 && L <= 5 && az === r) return AIR; // entrance arch
      if (ax <= 12 && az <= 12 && L <= 11) {
        if (L === 0) {
          if (ax <= 1 && az <= 1) return BID.lamp_gold;
          return (ax + az) % 4 === 0 ? BID.terracotta : BID.chiseled_sandstone;
        }
        if (L === 11) return (ax % 4 === 0 && az % 4 === 0) ? BID.lamp_gold : BID.sandstone;
        if (ax >= 7 && ax <= 8 && az >= 7 && az <= 8) return (L === 4 || L === 8) ? quadLamp : BID.chiseled_sandstone;
        if ((ax === 12 || az === 12) && L === 3 && (ax + az) % 4 === 0) return quadLamp;
        if (L === 1 && ax === 10 && az === 10) return BID.chest;
        if (L === 1 && ax <= 1 && az === 5 && dz < 0) return BID.tomb_block;
        if (L >= 9 && (ax === 11 || az === 11) && hash3(dx, dy, dz, seed + 5) < 0.12) return BID.cobweb;
        return AIR;
      }
      if (L % 6 === 5) return BID.chiseled_sandstone;
      return (hash3(dx, dy, dz, seed + 6) < 0.08) ? BID.sand : BID.sandstone;
    }
    // below ground: tomb chamber
    if (ax <= 10 && az <= 10 && dy >= -14 && dy <= -9) {
      if (dy === -14) return (ax + az) % 3 === 0 ? BID.blackstone : BID.chiseled_sandstone;
      if (dy === -9) return (ax % 4 === 0 && az % 4 === 0) ? BID.lamp_purple : BID.sandstone;
      if (ax === 10 || az === 10) return dy === -11 && (ax + az) % 3 === 0 ? lamps[(ax + az) % lamps.length] : BID.sandstone;
      if (dy === -13) {
        if (dz === 0 && ((dx >= 2 && dx <= 3) || (dx <= -2 && dx >= -3))) return BID.tomb_block;
        if (ax === 8 && az === 8) return BID.gold_block;
        if (dx === 0 && az === 6) return BID.chest;
      }
      if (ax === 5 && az === 5) return dy === -12 ? quadLamp : BID.chiseled_sandstone;
      return AIR;
    }
    if (dy >= -8 && dy < 0 && m <= half) return BID.sandstone; // foundation
    void ox; void oz;
    return -1;
  };
}

/** Obsidian mansion: three floors, blackstone frame, lamp-lit rooms, roof. */
function obsidianMansion(seed: number) {
  return (dx: number, dy: number, dz: number): number => {
    const ax = Math.abs(dx), az = Math.abs(dz);
    if (ax > 15 || az > 11) return -1;
    if (dy < 0) return dy >= -6 && ax <= 14 && az <= 10 ? BID.blackstone : -1;
    if (dy >= 18) {
      const i = dy - 18;
      if (ax <= 15 - i && az <= 11 - i) return i >= 5 ? BID.blackstone : (ax === 15 - i || az === 11 - i) ? BID.obsidian : AIR;
      return -1;
    }
    if (ax > 14 || az > 10) return -1;
    const floor = dy % 6 === 0;
    const wall = ax === 14 || az === 10;
    const corner = ax === 14 && az === 10;
    if (floor) return wall ? BID.blackstone : (ax % 5 === 0 && az % 5 === 0 && dy > 0 ? BID.lamp_purple : (ax <= 3 && az <= 6 ? BID.wool_red : BID.spruce_planks));
    if (corner) return BID.blackstone;
    if (wall) {
      if (dz < 0 && az === 10 && ax <= 1 && dy >= 1 && dy <= 3) return AIR; // front door
      const ly = dy % 6;
      if ((ly === 2 || ly === 3) && ((ax % 4 === 2 && az === 10) || (az % 4 === 2 && ax === 14))) return BID.glass;
      return BID.obsidian;
    }
    // interior partitions with doorways
    if ((dx === 0 && az !== 0 && az !== 1) || (dz === 0 && ax > 2 && ax !== 7 && ax !== 8)) {
      const ly = dy % 6;
      if (ly >= 1 && ly <= 3 && (az === 4 || ax === 7 || ax === 8)) return AIR;
      return BID.obsidian;
    }
    const ly = dy % 6;
    if (ly === 1 && ax === 13 && az % 3 === 0) return BID.bookshelf;
    if (ly === 2 && ax === 13 && az % 3 === 0) return BID.bookshelf;
    if (ly === 1 && ax === 12 && az === 8 && hash3(dx, dy, dz, seed + 9) < 0.7) return BID.chest;
    if (ly === 1 && ax === 4 && az === 8) return BID.lantern;
    if (ly === 5 && hash3(dx, dy, dz, seed + 10) < 0.02) return BID.cobweb;
    return AIR;
  };
}

/** Volcano: cone of basalt/stone with a magma crust, crater lava lake and a lava conduit. */
export const VOLCANO_RADIUS = 46;
export const VOLCANO_HEIGHT = 58;
function volcano(seed: number) {
  return (dx: number, dy: number, dz: number): number => {
    const d = Math.sqrt(dx * dx + dz * dz);
    if (d > VOLCANO_RADIUS) return -1;
    const H = VOLCANO_HEIGHT;
    let hc = H * Math.pow(1 - d / VOLCANO_RADIUS, 1.25) + noise2(dx * 0.15, dz * 0.15, seed + 3) * 2;
    if (d < 8) hc = H - 10 + (d / 8) * 6;
    if (dy < 0) return dy >= -6 ? BID.basalt : -1;
    if (d < 2.2 && dy <= H - 10) return LAVA; // conduit
    if (d < 8 && dy > hc) return dy <= H - 9 ? LAVA : -1;
    if (dy > hc) return -1;
    if (hc - dy < 1.5) return hash3(dx, dy, dz, seed + 4) < 0.25 ? BID.magma : BID.basalt;
    return hash3(dx, dy, dz, seed + 5) < 0.4 ? BID.blackstone : BID.stone;
  };
}

/** Giant fossil: buried spine with ribs and a skull (desert / badlands). */
function fossil(seed: number) {
  return (dx: number, dy: number, dz: number): number => {
    if (Math.abs(dx) > 19 || Math.abs(dz) > 8) return -1;
    if (dx >= 15 && dx <= 19 && dy >= 2 && dy <= 6 && Math.abs(dz) <= 2) {
      if ((dx === 17 && Math.abs(dz) === 1 && dy === 5) || (dy === 2 && dx > 16)) return AIR;
      return BID.bone_block;
    }
    if (dx > 15) return -1;
    if (dy === 7 && Math.abs(dz) <= 0) return BID.bone_block; // spine
    if (dx % 3 === 0 && dx >= -14 && dx <= 12) {
      const rr = Math.sqrt(dz * dz + (dy - 2) * (dy - 2) * 0.9);
      if (Math.abs(rr - 5) < 0.6 && dy >= -3 && dy <= 7) return hash3(dx, dy, dz, seed + 7) < 0.1 ? -1 : BID.bone_block;
    }
    return -1;
  };
}

function buildHouse(w: ChunkWriter, bx: number, base: number, bz: number, wood: number, spawns: SpawnRec[]): void {
  const W = 7, D = 6;
  const ox = bx - 3, oz = bz - 3;
  for (let x = 0; x < W; x++) for (let z = 0; z < D; z++) {
    w.wset(ox + x, base, oz + z, BID.oak_planks);
    for (let y = base - 1; y > base - 7; y--) {
      const cur = w.wget(ox + x, y, oz + z);
      if (cur === AIR || cur === WATER || cur === BID.tall_grass) w.wset(ox + x, y, oz + z, BID.cobblestone);
    }
  }
  for (let y = base + 1; y <= base + 3; y++) for (let x = 0; x < W; x++) for (let z = 0; z < D; z++) {
    const edge = x === 0 || x === W - 1 || z === 0 || z === D - 1;
    if (!edge) { w.wset(ox + x, y, oz + z, AIR); continue; }
    const corner = (x === 0 || x === W - 1) && (z === 0 || z === D - 1);
    let id = corner ? BID.oak_log : wood;
    if (y === base + 2 && (z === 0 || z === D - 1) && (x === 1 || x === 5)) id = BID.glass;
    if (y === base + 2 && x === 0 && z === 2) id = BID.glass;
    if (z === 0 && x === 3 && y <= base + 2) id = AIR;
    w.wset(ox + x, y, oz + z, id);
  }
  for (let layer = 0; layer < 4; layer++) {
    const y = base + 4 + layer;
    for (let x = -1 + layer; x <= W - layer; x++) for (let z = -1; z <= D; z++) w.wset(ox + x, y, oz + z, layer === 3 ? BID.oak_log : BID.spruce_planks);
  }
  for (let x = 0; x < W; x++) for (let z = 0; z < D; z++) for (let y = base + 4; y <= base + 6; y++) {
    if (x >= 1 + (y - base - 4) && x <= W - 2 - (y - base - 4) && z >= 1 && z <= D - 2) w.wset(ox + x, y, oz + z, AIR);
  }
  w.wset(ox + 1, base + 1, oz + 4, BID.crafting_table);
  w.wset(ox + 5, base + 1, oz + 4, BID.chest);
  w.wset(ox + 5, base + 1, oz + 1, BID.bed_block);
  w.wset(ox + 1, base + 3, oz + 1, BID.lantern);
  const vx = ox + 3, vz = oz + 3;
  if (vx - w.cx * 16 >= 0 && vx - w.cx * 16 < 16 && vz - w.cz * 16 >= 0 && vz - w.cz * 16 < 16) {
    spawns.push({ kind: "villager", x: vx + 0.5, y: base + 1, z: vz + 0.5 });
  }
}

function lampPost(w: ChunkWriter, x: number, y: number, z: number): void {
  w.wset(x, y + 1, z, BID.lantern_post);
  w.wset(x, y + 2, z, BID.lantern_post);
  w.wset(x, y + 3, z, BID.lantern);
}

function buildVillage(w: ChunkWriter, p: GenParams, vx: number, vz: number, biome: Biome, spawns: SpawnRec[]): void {
  const wood = biome.snowy ? BID.spruce_planks : biome.id === "desert" || biome.id === "savanna" ? BID.sandstone : BID.oak_planks;
  const houses: [number, number][] = [[-14, -9], [9, -10], [-6, 10], [12, 9], [-18, 6], [20, -2], [2, -20], [-2, 22]];
  const vh = surfaceAt(p, vx, vz);
  for (let x = -24; x <= 24; x++) for (const dz of [0, 1]) {
    const h = surfaceAt(p, vx + x, vz + dz);
    if (Math.abs(h - vh) < 5) w.wset(vx + x, h, vz + dz, BID.gravel);
  }
  for (let z = -24; z <= 24; z++) {
    const h = surfaceAt(p, vx, vz + z);
    if (Math.abs(h - vh) < 5) w.wset(vx, h, vz + z, BID.gravel);
  }
  for (const [dx, dz] of houses) {
    const hx = vx + dx, hz = vz + dz;
    const hb = surfaceAt(p, hx, hz);
    if (hb < SEA_LEVEL || Math.abs(hb - vh) > 8) continue;
    buildHouse(w, hx, hb, hz, wood, spawns);
  }
  for (let x = -2; x <= 2; x++) for (let z = -2; z <= 2; z++) {
    const edge = Math.abs(x) === 2 || Math.abs(z) === 2;
    w.wset(vx + 4 + x, vh, vz + 4 + z, edge ? BID.stone_bricks : WATER);
    if (!edge) w.wset(vx + 4 + x, vh - 1, vz + 4 + z, WATER);
    if (edge) w.wset(vx + 4 + x, vh + 1, vz + 4 + z, BID.stone_bricks);
  }
  for (const [lx, lz] of [[-4, 3], [4, -3], [3, 9], [-9, -3], [10, 3]]) lampPost(w, vx + lx, surfaceAt(p, vx + lx, vz + lz), vz + lz);
  for (let x = 0; x < 6; x++) for (let z = 0; z < 4; z++) w.wset(vx - 10 + x, vh, vz + 14 + z, BID.hay_bale);
}

function buildRuin(w: ChunkWriter, rx: number, base: number, rz: number, seed: number): void {
  for (const [dx, dz] of [[-3, -3], [3, -3], [-3, 3], [3, 3]]) {
    const hgt = 3 + Math.floor(hash2(rx + dx, rz + dz, seed + 77) * 5);
    for (let y = base + 1; y <= base + hgt; y++) w.wset(rx + dx, y, rz + dz, hash2(rx + dx, y, seed + 9) < 0.3 ? BID.cobble_wall : BID.stone_bricks);
  }
  w.wset(rx, base + 1, rz, BID.chest);
}

function buildWatchtower(w: ChunkWriter, x: number, base: number, z: number): void {
  for (let y = base; y <= base + 14; y++) for (let dx = -2; dx <= 2; dx++) for (let dz = -2; dz <= 2; dz++) {
    const edge = Math.abs(dx) === 2 || Math.abs(dz) === 2;
    if (edge) w.wset(x + dx, y, z + dz, (y - base) % 4 === 3 && (dx === 0 || dz === 0) ? AIR : BID.stone_bricks);
    else w.wset(x + dx, y, z + dz, y === base ? BID.cobblestone : AIR);
  }
  for (let dx = -3; dx <= 3; dx++) for (let dz = -3; dz <= 3; dz++) w.wset(x + dx, base + 15, z + dz, BID.spruce_planks);
  w.wset(x, base + 16, z, BID.lantern);
}

function buildBalloon(w: ChunkWriter, bx: number, y0: number, bz: number, seed: number): void {
  const wools = [BID.wool_red, BID.wool_blue, BID.wool_yellow, BID.wool_green, BID.wool_white];
  const wool = wools[Math.floor(hash2(bx, bz, seed + 300) * wools.length)];
  const stripe = wools[Math.floor(hash2(bz, bx, seed + 301) * wools.length)];
  for (let dy = 0; dy <= 6; dy++) for (let dx = -6; dx <= 6; dx++) for (let dz = -6; dz <= 6; dz++) {
    const d = Math.sqrt(dx * dx + dz * dz + (dy - 2) * (dy - 2) * 0.8);
    if (d > 6 || d < 4.8) continue;
    w.wset(bx + dx, y0 + dy, bz + dz, (dx + dz + 20) % 4 === 0 ? stripe : wool);
  }
  for (let dx = -1; dx <= 1; dx++) for (let dz = -1; dz <= 1; dz++) w.wset(bx + dx, y0 - 6, bz + dz, BID.oak_planks);
  for (const [dx, dz] of [[-1, -1], [1, 1], [-1, 1], [1, -1]]) for (let y = y0 - 5; y <= y0 - 1; y++) w.wset(bx + dx, y, bz + dz, BID.oak_log);
}

interface StructSite {
  kind: string;
  x: number;
  z: number;
  radius: number;
}

const BIG_REGION = 448;
const SMALL_REGION = 144;
const VILLAGE_REGION = 320;

function bigSiteIn(p: GenParams, rx: number, rz: number): StructSite | null {
  const s = p.seed;
  if (hash2(rx, rz, s + 700) > 0.55) return null;
  const x = rx * BIG_REGION + 70 + Math.floor(hash2(rx, rz, s + 701) * (BIG_REGION - 140));
  const z = rz * BIG_REGION + 70 + Math.floor(hash2(rx, rz, s + 702) * (BIG_REGION - 140));
  const c = climateAt(p, x, z);
  if (c.cont < -0.08 || c.river > 0.2) return null;
  const b = BIOME_BY_ID[c.biome];
  if (!b) return null;
  if (b.structures.includes("giant_pyramid")) return { kind: "giant_pyramid", x, z, radius: 31 };
  if (b.structures.includes("volcano")) return { kind: "volcano", x, z, radius: VOLCANO_RADIUS };
  if (b.structures.includes("mansion")) return { kind: "mansion", x, z, radius: 16 };
  return null;
}

function smallSiteIn(p: GenParams, rx: number, rz: number): StructSite | null {
  const s = p.seed;
  if (hash2(rx, rz, s + 720) > 0.22) return null;
  const x = rx * SMALL_REGION + 20 + Math.floor(hash2(rx, rz, s + 721) * (SMALL_REGION - 40));
  const z = rz * SMALL_REGION + 20 + Math.floor(hash2(rx, rz, s + 722) * (SMALL_REGION - 40));
  const c = climateAt(p, x, z);
  if (c.cont < -0.08 || c.river > 0.2) return null;
  const b = BIOME_BY_ID[c.biome];
  if (!b) return null;
  const roll = hash2(rx, rz, s + 723);
  if (b.structures.includes("fossil") && roll < 0.5) return { kind: "fossil", x, z, radius: 20 };
  if (b.structures.includes("balloon") && roll < 0.3) return { kind: "balloon", x, z, radius: 7 };
  if (roll < 0.55 && b.trees !== "none") return { kind: "watchtower", x, z, radius: 4 };
  if (b.structures.includes("ruin")) return { kind: "ruin", x, z, radius: 4 };
  return null;
}

function villageSiteIn(p: GenParams, rx: number, rz: number): StructSite | null {
  const s = p.seed;
  if (hash2(rx, rz, s + 740) > 0.45) return null;
  const x = rx * VILLAGE_REGION + 60 + Math.floor(hash2(rx, rz, s + 741) * (VILLAGE_REGION - 120));
  const z = rz * VILLAGE_REGION + 60 + Math.floor(hash2(rx, rz, s + 742) * (VILLAGE_REGION - 120));
  const c = climateAt(p, x, z);
  if (c.cont < -0.05 || c.river > 0.1) return null;
  const b = BIOME_BY_ID[c.biome];
  if (!b || !b.structures.includes("village")) return null;
  return { kind: "village", x, z, radius: 30 };
}

function sitesNear(p: GenParams, x0: number, z0: number, x1: number, z1: number): StructSite[] {
  const out: StructSite[] = [];
  const scan = (region: number, fn: (rx: number, rz: number) => StructSite | null, margin: number) => {
    for (let rx = Math.floor((x0 - margin) / region); rx <= Math.floor((x1 + margin) / region); rx++)
      for (let rz = Math.floor((z0 - margin) / region); rz <= Math.floor((z1 + margin) / region); rz++) {
        const site = fn(rx, rz);
        if (site && site.x + site.radius >= x0 && site.x - site.radius <= x1 && site.z + site.radius >= z0 && site.z - site.radius <= z1) out.push(site);
      }
  };
  scan(BIG_REGION, (rx, rz) => bigSiteIn(p, rx, rz), 60);
  scan(SMALL_REGION, (rx, rz) => smallSiteIn(p, rx, rz), 24);
  scan(VILLAGE_REGION, (rx, rz) => villageSiteIn(p, rx, rz), 40);
  return out;
}

/** Volcano craters near a point (used by the game to schedule rare eruptions). */
export function volcanoesNear(p: GenParams, x: number, z: number, range: number): { x: number; y: number; z: number }[] {
  if (p.dim !== "overworld" || p.type === "flat" || p.type === "tutorial") return [];
  return sitesNear(p, x - range, z - range, x + range, z + range)
    .filter((s) => s.kind === "volcano")
    .map((s) => ({ x: s.x, y: surfaceAt(p, s.x, s.z) + VOLCANO_HEIGHT - 9, z: s.z }));
}

/** Points of interest for the World Tour: one location per distinct biome (and big structures) near spawn. */
export function tourStops(p: GenParams, maxStops = 10): { x: number; z: number; y: number; label: string }[] {
  const stops: { x: number; z: number; y: number; label: string }[] = [];
  const seen = new Set<string>();
  if (p.type === "tutorial" || p.type === "flat") {
    return [
      { x: 0, z: 0, y: 64, label: "Town Square" },
      { x: 26, z: 14, y: 64, label: "Village Houses" },
      { x: -40, z: -40, y: 64, label: "Little Pyramid" },
      { x: 20, z: -22, y: 64, label: "Portal Frame" },
    ];
  }
  for (let r = 0; r <= 3200 && stops.length < maxStops; r += 160) {
    const steps = Math.max(1, Math.floor((2 * Math.PI * r) / 160));
    for (let i = 0; i < steps && stops.length < maxStops; i++) {
      const a = (i / steps) * Math.PI * 2;
      const x = Math.round(Math.cos(a) * r), z = Math.round(Math.sin(a) * r);
      const c = climateAt(p, x, z);
      if (seen.has(c.biome) || c.biome === "deep_ocean" || c.biome === "river") continue;
      seen.add(c.biome);
      stops.push({ x, z, y: surfaceAt(p, x, z), label: BIOME_BY_ID[c.biome]?.name ?? c.biome });
    }
  }
  const sites = sitesNear(p, -1500, -1500, 1500, 1500).filter((s) => s.kind === "giant_pyramid" || s.kind === "volcano" || s.kind === "mansion" || s.kind === "village").slice(0, 4);
  for (const s of sites) stops.push({ x: s.x, z: s.z, y: surfaceAt(p, s.x, s.z), label: s.kind === "giant_pyramid" ? "Giant Pyramid" : s.kind === "volcano" ? "Volcano" : s.kind === "mansion" ? "Obsidian Mansion" : "Village" });
  return stops;
}

// ---- Overworld ----------------------------------------------------------------------------------
const CG = 9; // coarse columns per axis covering -8..24
const CY = 33; // coarse y samples (every 8 blocks)
const PADW = 32; // padded heightmap width (-8..23)

function genOverworld(p: GenParams, cx: number, cz: number): GenResult {
  if (p.type === "flat" || p.type === "tutorial") return genFlat(p, cx, cz);
  const blocks = new Uint16Array(CHUNK_VOLUME);
  const w = new ChunkWriter(blocks, cx, cz);
  const s = p.seed;
  const n = N(s);
  const spawns: SpawnRec[] = [];
  const cache = new Map<number, Climate>();
  const bx = cx * 16 - 8, bz = cz * 16 - 8;

  // 1) coarse density grid (with biome-blended depth/scale)
  const D = new Float32Array(CG * CG * CY);
  for (let i = 0; i < CG; i++) for (let k = 0; k < CG; k++) {
    const wx = bx + i * 4, wz = bz + k * 4;
    const [dep, sc] = blendedShape(p, wx, wz, cache);
    const dn = n.depth.sample2(wx, wz);
    for (let j = 0; j < CY; j++) D[(i * CG + k) * CY + j] = densityAt(p, n, wx, j * 8, wz, dep, sc, dn);
  }
  const dAt = (px: number, pz: number, j: number): number => {
    const i = Math.min(CG - 2, px >> 2), k = Math.min(CG - 2, pz >> 2);
    const fx = (px - i * 4) / 4, fz = (pz - k * 4) / 4;
    const a = D[(i * CG + k) * CY + j], b = D[((i + 1) * CG + k) * CY + j];
    const c = D[(i * CG + k + 1) * CY + j], d = D[((i + 1) * CG + k + 1) * CY + j];
    return (a + (b - a) * fx) + ((c + (d - c) * fx) - (a + (b - a) * fx)) * fz;
  };

  // 2) padded heightmap + biome per column (for trees that cross chunk borders)
  const padH = new Int16Array(PADW * PADW);
  const padBiome: Biome[] = new Array(PADW * PADW);
  for (let pz = 0; pz < PADW; pz++) for (let px = 0; px < PADW; px++) {
    let h = 0;
    for (let j = CY - 2; j >= 0; j--) {
      const d0 = dAt(px, pz, j), d1 = dAt(px, pz, j + 1);
      if (d0 > 0 && d1 <= 0) { h = Math.floor(j * 8 + 8 * d0 / (d0 - d1)); break; }
    }
    padH[pz * PADW + px] = h;
    const c = climateAt(p, bx + px, bz + pz);
    padBiome[pz * PADW + px] = BIOME_BY_ID[c.biome] ?? BIOME_BY_ID.plains;
  }

  // 3) fill terrain from interpolated density
  for (let lz = 0; lz < 16; lz++) for (let lx = 0; lx < 16; lx++) {
    const px = lx + 8, pz = lz + 8;
    for (let j = 0; j < CY - 1; j++) {
      const d0 = dAt(px, pz, j), d1 = dAt(px, pz, j + 1);
      if (d0 <= 0 && d1 <= 0) continue;
      for (let t = 0; t < 8; t++) {
        const y = j * 8 + t;
        if (d0 + (d1 - d0) * (t / 8) > 0) blocks[(y << 8) | (lz << 4) | lx] = STONE;
      }
    }
  }

  // 4) surface layers, bedrock, deepslate, ores, water
  const colH = new Int16Array(256);
  for (let lz = 0; lz < 16; lz++) for (let lx = 0; lx < 16; lx++) {
    const wx = cx * 16 + lx, wz = cz * 16 + lz;
    const biome = padBiome[(lz + 8) * PADW + lx + 8];
    const fillDepth = 3 + Math.floor((n.fill.sample2(wx, wz) + 1) * 1.5);
    let depthCount = -1;
    let top = -1;
    for (let y = WORLD_HEIGHT - 1; y >= 0; y--) {
      const idx = (y << 8) | (lz << 4) | lx;
      if (y === 0 || (y < 4 && hash3(wx, y, wz, s + 90) < 0.5)) { blocks[idx] = BEDROCK; continue; }
      if (blocks[idx] !== STONE) { depthCount = -1; continue; }
      depthCount++;
      if (depthCount === 0 && top < 0) top = y;
      let id = STONE;
      const under = y < SEA_LEVEL - 1;
      if (depthCount === 0) {
        if (under) id = biome.id === "deep_ocean" ? BID.gravel : biome.id === "swamp" ? BID.mud : (hash2(wx, wz, s + 91) < 0.12 ? BID.clay : BID.sand);
        else if (y > 150 && biome.id === "mountains") id = BID.snow_block;
        else if (y > 128 && biome.id === "snowy_peaks") id = BID.snow_block;
        else if (biome.id === "beach" || (biome.id === "river" && y <= SEA_LEVEL + 1)) id = BID.sand;
        else id = B(biome.top);
      } else if (depthCount < fillDepth) {
        if (under) id = BID.sand;
        else if (biome.id === "badlands") {
          const band = Math.floor(y + n.band.sample2(wx, wz) * 4) % 5;
          id = band === 0 ? BID.red_sand : band === 2 ? BID.sandstone : BID.terracotta;
        } else id = B(biome.under);
      } else {
        if (y < 10) id = DEEPSLATE;
        else if (y < 20 && hash3(wx, y, wz, s + 92) < (20 - y) / 10) id = DEEPSLATE;
        const o = oreFor(s, wx, y, wz, biome.id);
        if (o) id = o;
      }
      blocks[idx] = id;
    }
    colH[lz * 16 + lx] = top < 0 ? 0 : top;
    // badlands hoodoo pillars
    if (biome.id === "badlands" && n.pillar.sample2(wx, wz) > 0.55 && top > SEA_LEVEL) {
      const ph = Math.floor((n.pillar.sample2(wx, wz) - 0.55) * 60);
      for (let y = top + 1; y <= top + ph && y < 250; y++) blocks[(y << 8) | (lz << 4) | lx] = y % 3 === 0 ? BID.red_sand : BID.terracotta;
    }
    // water / ice
    for (let y = Math.max(1, top + 1); y <= SEA_LEVEL; y++) {
      const idx = (y << 8) | (lz << 4) | lx;
      if (blocks[idx] !== AIR) continue;
      blocks[idx] = biome.water === "toxic_water" ? TOXIC : (y === SEA_LEVEL && (biome.snowy || biome.id === "snowy_plains") ? ICE : WATER);
    }
  }

  // 5) caves: cheese caverns + spaghetti tunnels; crystal caves in rare regions
  for (let lz = 0; lz < 16; lz++) for (let lx = 0; lx < 16; lx++) {
    const wx = cx * 16 + lx, wz = cz * 16 + lz;
    const h = colH[lz * 16 + lx];
    const crystal = n.crystal.sample2(wx, wz) > 0.5;
    const wet = h < SEA_LEVEL + 2;
    const maxY = wet ? h - 8 : h + 1;
    for (let y = 4; y < maxY && y < 200; y++) {
      const idx = (y << 8) | (lz << 4) | lx;
      const id = blocks[idx];
      if (id === AIR || id === WATER || id === BEDROCK || id === ICE) continue;
      let carve = false;
      if (y < h - 5) {
        const ch = n.cheese.sample3(wx, y, wz, 1.6);
        if (ch > (crystal ? 0.38 : y < 40 ? 0.5 : 0.62)) carve = true;
      }
      if (!carve) {
        const a = n.sp1.sample3(wx, y, wz, 1.2), b = n.sp2.sample3(wx, y, wz, 1.2);
        if (Math.abs(a) < 0.055 && Math.abs(b) < 0.055) carve = true;
      }
      if (carve) blocks[idx] = y <= 10 ? LAVA : AIR;
    }
    if (crystal) {
      for (let y = 5; y < Math.min(h - 6, 70); y++) {
        const idx = (y << 8) | (lz << 4) | lx;
        const below = blocks[((y - 1) << 8) | (lz << 4) | lx];
        const above = blocks[((y + 1) << 8) | (lz << 4) | lx];
        const r = hash3(wx, y, wz, s + 95);
        if (blocks[idx] === AIR && below !== AIR && below !== LAVA && r < 0.07) blocks[idx] = r < 0.035 ? BID.crystal_blue : BID.amethyst;
        else if (blocks[idx] === AIR && above !== AIR && above !== LAVA && r > 0.96) blocks[idx] = BID.amethyst;
        else if (blocks[idx] === STONE && (below === AIR || above === AIR) && r < 0.3) blocks[idx] = BID.amethyst;
      }
    }
  }

  // 6) trees, from every padded column (canopies cross chunk borders seamlessly)
  for (let pz = 2; pz < PADW - 2; pz++) for (let px = 2; px < PADW - 2; px++) {
    const biome = padBiome[pz * PADW + px];
    const h = padH[pz * PADW + px];
    if (h < SEA_LEVEL || biome.trees === "none" || biome.id === "river" || biome.id === "beach" && biome.trees !== "palm") continue;
    const wx = bx + px, wz = bz + pz;
    const r = hash2(wx, wz, s + 50);
    let density = biome.treeDensity;
    // forest patches: density varies smoothly so forests have edges and clearings
    density *= 0.4 + 1.2 * clamp(n.flower.sample2(wx * 0.3, wz * 0.3) + 0.6, 0, 1.2);
    if (r < density) {
      const lx = px - 8, lz = pz - 8;
      if (lx >= 0 && lx < 16 && lz >= 0 && lz < 16) {
        const topId = w.get(lx, h, lz);
        if (topId === AIR || topId === WATER || topId === LAVA) continue;
      }
      placeTree(w, biome.trees, wx, h + 1, wz, s);
    } else if (r > 0.994 && (biome.tint === "grass") && biome.trees !== "cactus") {
      placeTree(w, "bush", wx, h + 1, wz, s);
    }
  }

  // 7) ground foliage (grass, ferns, flower patches)
  for (let lz = 0; lz < 16; lz++) for (let lx = 0; lx < 16; lx++) {
    const biome = padBiome[(lz + 8) * PADW + lx + 8];
    const h = colH[lz * 16 + lx];
    if (h < SEA_LEVEL || h >= WORLD_HEIGHT - 2) continue;
    const wx = cx * 16 + lx, wz = cz * 16 + lz;
    const surface = w.get(lx, h, lz);
    if (w.get(lx, h + 1, lz) !== AIR) continue;
    const r = hash2(wx, wz, s + 61);
    if (biome.id === "desert" || biome.id === "badlands") {
      if (surface === BID.sand && r < 0.006) placeTree(w, "cactus", wx, h + 1, wz, s);
      else if (r < 0.02) w.set(lx, h + 1, lz, BID.dead_bush);
      continue;
    }
    if (surface === BID.sand && r < 0.05) {
      const nearWater = [[1, 0], [-1, 0], [0, 1], [0, -1]].some(([a, b]) => w.get(lx + a, h, lz + b) === WATER);
      if (nearWater) for (let i = 1; i <= 1 + Math.floor(hash2(wx, wz, s + 63) * 3); i++) w.set(lx, h + i, lz, BID.sugar_reed);
      continue;
    }
    if (biome.id === "mushroom_valley" && r < 0.06) { w.set(lx, h + 1, lz, r < 0.03 ? BID.red_mushroom : BID.brown_mushroom); continue; }
    if (biome.id === "toxic_marsh" && r < 0.1) { w.set(lx, h + 1, lz, BID.toxic_moss); continue; }
    if (biome.id === "boneyard" && r < 0.02) { w.set(lx, h + 1, lz, BID.bone_block); continue; }
    if (surface !== B(biome.top) && surface !== BID.grass_block && surface !== BID.podzol) continue;
    const patch = n.flower.sample2(wx, wz);
    if (patch > 0.3 && biome.flowerKinds.length && r < biome.flowers * 4 + 0.05) {
      const kind = biome.flowerKinds[Math.floor((patch * 7 + hash2(wx, wz, s + 62) * 2) * 10) % biome.flowerKinds.length];
      w.set(lx, h + 1, lz, BID[kind] ?? BID.poppy);
    } else if (r < biome.tallGrass) {
      const fern = biome.id === "taiga" || biome.id === "old_growth_taiga" || biome.id === "jungle" ? 0.45 : 0.08;
      w.set(lx, h + 1, lz, hash2(wx, wz, s + 64) < fern ? BID.fern : BID.tall_grass);
    } else if (r < biome.tallGrass + biome.flowers && biome.flowerKinds.length) {
      w.set(lx, h + 1, lz, BID[biome.flowerKinds[Math.floor(hash2(wx, wz, s + 65) * biome.flowerKinds.length)]] ?? BID.poppy);
    }
  }

  // 8) structures (rare, deterministic, clipped to this chunk)
  const sites = sitesNear(p, cx * 16, cz * 16, cx * 16 + 15, cz * 16 + 15);
  for (const site of sites) {
    const base = surfaceAt(p, site.x, site.z);
    if (site.kind === "giant_pyramid") stamp(w, site.x, base, site.z, 31, -15, 31, giantPyramid(s, site.x, site.z));
    else if (site.kind === "mansion") stamp(w, site.x, base, site.z, 16, -6, 24, obsidianMansion(s));
    else if (site.kind === "volcano") stamp(w, site.x, base, site.z, VOLCANO_RADIUS, -6, VOLCANO_HEIGHT, volcano(s));
    else if (site.kind === "fossil") stamp(w, site.x, base - 4, site.z, 20, -3, 8, fossil(s));
    else if (site.kind === "village") buildVillage(w, p, site.x, site.z, BIOME_BY_ID[climateAt(p, site.x, site.z).biome] ?? BIOME_BY_ID.plains, spawns);
    else if (site.kind === "ruin") buildRuin(w, site.x, base, site.z, s);
    else if (site.kind === "watchtower") buildWatchtower(w, site.x, base, site.z);
    else if (site.kind === "balloon") buildBalloon(w, site.x, Math.max(base + 36, 115), site.z, s);
  }

  // 9) animal spawns
  for (let a = 0; a < 2; a++) {
    if (hash2(cx * 3 + a, cz, s + 800) > 0.35) continue;
    const lx = 1 + Math.floor(hash2(cx, cz + a, s + 801) * 14);
    const lz = 1 + Math.floor(hash2(cx + a, cz, s + 802) * 14);
    const biome = padBiome[(lz + 8) * PADW + lx + 8];
    const h = colH[lz * 16 + lx];
    if (h >= SEA_LEVEL && biome.passive.length) {
      const kind = biome.passive[Math.floor(hash2(cx, cz, s + 803 + a) * biome.passive.length)];
      spawns.push({ kind: `animal:${kind}`, x: cx * 16 + lx + 0.5, y: h + 1, z: cz * 16 + lz + 0.5 });
    }
  }
  return { blocks, spawns };
}

// ---- Flat & tutorial worlds ----------------------------------------------------------------------
function genFlat(p: GenParams, cx: number, cz: number): GenResult {
  const blocks = new Uint16Array(CHUNK_VOLUME);
  const w = new ChunkWriter(blocks, cx, cz);
  const spawns: SpawnRec[] = [];
  const s = p.seed;
  for (let lz = 0; lz < 16; lz++) for (let lx = 0; lx < 16; lx++) {
    for (let y = 0; y <= 63; y++) {
      const id = y === 0 ? BEDROCK : y < 58 ? STONE : y < 63 ? BID.dirt : BID.grass_block;
      blocks[(y << 8) | (lz << 4) | lx] = id;
    }
    const wx = cx * 16 + lx, wz = cz * 16 + lz;
    const r = hash2(wx, wz, s + 61);
    const inTown = p.type === "tutorial" && Math.abs(wx) < 56 && Math.abs(wz) < 56;
    if (!inTown) {
      if (r < 0.3) blocks[(64 << 8) | (lz << 4) | lx] = r < 0.02 ? BID.dandelion : r < 0.04 ? BID.poppy : BID.tall_grass;
    }
  }
  // trees outside the town (padded so canopies cross borders)
  for (let px = -6; px < 22; px++) for (let pz = -6; pz < 22; pz++) {
    const wx = cx * 16 + px, wz = cz * 16 + pz;
    if (p.type === "tutorial" && Math.abs(wx) < 60 && Math.abs(wz) < 60) continue;
    if (hash2(wx, wz, s + 50) < 0.012) placeTree(w, hash2(wx, wz, s + 51) < 0.7 ? "oak" : "big_oak", wx, 64, wz, s);
  }
  if (p.type === "tutorial") buildTutorialTown(w, spawns);
  return { blocks, spawns };
}

/** Built-in tutorial town: plaza, roads, houses with villagers, farm, demo portal frame and a small lit pyramid. */
function buildTutorialTown(w: ChunkWriter, spawns: SpawnRec[]): void {
  const G = 63;
  for (let x = -54; x <= 54; x++) for (let d = -1; d <= 1; d++) { w.wset(x, G, d, BID.gravel); w.wset(d, G, x, BID.gravel); }
  for (let x = -6; x <= 6; x++) for (let z = -6; z <= 6; z++) w.wset(x, G, z, (x + z) % 2 === 0 ? BID.stone_bricks : BID.cobblestone);
  for (let x = -2; x <= 2; x++) for (let z = -2; z <= 2; z++) {
    const edge = Math.abs(x) === 2 || Math.abs(z) === 2;
    w.wset(x + 9, G, z + 9, edge ? BID.stone_bricks : WATER);
    if (edge) w.wset(x + 9, G + 1, z + 9, BID.stone_bricks);
  }
  for (const [lx, lz] of [[-6, -6], [6, -6], [-6, 6], [6, 6], [20, 3], [-20, 3], [3, 20], [3, -20], [36, 3], [-36, 3]]) lampPost(w, lx, G, lz);
  const houses: [number, number][] = [[-14, -12], [14, -12], [-14, 14], [14, 14], [-30, -12], [30, -12], [-30, 14], [30, 14]];
  for (const [hx, hz] of houses) buildHouse(w, hx, G, hz, BID.oak_planks, spawns);
  for (let x = 0; x < 8; x++) for (let z = 0; z < 5; z++) w.wset(-22 + x, G, 28 + z, z === 2 ? WATER : BID.hay_bale);
  // demo nether portal frame (unlit): 4 wide x 5 tall, at z = -22
  for (let dx = 0; dx < 4; dx++) for (let dy = 0; dy < 5; dy++) {
    const edge = dx === 0 || dx === 3 || dy === 0 || dy === 4;
    w.wset(18 + dx, G + 1 + dy, -22, edge ? BID.obsidian : AIR);
  }
  // small lit pyramid
  for (let L = 0; L < 10; L++) for (let dx = -(10 - L); dx <= 10 - L; dx++) for (let dz = -(10 - L); dz <= 10 - L; dz++) {
    const inner = Math.abs(dx) < 10 - L - 1 && Math.abs(dz) < 10 - L - 1 && L > 0 && L < 5;
    const id = inner ? ((Math.abs(dx) === 3 && Math.abs(dz) === 3) ? LAMPS()[(dx > 0 ? 1 : 0) + (dz > 0 ? 2 : 0)] : AIR) : BID.sandstone;
    w.wset(-40 + dx, G + 1 + L, -40 + dz, id);
  }
  for (let L = 1; L <= 3; L++) w.wset(-40, G + L, -40 + 10 - L + 1, AIR);
  for (let L = 1; L <= 3; L++) for (let k = 0; k < 3; k++) w.wset(-40, G + L, -40 + 9 - k, AIR);
  w.wset(-40, G + 1, -40, BID.chest);
  w.wset(-38, G + 1, -40, BID.tomb_block);
  for (const [x, z] of [[2, 3], [3, 2], [-3, 2]]) w.wset(x, G + 1, z, [BID.crafting_table, BID.furnace, BID.chest][(x + z + 9) % 3]);
}

// ---- Nether ---------------------------------------------------------------------------------------------
function genNether(p: GenParams, cx: number, cz: number): GenResult {
  const blocks = new Uint16Array(CHUNK_VOLUME);
  const w = new ChunkWriter(blocks, cx, cz);
  const s = p.seed;
  const spawns: SpawnRec[] = [];
  const LAVA_Y = 31;
  for (let lz = 0; lz < 16; lz++) for (let lx = 0; lx < 16; lx++) {
    const wx = cx * 16 + lx, wz = cz * 16 + lz;
    const basalt = noise2(wx * 0.008, wz * 0.008, s + 900) > 0.45;
    for (let y = 0; y < WORLD_HEIGHT; y++) {
      let id = AIR;
      if (y === 0 || y >= 127) id = BEDROCK;
      else {
        const dens = fbm3(wx * 0.028, y * 0.045, wz * 0.028, s + 901, 3) + 0.22 * (1 - Math.abs(y - 64) / 64);
        if (dens > 0.12 || (y > 118 && dens > -0.05)) {
          id = BID.netherrack;
          if (basalt && noise3(wx * 0.05, y * 0.02, wz * 0.05, s + 902) > 0.25) id = BID.basalt;
          if (y < 36 && hash3(wx, y, wz, s + 903) < 0.02) id = BID.soul_sand;
          if (y > 100 && hash3(wx, y, wz, s + 904) < 0.015) id = BID.glowstone;
          if (y < 40 && hash3(wx, y, wz, s + 905) < 0.01) id = BID.magma;
        } else if (y <= LAVA_Y) id = LAVA;
      }
      w.set(lx, y, lz, id);
    }
  }
  for (let rx = Math.floor((cx * 16 - 20) / 160); rx <= Math.floor((cx * 16 + 36) / 160); rx++)
    for (let rz = Math.floor((cz * 16 - 20) / 160); rz <= Math.floor((cz * 16 + 36) / 160); rz++) {
      if (hash2(rx, rz, s + 910) > 0.35) continue;
      const ox = rx * 160 + 32, oz = rz * 160 + 32, by = 70;
      for (let i = 0; i < 48; i++) for (let j = 0; j < 7; j++) {
        const x = ox + i, z = oz + j;
        w.wset(x, by, z, BID.nether_bricks);
        if (j === 0 || j === 6) { w.wset(x, by + 1, z, BID.nether_bricks); if (i % 4 === 0) w.wset(x, by + 2, z, BID.nether_bricks); }
        if (i % 6 === 0 && j === 3) for (let y = by - 1; y >= by - 30; y--) w.wset(x, y, z, BID.nether_bricks);
        if (i % 8 === 4 && j === 3) w.wset(x, by + 1, z, BID.lamp_red);
      }
    }
  if (hash2(cx, cz, s + 920) < 0.2) spawns.push({ kind: "hostile:blaze", x: cx * 16 + 8, y: 74, z: cz * 16 + 8 });
  return { blocks, spawns };
}

// ---- End --------------------------------------------------------------------------------------------------
function genEnd(p: GenParams, cx: number, cz: number): GenResult {
  const blocks = new Uint16Array(CHUNK_VOLUME);
  const w = new ChunkWriter(blocks, cx, cz);
  const s = p.seed;
  const spawns: SpawnRec[] = [];
  for (let lz = 0; lz < 16; lz++) for (let lx = 0; lx < 16; lx++) {
    const wx = cx * 16 + lx, wz = cz * 16 + lz;
    const d = Math.sqrt(wx * wx + wz * wz);
    const nn = noise2(wx * 0.021, wz * 0.021, s + 1000);
    let top = -1;
    if (d < 92 + nn * 10) top = Math.round(60 + nn * 5 - d * 0.05);
    const rg = Math.floor(wx / 160), rh = Math.floor(wz / 160);
    const cxI = rg * 160 + 40 + Math.floor(hash2(rg, rh, s + 1001) * 80);
    const czI = rh * 160 + 40 + Math.floor(hash2(rg, rh, s + 1002) * 80);
    const dI = Math.hypot(wx - cxI, wz - czI);
    if (hash2(rg, rh, s + 1003) < 0.5 && dI < 14 + hash2(rg, rh, s + 1004) * 10) top = Math.max(top, Math.round(52 + (14 - dI) * 0.5));
    const ang = Math.atan2(wz, wx);
    const kk = Math.round(ang / (Math.PI / 5));
    const a = kk * Math.PI / 5;
    const ring = 42 + (((kk % 2) + 2) % 2) * 3;
    const isPillar = Math.hypot(wx - Math.cos(a) * ring, wz - Math.sin(a) * ring) < 3.5;
    for (let y = 0; y < WORLD_HEIGHT; y++) {
      let id = AIR;
      if (top >= 0 && y <= top && y > top - 18) id = BID.end_stone;
      if (top >= 0 && y === top && hash2(wx, wz, s + 1006) < 0.04) id = BID.end_bricks;
      if (isPillar && y <= 92 + Math.floor(hash2(kk, 0, s + 1007) * 8)) id = BID.obsidian;
      w.set(lx, y, lz, id);
    }
    if (isPillar) w.set(lx, 101, lz, BID.crystal_blue);
    if (top > 40 && hash2(wx, wz, s + 1008) < 0.004) spawns.push({ kind: "hostile:enderman", x: wx + 0.5, y: top + 1, z: wz + 0.5 });
  }
  return { blocks, spawns };
}

// ---- Sift (prismatic dimension) ----------------------------------------------------------------------
function genSift(p: GenParams, cx: number, cz: number): GenResult {
  const blocks = new Uint16Array(CHUNK_VOLUME);
  const w = new ChunkWriter(blocks, cx, cz);
  const s = p.seed;
  const spawns: SpawnRec[] = [];
  for (let lz = 0; lz < 16; lz++) for (let lx = 0; lx < 16; lx++) {
    const wx = cx * 16 + lx, wz = cz * 16 + lz;
    const metal = noise2(wx * 0.01, wz * 0.01, s + 1100) > 0.35;
    for (let y = 0; y < WORLD_HEIGHT; y++) {
      let id = AIR;
      if (y === 0) id = BEDROCK;
      else if (y < 200) {
        const dens = fbm3(wx * 0.016, y * 0.03, wz * 0.016, s + 1102, 3) - Math.abs(y - 110) / 150;
        if (dens > 0.04) {
          id = y > 130 ? BID.sift_grass : BID.prism_stone;
          if (metal && y < 110 && hash3(wx, y, wz, s + 1103) < 0.08) id = hash3(wx, y, wz, s + 1104) < 0.5 ? BID.iron_block : BID.copper_block;
        } else if (y <= 66 && y > 40 && noise3(wx * 0.03, y * 0.05, wz * 0.03, s + 1105) > -0.1) id = SIFTW;
      }
      w.set(lx, y, lz, id);
    }
    if (hash2(Math.floor(wx / 24), Math.floor(wz / 24), s + 1101) > 0.82 && wx % 24 === 12 && wz % 24 === 12) {
      for (let y = 80; y < 94; y++) w.wset(wx, y, wz, y > 90 ? BID.crystal_blue : BID.amethyst);
    }
    if (hash2(wx, wz, s + 1106) < 0.008) spawns.push({ kind: "animal:prism_jelly", x: wx + 0.5, y: 140, z: wz + 0.5 });
  }
  return { blocks, spawns };
}

// ---- Dispatch ---------------------------------------------------------------------------------------------
export function generateChunk(p: GenParams, cx: number, cz: number): GenResult {
  switch (p.dim) {
    case "nether": return genNether(p, cx, cz);
    case "end": return genEnd(p, cx, cz);
    case "sift": return genSift(p, cx, cz);
    default: return genOverworld(p, cx, cz);
  }
}

export function findSafeY(blocks: Uint16Array, lx: number, lz: number, startY = 200): number {
  for (let y = Math.min(startY, WORLD_HEIGHT - 3); y > 1; y--) {
    const id = blocks[(y << 8) | (lz << 4) | lx];
    if (id !== 0 && id !== WATER && id !== LAVA && id !== TOXIC && id !== SIFTW
      && blocks[((y + 1) << 8) | (lz << 4) | lx] === 0 && blocks[((y + 2) << 8) | (lz << 4) | lx] === 0) return y + 1;
  }
  return 80;
}
