// Web Worker entry: receives chunk requests and returns generated block data (transferred, zero-copy).
import { generateChunk, type GenParams } from "./generator";

interface GenRequest {
  id: number;
  params: GenParams;
  cx: number;
  cz: number;
}

const ctx = self as unknown as {
  postMessage(msg: unknown, transfer?: Transferable[]): void;
  onmessage: ((e: MessageEvent<GenRequest>) => void) | null;
};

ctx.onmessage = (e: MessageEvent<GenRequest>) => {
  const { id, params, cx, cz } = e.data;
  try {
    const result = generateChunk(params, cx, cz);
    ctx.postMessage({ id, blocks: result.blocks, spawns: result.spawns }, [result.blocks.buffer]);
  } catch (err) {
    ctx.postMessage({ id, error: String(err) });
  }
};
