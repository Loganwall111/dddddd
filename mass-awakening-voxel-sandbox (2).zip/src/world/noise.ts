// Deterministic noise + RNG utilities. Pure functions only (safe to run in Web Workers).

export function hashString(str: string): number {
  // FNV-1a 32-bit
  let h = 0x811c9dc5;
  for (let i = 0; i < str.length; i++) {
    h ^= str.charCodeAt(i);
    h = Math.imul(h, 0x01000193);
  }
  return h >>> 0;
}

/** Converts a user-entered seed (number or text) into a 32-bit integer. */
export function seedToInt(seed: string): number {
  const trimmed = seed.trim();
  if (trimmed === "") return Math.floor(Math.random() * 0x7fffffff);
  if (/^-?\d+$/.test(trimmed)) return Number(trimmed) | 0;
  return hashString(trimmed) | 0;
}

export function mulberry32(seed: number): () => number {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

/** Integer hash -> [0,1). */
export function hash2(x: number, y: number, seed: number): number {
  let h = Math.imul(x | 0, 374761393) + Math.imul(y | 0, 668265263) + Math.imul(seed | 0, 1442695041);
  h = Math.imul(h ^ (h >>> 13), 1274126177);
  h ^= h >>> 16;
  return (h >>> 0) / 4294967296;
}

export function hash3(x: number, y: number, z: number, seed: number): number {
  let h = Math.imul(x | 0, 374761393) + Math.imul(y | 0, 668265263) + Math.imul(z | 0, 2246822519) + Math.imul(seed | 0, 1442695041);
  h = Math.imul(h ^ (h >>> 13), 1274126177);
  h ^= h >>> 16;
  return (h >>> 0) / 4294967296;
}

const fade = (t: number) => t * t * t * (t * (t * 6 - 15) + 10);
const lerp = (a: number, b: number, t: number) => a + (b - a) * t;

/** Smooth value noise in [-1,1]. */
export function noise2(x: number, y: number, seed: number): number {
  const xi = Math.floor(x), yi = Math.floor(y);
  const xf = x - xi, yf = y - yi;
  const u = fade(xf), v = fade(yf);
  const a = hash2(xi, yi, seed) * 2 - 1;
  const b = hash2(xi + 1, yi, seed) * 2 - 1;
  const c = hash2(xi, yi + 1, seed) * 2 - 1;
  const d = hash2(xi + 1, yi + 1, seed) * 2 - 1;
  return lerp(lerp(a, b, u), lerp(c, d, u), v);
}

export function noise3(x: number, y: number, z: number, seed: number): number {
  const xi = Math.floor(x), yi = Math.floor(y), zi = Math.floor(z);
  const xf = x - xi, yf = y - yi, zf = z - zi;
  const u = fade(xf), v = fade(yf), w = fade(zf);
  const n000 = hash3(xi, yi, zi, seed) * 2 - 1;
  const n100 = hash3(xi + 1, yi, zi, seed) * 2 - 1;
  const n010 = hash3(xi, yi + 1, zi, seed) * 2 - 1;
  const n110 = hash3(xi + 1, yi + 1, zi, seed) * 2 - 1;
  const n001 = hash3(xi, yi, zi + 1, seed) * 2 - 1;
  const n101 = hash3(xi + 1, yi, zi + 1, seed) * 2 - 1;
  const n011 = hash3(xi, yi + 1, zi + 1, seed) * 2 - 1;
  const n111 = hash3(xi + 1, yi + 1, zi + 1, seed) * 2 - 1;
  const x00 = lerp(n000, n100, u), x10 = lerp(n010, n110, u);
  const x01 = lerp(n001, n101, u), x11 = lerp(n011, n111, u);
  return lerp(lerp(x00, x10, v), lerp(x01, x11, v), w);
}

/** Fractal Brownian motion, normalized to roughly [-1,1]. */
export function fbm2(x: number, y: number, seed: number, octaves = 4, lacunarity = 2, gain = 0.5): number {
  let amp = 1, freq = 1, sum = 0, norm = 0;
  for (let i = 0; i < octaves; i++) {
    sum += noise2(x * freq, y * freq, seed + i * 1013) * amp;
    norm += amp;
    amp *= gain;
    freq *= lacunarity;
  }
  return sum / norm;
}

export function fbm3(x: number, y: number, z: number, seed: number, octaves = 3): number {
  let amp = 1, freq = 1, sum = 0, norm = 0;
  for (let i = 0; i < octaves; i++) {
    sum += noise3(x * freq, y * freq, z * freq, seed + i * 1013) * amp;
    norm += amp;
    amp *= 0.5;
    freq *= 2;
  }
  return sum / norm;
}

/** Ridged multifractal in [0,1]: sharp mountain crests. */
export function ridged2(x: number, y: number, seed: number, octaves = 4): number {
  let amp = 1, freq = 1, sum = 0, norm = 0;
  for (let i = 0; i < octaves; i++) {
    const n = 1 - Math.abs(noise2(x * freq, y * freq, seed + i * 271));
    sum += n * n * amp;
    norm += amp;
    amp *= 0.5;
    freq *= 2.03;
  }
  return sum / norm;
}

// ---- Seeded gradient (Perlin) noise ------------------------------------------------------
// Improved Perlin noise with a per-seed permutation table. Smooth and isotropic, so terrain
// does not show the blocky grid artefacts of value noise.

const GRAD3 = [
  [1, 1, 0], [-1, 1, 0], [1, -1, 0], [-1, -1, 0], [1, 0, 1], [-1, 0, 1], [1, 0, -1], [-1, 0, -1],
  [0, 1, 1], [0, -1, 1], [0, 1, -1], [0, -1, -1], [1, 1, 0], [0, -1, 1], [-1, 1, 0], [0, -1, -1],
];

export class Perlin {
  private p = new Uint8Array(512);
  readonly ox: number;
  readonly oy: number;
  readonly oz: number;
  constructor(seed: number) {
    const rnd = mulberry32(seed);
    const perm = new Uint8Array(256);
    for (let i = 0; i < 256; i++) perm[i] = i;
    for (let i = 255; i > 0; i--) {
      const j = Math.floor(rnd() * (i + 1));
      const t = perm[i]; perm[i] = perm[j]; perm[j] = t;
    }
    for (let i = 0; i < 512; i++) this.p[i] = perm[i & 255];
    // random origin offsets, as in Minecraft's ImprovedNoise, so octaves don't align at 0,0
    this.ox = rnd() * 256; this.oy = rnd() * 256; this.oz = rnd() * 256;
  }
  noise3(x: number, y: number, z: number): number {
    x += this.ox; y += this.oy; z += this.oz;
    const xi = Math.floor(x), yi = Math.floor(y), zi = Math.floor(z);
    const X = xi & 255, Y = yi & 255, Z = zi & 255;
    const xf = x - xi, yf = y - yi, zf = z - zi;
    const u = fade(xf), v = fade(yf), w = fade(zf);
    const p = this.p;
    const A = p[X] + Y, AA = p[A] + Z, AB = p[A + 1] + Z;
    const Bq = p[X + 1] + Y, BA = p[Bq] + Z, BB = p[Bq + 1] + Z;
    const g = (h: number, dx: number, dy: number, dz: number) => {
      const gr = GRAD3[h & 15];
      return gr[0] * dx + gr[1] * dy + gr[2] * dz;
    };
    return lerp(
      lerp(lerp(g(p[AA], xf, yf, zf), g(p[BA], xf - 1, yf, zf), u), lerp(g(p[AB], xf, yf - 1, zf), g(p[BB], xf - 1, yf - 1, zf), u), v),
      lerp(lerp(g(p[AA + 1], xf, yf, zf - 1), g(p[BA + 1], xf - 1, yf, zf - 1), u), lerp(g(p[AB + 1], xf, yf - 1, zf - 1), g(p[BB + 1], xf - 1, yf - 1, zf - 1), u), v),
      w,
    );
  }
  noise2(x: number, z: number): number {
    return this.noise3(x, 0.5, z);
  }
}

/**
 * Octave noise in the style of Minecraft's legacy terrain noises.
 * `baseFreq` is the frequency of the lowest octave; each octave doubles frequency and halves amplitude.
 * Octaves whose frequency exceeds `maxFreq` are skipped: at a 4-block sampling grid they only alias
 * into speckle, which is a major cause of "jagged" terrain.
 */
export class OctaveNoise {
  private octaves: Perlin[] = [];
  private amps: number[] = [];
  private freqs: number[] = [];
  private norm = 1;
  constructor(seed: number, octaves: number, baseFreq: number, maxFreq = 0.25) {
    let f = baseFreq, a = 1, sum = 0;
    for (let i = 0; i < octaves; i++) {
      if (f > maxFreq) break;
      this.octaves.push(new Perlin(seed * 31 + i * 7919 + 17));
      this.amps.push(a);
      this.freqs.push(f);
      sum += a;
      f *= 2;
      a *= 0.5;
    }
    this.norm = sum > 0 ? 1 / sum : 1;
  }
  /** Returns roughly [-1, 1]. `yScale` squashes vertical frequency (legacy terrain uses flatter vertical noise). */
  sample3(x: number, y: number, z: number, yScale = 1): number {
    let v = 0;
    for (let i = 0; i < this.octaves.length; i++) {
      const f = this.freqs[i];
      v += this.octaves[i].noise3(x * f, y * f * yScale, z * f) * this.amps[i];
    }
    return v * this.norm * 1.6;
  }
  sample2(x: number, z: number): number {
    let v = 0;
    for (let i = 0; i < this.octaves.length; i++) {
      const f = this.freqs[i];
      v += this.octaves[i].noise2(x * f, z * f) * this.amps[i];
    }
    return v * this.norm * 1.6;
  }
}

export function clamp(v: number, lo: number, hi: number): number {
  return v < lo ? lo : v > hi ? hi : v;
}

export function smoothstep(e0: number, e1: number, x: number): number {
  const t = clamp((x - e0) / (e1 - e0), 0, 1);
  return t * t * (3 - 2 * t);
}
