# AETHERFORGED: REINCARNATED

An original browser voxel sandbox built with **TypeScript, Babylon.js 9 (WebGL2), React and Vite**.
Textures, icons, mob skins, sounds and music are all generated procedurally at runtime.

**Build status: passing.** `npm run build` produces a single `dist/index.html` (~2.9 MB, ~0.7 MB gzip).
The game has not been run in a browser by the author of these changes, and frame rates have not been measured.

```bash
npm install
npm run dev     # http://localhost:5173
npm run build   # dist/index.html
```

## What changed in this update

| Request | Status | Notes |
| --- | --- | --- |
| Build fix | Done | All Babylon imports go through `src/rendering/babylon.ts` (subpath imports). Bundle went from 3,254 to 800 modules. |
| Coloured lighting / torches emit coloured light | Done (approximate) | Emitters (torch, lantern, lamps, lava, crystals...) add coloured light to nearby vertices, distance-weighted, radius 11. **No occlusion**: light can leak through thin walls. |
| Emissive textures for mobs | Done | Every mob has glowing eyes (emissive texture); hostile mobs glow brighter. |
| Mob textures | Fixed | Box UVs were computed in world units, so faces sampled ~1 pixel. Now 16 px per block. |
| TNT / block physics / ragdolls | Done (simplified) | Explosions fling textured debris cubes that bounce and fade. Sand and gravel fall. Killed mobs tumble over with momentum (a simplified ragdoll, not a jointed physics ragdoll). |
| Particles | Done | Block-break particles in the block's colour, eruption lava and smoke. |
| Anti-aliasing | Done | MSAA (setting) + FXAA always on. |
| Screen jitter / static noise / blurry distance | Addressed (unverified) | Removed screen-space god rays, sharpen and grain. Stars are anti-aliased. Atlas tiles have 16 px gutters so mipmaps don't bleed (likely cause of shimmer). Nearest-magnify plus trilinear/anisotropic minify. Linear fog keeps the mid-distance crisp. |
| Visible sun and real god rays | Done (approximation) | Sun and moon discs. Sun shafts in the sky shader. World-space light-beam quads slanting along the sun direction, strongest at sunrise and sunset. Not shadow-accurate volumetrics. |
| Better shadows | Done | Cascaded shadow maps (3 cascades, PCF). |
| More cinematic colour | Done | ACES tone mapping, higher exposure and contrast, vignette, stronger bloom. |
| Rain reflections / puddles | Done (approximate) | Wet ground gets darker and glossier. Glossy puddle decals appear around you in rain. Not true mirror reflections. |
| Realistic thunder | Done | Thunder (crack + rolling rumble) is synced to each lightning bolt and delayed by distance. |
| Biome ambience | Done | Birds, crickets, owls, waves, frogs, wind gusts, cave drips and rumbles, Nether lava, underwater bubbles. |
| Underwater | Partly | Dense coloured underwater fog and tint. Seeing the surface reflected from below depends on Babylon's WaterMaterial and is unverified. |
| Terrain noise (low/high/selector/depth) | Done | Seeded Perlin noise using the octave counts and base frequencies provided. Sampled on a 4×8×4 grid and trilinearly interpolated. Octaves above the grid's resolution are skipped because they only alias. Biome depth and scale are blended over a 5×5 neighbourhood. This follows the legacy structure but is **not a bit-exact reproduction** of Minecraft. |
| Bigger forests, more foliage | Done | Trees can root in any column, including across chunk borders. New big oak, mega spruce, tall birch, acacia, bushes and mixed forests. Forest density varies in patches. Ferns, dandelions and alliums; flower patches use flower noise. New biomes: flower forest, old-growth taiga, meadow. |
| Structures overhaul, less crowded | Done | Rare region grids (448 / 320 / 144 blocks). Giant desert pyramids (grand hall with coloured lamp pillars, stair to a tomb chamber with sarcophagi, gold and chests). Obsidian mansions. Volcanoes. Giant fossils. Watchtowers. Bigger villages seated on the terrain. Ruins and balloons. No structure generates portals. Toxic sludge is now green (it was purple, which may have read as portals). |
| Erupting volcanoes | Done | When you're within ~220 blocks, an eruption happens every 4–9 minutes: lava fountain, smoke column, lava bombs that land as magma, rumble and screen shake. |
| Crystal caves, better caves | Done | Cheese caverns, spaghetti tunnels, lava below y=10, and crystal-cave regions lined with amethyst and glowing crystals. |
| Better first-person arm | Done | Slimmer, flat-lit arm reaching in from the bottom-right, rendered in its own layer so it never clips into blocks. |
| Menus as separate screens | Done | Every menu is a full-screen page with a dark dirt background. Options is a hub with separate pages for Video, Shaders & Effects, Sounds, Controls, Accessibility, World and Skin. Create World has Game / World / More tabs. |
| World Tour | Done | Pause menu → World Tour: a cinematic camera visits one location per distinct biome plus nearby big structures, with letterbox bars, title cards and fades while chunks load. Esc ends it. |
| Tutorial world | Done | Title → Tutorial World: a town with houses and villagers, a plaza, a farm, a demo obsidian portal frame, a small lit pyramid, a starter kit and an 8-step checklist panel. |

## Not done / known limitations

- Coloured light has no occlusion, and lighting is baked per chunk mesh (re-meshed when lights change).
- God rays are artistic approximations, not shadowed volumetric scattering.
- Puddles are glossy decals, not mirrors. Underwater surface reflection is unverified.
- Ragdolls are a tumble animation with physics, not jointed limbs.
- Ladders aren't climbable. Multiplayer and WebGPU are not implemented.
- Terrain generation is heavier than before (16-octave-class noise). Worker generation keeps the main thread free, but chunk loading may be slower on weak CPUs.
- No runtime testing was possible in this environment.

## Controls

WASD move · Space jump (double-tap to fly in creative) · Shift sprint · Ctrl sneak · Left click mine/attack · Right click place/use/talk ·
Middle click pick block · 1–9 / wheel hotbar · E inventory · Q drop · F third person · G fly · F3 debug · Esc pause / exit tour.

See `docs/ARCHITECTURE.md` for module layout and extension points.
