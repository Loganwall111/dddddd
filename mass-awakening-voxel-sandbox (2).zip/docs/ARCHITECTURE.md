# Architecture

## Layers

| Folder | Responsibility |
| --- | --- |
| `src/core` | `Game` orchestrator (engine, scene, loop, input, survival, containers, TNT, portals, saving, UI snapshot). `settings.ts` holds persisted options and graphics presets. |
| `src/world` | Pure, worker-safe generation (`generator.ts`, `noise.ts`, `biomes.ts`), chunk streaming (`world.ts`), greedy-free culled meshing (`mesher.ts`), worker entry (`generator.worker.ts`). |
| `src/blocks` | Data-driven block registry (`blocks.ts`) and procedural pixel-art atlas painter (`textures.ts`). |
| `src/items` | Data-driven item registry (tools, armour, food, ingredients, spawn eggs) with icon specs. |
| `src/inventory` | Stack rules and click semantics shared by player inventory, containers and creative palette. |
| `src/crafting` | Recipe registry, shaped/shapeless matching with tags, smelting and fuel tables. |
| `src/rendering` | Environment (sky, clouds, sun/moon, god rays, post-processing, shadows, weather particles) and materials (atlas, emissive, portal shader, WaterMaterial). |
| `src/player` | Player physics, camera, held items, voxel raycasting. |
| `src/entities` | Voxel model builder (64×64 MC-layout skins), mob definitions, AI, ground items, projectiles, villager dialogue. |
| `src/dimensions` | Dimension registry (sky presets, coordinate scale) and frame-based portal detection and ignition. |
| `src/audio` | Web Audio synthesis, buses, positional sounds, ambience and generative music. |
| `src/persistence` | IndexedDB stores (`worlds`, `chunks`, `containers`, `kv`), RLE chunk codec, export/import. |
| `src/ui` | React menus (`Menus.tsx`) and in-game overlays (`InGame.tsx`). |
| `src/App.tsx` | Screen router that owns the single `Game` instance. |

## Data flow

1. `App` creates one `Game` bound to the canvas and subscribes to its snapshots.
2. `Game.startPanorama()` creates a `World` with a dummy store. The camera orbits it behind the title menu.
3. `Game.enterWorld(meta)` loads the save, creates a `World` for the dimension and waits for spawn chunks.
4. Each frame: input → physics → camera → world streaming and meshing (time-budgeted) → mining/placing → entities → TNT → furnaces → survival → portals → environment → audio. A snapshot is emitted at 10 Hz.
5. Chunk generation runs in a Web Worker (`generator.worker.ts`, inlined). Saved chunks are read from IndexedDB first.

## Extension points

- **Block:** add an entry in `src/blocks/blocks.ts` (`blk(...)`) and a painter in `src/blocks/textures.ts`. Items for blocks are generated automatically.
- **Item:** add to `src/items/items.ts`. Give it an icon spec and optional tool, armour or food data.
- **Recipe:** add to `src/crafting/recipes.ts` using `add({...})`.
- **Biome:** add to `BIOMES` in `src/world/biomes.ts` and extend `selectBiome`.
- **Mob:** add a `MobDef` (parts, drops, AI flags) in `src/entities/entities.ts`, and an egg entry in `src/items/items.ts`.
- **Dimension:** add a `DimensionDef` and a generator branch in `src/world/generator.ts`, then map a frame block in `src/dimensions/dimensions.ts`.

## Multiplayer (not implemented)

Intended design: the server owns world edits, entity state and time. The client sends intents (break, place, move) and renders server snapshots. The current singleplayer `Game` already separates world data (`World`), simulation (`Game` update) and presentation (`Environment`, `UI`), so a transport adapter can be added without restructuring. No server exists in this repository.
