package dev.massg.siftsuite;

import java.util.function.Function;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.core.Registry;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.SoundType;

public final class ModBlocks {
    public static final Block RIFT_FRAME = register("rift_frame", Block::new,
            BlockBehaviour.Properties.of().strength(3.5F).requiresCorrectToolForDrops()
                    .sound(SoundType.AMETHYST_CLUSTER).lightLevel(state -> 7));
    public static final Block RIFT_SURFACE = register("rift_surface", RiftSurfaceBlock::new,
            BlockBehaviour.Properties.of().strength(0.2F).noOcclusion().noCollision()
                    .sound(SoundType.GLASS).lightLevel(state -> 12));
    public static final Block RIFT_SHARD = register("rift_shard", Block::new,
            BlockBehaviour.Properties.of().strength(2.0F).noOcclusion().sound(SoundType.AMETHYST_CLUSTER)
                    .lightLevel(state -> 10));

    private static Block register(String name, Function<BlockBehaviour.Properties, Block> factory,
                                  BlockBehaviour.Properties properties) {
        Identifier id = Identifier.fromNamespaceAndPath(SiftRiftMod.MOD_ID, name);
        ResourceKey<Block> blockKey = ResourceKey.create(Registries.BLOCK, id);
        Block block = factory.apply(properties.setId(blockKey));
        Registry.register(BuiltInRegistries.BLOCK, blockKey, block);
        ResourceKey<Item> itemKey = ResourceKey.create(Registries.ITEM, id);
        BlockItem item = new BlockItem(block, new Item.Properties().setId(itemKey));
        Registry.register(BuiltInRegistries.ITEM, itemKey, item);
        return block;
    }

    public static void initialize() { }
    private ModBlocks() { }
}
