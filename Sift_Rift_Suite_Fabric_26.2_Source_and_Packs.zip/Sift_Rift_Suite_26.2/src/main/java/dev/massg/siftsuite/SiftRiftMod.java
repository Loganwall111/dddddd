package dev.massg.siftsuite;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.commands.Commands;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.fabricmc.fabric.api.itemgroup.v1.CreativeModeTabEvents;

public final class SiftRiftMod implements ModInitializer {
    public static final String MOD_ID = "siftsuite";
    public static final ResourceKey<Level> SIFT_DIMENSION = ResourceKey.create(
            Registries.DIMENSION, Identifier.fromNamespaceAndPath(MOD_ID, "sift"));
    private static final int PORTAL_WIDTH = 5;
    private static final int PORTAL_HEIGHT = 7;

    @Override
    public void onInitialize() {
        ModBlocks.initialize();
        CreativeModeTabEvents.modifyOutputEvent(CreativeModeTabs.BUILDING_BLOCKS).register(entries -> {
            entries.accept(ModBlocks.RIFT_FRAME.asItem());
            entries.accept(ModBlocks.RIFT_SURFACE.asItem());
            entries.accept(ModBlocks.RIFT_SHARD.asItem());
        });
        registerCommands();
    }

    private static void registerCommands() {
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) ->
            dispatcher.register(Commands.literal("siftrift")
                .then(Commands.literal("build").executes(context -> {
                    ServerPlayer player = context.getSource().getPlayerOrException();
                    int count = buildPortal(player.serverLevel(), player.blockPosition(), player.getDirection());
                    context.getSource().sendSuccess(() -> Component.literal(
                            "Sift Rift built in front of you (" + count + " blocks). Use /siftrift enter to travel."), false);
                    return 1;
                }))
                .then(Commands.literal("clear").executes(context -> {
                    ServerPlayer player = context.getSource().getPlayerOrException();
                    int count = clearPortal(player.serverLevel(), player.blockPosition(), player.getDirection());
                    context.getSource().sendSuccess(() -> Component.literal("Removed " + count + " Sift Rift blocks."), false);
                    return 1;
                }))
                .then(Commands.literal("enter").executes(context -> {
                    ServerPlayer player = context.getSource().getPlayerOrException();
                    MinecraftServer server = context.getSource().getServer();
                    ServerLevel destination = server.getLevel(SIFT_DIMENSION);
                    if (destination == null) {
                        context.getSource().sendFailure(Component.literal("The Sift dimension did not load. Check data/siftsuite/dimension/sift.json."));
                        return 0;
                    }
                    player.changeDimension(destination);
                    return 1;
                }))
                .then(Commands.literal("return").executes(context -> {
                    ServerPlayer player = context.getSource().getPlayerOrException();
                    ServerLevel overworld = context.getSource().getServer().overworld();
                    player.changeDimension(overworld);
                    return 1;
                }))
                .then(Commands.literal("help").executes(context -> {
                    context.getSource().sendSuccess(() -> Component.literal(
                            "/siftrift build | clear | enter | return | help"), false);
                    return 1;
                }))
            )
        );
    }

    private static Direction widthDirection(Direction facing) {
        return facing.getAxis() == Direction.Axis.Z ? Direction.EAST : Direction.SOUTH;
    }

    private static BlockPos portalBottomCenter(BlockPos playerPos, Direction facing) {
        // Four blocks ahead, with the portal base at the player's feet level.
        return playerPos.relative(facing, 4).below();
    }

    private static int buildPortal(ServerLevel world, BlockPos playerPos, Direction facing) {
        BlockPos bottom = portalBottomCenter(playerPos, facing);
        Direction width = widthDirection(facing);
        int changed = 0;
        for (int y = 0; y < PORTAL_HEIGHT; y++) {
            for (int w = -2; w <= 2; w++) {
                BlockPos pos = bottom.relative(width, w).above(y);
                boolean border = (y == 0 || y == PORTAL_HEIGHT - 1 || w == -2 || w == 2);
                BlockState state;
                if (border) {
                    // Crystal anchors decorate the top/bottom midpoints of the frame.
                    boolean crown = w == 0 && (y == 0 || y == PORTAL_HEIGHT - 1);
                    state = crown ? ModBlocks.RIFT_SHARD.defaultBlockState() : ModBlocks.RIFT_FRAME.defaultBlockState();
                } else {
                    state = ModBlocks.RIFT_SURFACE.defaultBlockState().setValue(RiftSurfaceBlock.FACING, facing);
                }
                world.setBlock(pos, state, 3);
                changed++;
            }
        }
        return changed;
    }

    private static int clearPortal(ServerLevel world, BlockPos playerPos, Direction facing) {
        BlockPos bottom = portalBottomCenter(playerPos, facing);
        Direction width = widthDirection(facing);
        int removed = 0;
        for (int y = 0; y < PORTAL_HEIGHT; y++) {
            for (int w = -2; w <= 2; w++) {
                BlockPos pos = bottom.relative(width, w).above(y);
                BlockState current = world.getBlockState(pos);
                if (current.is(ModBlocks.RIFT_FRAME) || current.is(ModBlocks.RIFT_SURFACE) || current.is(ModBlocks.RIFT_SHARD)) {
                    world.setBlock(pos, Blocks.AIR.defaultBlockState(), 3);
                    removed++;
                }
            }
        }
        return removed;
    }


}
