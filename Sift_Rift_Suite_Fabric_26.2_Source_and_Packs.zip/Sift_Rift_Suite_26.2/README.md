# Sift Rift Suite — Fabric 26.2 Source Project

An original, reference-guided Sift Rift mod and asset suite. The uploaded reference MP4 has now been inspected and all of its decoded frames exported. The video is approximately 11:32 long at 640×360 / 29.97 fps (20,755 frames). The contact sheets included under `reference-frames/video1/` summarize the 06:19-to-end sequence, one representative frame per second; the CSV maps every extracted frame to its source timestamp. Full frame exports are supplied separately in five ZIP parts because the image set is about 814 MB unpacked.

## What the inspected footage informed

- Around **06:19–07:03**, a bright segmented pink/white geometric effect with shifting block-like lobes dominates the scene.
- Around **07:04–07:25**, a strong lime-green / warm-white square fracture effect fills the view during the transition.
- From approximately **07:25 onward**, the environment shows bright mint/cyan sky, pink atmospheric bands, teal vegetation, purple/magenta rock shelves, and cyan waterfalls / vertical streams, with occasional hard-edged green light.

The revised assets are newly generated interpretations of the observed shape language and palette, not raw video screenshots pasted into the mod. The animated surface now uses eight angular square-fracture frames rather than a spiral; the panorama and shader have been revised for teal/pink Sift atmosphere and day/night tinting; the standalone OBJ Rift ring is now angular and beveled.

## Mod features

- **Custom blocks**: Sift Rift Frame, Animated Rift Surface, and Rift Crystal Shard.
- **Commands**: `/siftrift build` constructs a 5×7 animated rift in front of the player, `/siftrift clear` removes custom portal blocks in the same target footprint, `/siftrift enter` travels to the Sift dimension, `/siftrift return` returns to the Overworld, and `/siftrift help` lists commands.
- **Prototype dimension**: the data definition uses vanilla noise terrain and a fixed Meadow biome to keep this first implementation small and compatible. It is not yet a custom Sift biome/terrain generator.
- **Iris/OpenGL shader pack**: 2:1 Sift panorama, moving cyan/pink atmospheric ribbons, lime fracture-light accents, and world-time day/night color modulation.
- **Geometry exports**: OBJ meshes for an angular Rift ring, floating island with waterfall sheets, and crystal shard. OBJ files are editable assets; vanilla Minecraft's resource-pack renderer does not automatically load arbitrary OBJ meshes. The in-game Rift itself is built with Minecraft blocks.
- **Frame reference tools**: Python/FFmpeg pipeline plus timestamp/contact-sheet outputs. The frame extraction is a visual-reference tool, not recovery of original game source code.

## Build the Fabric mod

Minecraft 26.2 targets Java 25. Install **JDK 25**, Fabric Loader for 26.2, and a matching Fabric API. This project specifies Loom 1.17.13 and Fabric API `0.154.2+26.2`. Open the project in IntelliJ IDEA or VS Code with Java and Gradle extensions, then run the Gradle `build` task. If you have a compatible installed Gradle:

```bash
gradle build
```

The output JAR should be in `build/libs/`. Copy it to `.minecraft/mods` alongside Fabric API. This environment has Java 21 and cannot download build dependencies, so the project has **not** been compiled or launched here. A local compile/runtime test is still required before relying on it in a main save.

## Install the texture / geometry resource pack

Copy `standalone-packs/Sift_Geometry_Assets_26.2.zip` to `.minecraft/resourcepacks` and enable it. This pack relies on the mod registering the `siftsuite` block identifiers. The mod bundles matching base textures as well, so the separate pack is optional.

## Install the shader pack

Copy `standalone-packs/Sift_Atmosphere_Iris_OpenGL.zip` to `.minecraft/shaderpacks`. Install Iris for Minecraft 26.2 and enable the pack. Use **OpenGL** in Minecraft 26.2's Graphics API setting when running Iris; do not select the optional Vulkan backend for this shader workflow. This is a sky/atmosphere shader, not a complete PBR, water-reflection, or ray-tracing package.

## Use in-game

1. Use a disposable world and enable cheats / command permission.
2. Stand in an open area and run `/siftrift build`.
3. Run `/siftrift enter` to test the prototype dimension. The portal face is animated, but it does not yet teleport on collision; entering the dimension remains command-based.
4. Run `/siftrift return` to go back to the Overworld.

The portal builder places blocks four blocks ahead and can overwrite the 5×7 footprint. Use it in an open area. `/siftrift clear` only deletes the mod's three custom blocks in that footprint; it does not restore replaced terrain.

## Frame extraction details

`reference-tools/sift_reference_pipeline.py` can take local MP4 files or attempt to fetch video URLs using `yt-dlp`. Install FFmpeg/FFprobe, Pillow, and (for URL fetching) yt-dlp. The uploaded MP4 was processed separately with FFmpeg using passthrough frame decoding; **all 20,755 frames are included in the separate five-part frame archive set**, with source timestamps in `frames_manifest.csv`. Contact sheets under `reference-frames/video1/` sample one representative frame per second from 06:19 to the end for quick inspection.

For local videos, the general pipeline can be invoked with:

```bash
python -m pip install Pillow yt-dlp
python reference-tools/sift_reference_pipeline.py --video1 "sift.mp4" --video2 "dungeons_ii_trailer.mp4"
```

If running the YouTube fetch workflow, check that you have access to the videos and comply with the platform's terms. The extraction process gets rendered frames; it does not recover the source mod's Java code or hidden assets.

## License / attribution

This is an original fan-made implementation guided by a user-provided video. It is not an official Mojang/Microsoft product and is not affiliated with Minecraft Dungeons II. Use the exported frames only as reference material; the game assets generated for the mod are newly created interpretations.
