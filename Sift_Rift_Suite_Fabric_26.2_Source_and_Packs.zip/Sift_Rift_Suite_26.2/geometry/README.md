# Sift Rift Geometry Exports — reference-guided revision

Original generated mesh assets for the Sift Rift Suite prototype. Import the OBJ files into Blender or another OBJ-capable model editor. These exports are not a Java Edition resource-pack model format on their own; the in-game portal is built from native Minecraft block models for compatibility.

- `sift_rift_geometry.obj`: thick, angular squared-fracture ring with a beveled inner aperture and dark teal-violet edge materials. The updated silhouette follows the observed blocky portal language in the uploaded footage rather than an oval/toroidal design.
- `sift_floating_island.obj`: terraced floating-island platform with waterfall sheets.
- `rift_crystal_shard.obj`: standalone crystal shard mesh.

OBJ material paths are relative to the provided MTL files and may need re-pointing after import. Companion textures are in `Sift_Geometry_Assets_26.2.zip`.
