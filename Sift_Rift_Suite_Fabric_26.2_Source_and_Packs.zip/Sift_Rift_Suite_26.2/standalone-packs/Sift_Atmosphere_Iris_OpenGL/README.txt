SIFT ATMOSPHERE — Iris/OpenGL Shader Pack (reference-guided refresh)

Install: copy this ZIP into .minecraft/shaderpacks, then select it in Iris' Shader Packs menu. The ZIP has shaders/ at its root. Use Minecraft 26.2 with a compatible Iris build and select OpenGL in the game's Graphics API setting; Iris shaders do not run on the optional Vulkan backend.

This revision uses an original 2:1 Sift panorama guided by the uploaded video: bright mint/cyan sky, pink atmospheric ribbons, teal canopy, magenta/plum cliffs, and a few distant square fracture lights. The sky-basic shader adds moving cyan/pink aurora bands, a lime fracture-light sweep, and worldTime day/night tinting.

Limitations: the shader affects the sky-basic pass in any dimension where that pass is used; it is not yet restricted to the Sift dimension. This is an atmosphere/sky shader, not a complete PBR, water-reflection, or ray-tracing shader. The separate geometry pack contains editable OBJ meshes; Iris does not automatically load arbitrary OBJ models.
