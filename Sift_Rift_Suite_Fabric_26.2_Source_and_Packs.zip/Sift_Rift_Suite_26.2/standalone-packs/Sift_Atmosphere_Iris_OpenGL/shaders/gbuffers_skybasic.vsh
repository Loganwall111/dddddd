#version 120

// Pass the sky dome direction into the fragment stage.
varying vec3 siftDirection;

void main() {
    gl_Position = ftransform();
    siftDirection = normalize(gl_Vertex.xyz);
}
