#version 120

uniform sampler2D texture;
uniform float frameTimeCounter;
uniform int worldTime;
varying vec3 siftDirection;

const float PI = 3.14159265359;

float softBand(float value, float centre, float width) {
    float d = (value - centre) / max(width, 0.0001);
    return exp(-d * d);
}

void main() {
    vec3 dir = normalize(siftDirection);
    // Equirectangular Sift panorama, designed around the observed teal canopy,
    // pink/cyan sky bands, plum cliffs, and squared green-white fractures.
    vec2 uv = vec2(atan(dir.z, dir.x) / (2.0 * PI) + 0.5,
                   asin(clamp(dir.y, -1.0, 1.0)) / PI + 0.5);
    vec4 pano = texture2D(texture, vec2(fract(uv.x), clamp(uv.y, 0.001, 0.999)));

    float t = frameTimeCounter * 0.075;
    // Animate the broad, smooth atmospheric ribbons; avoid grain and busy noise.
    float ribbonA = softBand(dir.y, 0.285 + 0.038 * sin(dir.x * 3.0 + dir.z * 2.0 + t), 0.022);
    float ribbonB = softBand(dir.y, 0.385 + 0.028 * sin(dir.z * 3.4 - dir.x * 1.6 - t * 0.82), 0.025);
    float ribbonC = softBand(dir.y, 0.465 + 0.020 * sin(dir.x * 2.1 + dir.z * 2.8 + t * 0.50), 0.018);

    vec3 aurora = vec3(0.20, 1.00, 0.79) * ribbonA * 0.20;
    aurora += vec3(0.98, 0.39, 0.78) * ribbonB * 0.24;
    aurora += vec3(0.35, 0.72, 1.00) * ribbonC * 0.16;

    // Minecraft day/night cycle: preserve the reference palette by day; cool the sky
    // toward indigo and emphasize cyan/magenta ribbons at night.
    float timeOfDay = mod(float(worldTime), 24000.0);
    float sunArc = cos((timeOfDay - 6000.0) * (2.0 * PI / 24000.0));
    float daylight = smoothstep(-0.22, 0.28, sunArc);
    vec3 nightSky = pano.rgb * vec3(0.29, 0.34, 0.67) + vec3(0.015, 0.012, 0.055);
    vec3 baseSky = mix(nightSky, pano.rgb, daylight);

    // A soft lower-horizon bloom echoes the portal's lime-white core without a hard halo.
    float horizon = exp(-abs(dir.y + 0.015) * 18.0);
    vec3 horizonGlow = vec3(0.30, 0.92, 0.71) * horizon * 0.075;
    vec3 color = baseSky + aurora + horizonGlow;

    // Subtle moving fracture-light passing through the high atmosphere.
    float fractureBand = softBand(dir.y, 0.33 + 0.012 * sin(dir.x * 5.0 + t * 1.7), 0.010);
    float fractureSweep = pow(max(0.0, sin(dir.x * 13.0 + dir.z * 9.0 + t * 1.4)), 24.0);
    color += vec3(0.43, 1.00, 0.24) * fractureBand * fractureSweep * 0.10;

    gl_FragColor = vec4(clamp(color, 0.0, 1.0), 1.0);
}
