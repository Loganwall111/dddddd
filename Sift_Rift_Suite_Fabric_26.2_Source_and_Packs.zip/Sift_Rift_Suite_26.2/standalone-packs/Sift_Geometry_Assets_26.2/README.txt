RESOURCE PACK: Sift Geometry & Textures (Minecraft 26.2)

Requires the Sift Rift Suite Fabric mod to register the custom block IDs. Copy the ZIP to .minecraft/resourcepacks and enable it. The mod bundles the same core textures/models, so this pack is an optional override.

Includes an eight-frame angular square-fracture portal surface in acid green, mint/cyan, and warm white; a dark violet/teal fractured frame texture; faceted pink-white crystal; normal map; and original day/night panorama source art. Sky rendering itself is handled by the separate Iris shader pack.

Assets are original interpretations of the uploaded visual reference, not raw frame screenshots.
