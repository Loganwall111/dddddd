#!/usr/bin/env python3
"""Extract every decoded frame from the two Sift/Rift video references.

This is a visual-reference pipeline, not source-code extraction: videos contain
rendered images/audio, not normally the original game's Python/Java source.

Requirements:
  - Python 3.10+
  - ffmpeg + ffprobe on PATH
  - Pillow (`python -m pip install Pillow`)
  - yt-dlp only when downloading from YouTube (`python -m pip install yt-dlp`)

Default reference handling:
  Video 1: starts at 06:19 (379 seconds) and continues to the end.
  Video 2: extracts from the beginning to the end.

Examples:
  python sift_reference_pipeline.py --fetch-youtube
  python sift_reference_pipeline.py --video1 "sift.mp4" --video2 "trailer.mp4"
  python sift_reference_pipeline.py --video1 "sift.mp4" --video2 "trailer.mp4" --image-format jpg
"""
from __future__ import annotations

import argparse
import csv
import json
import math
import re
import shutil
import subprocess
import sys
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable, Optional

VIDEO1_URL = "https://youtu.be/sJ97JDRCfPc?si=xmJ7w6qSQARmKyZ6"
VIDEO2_URL = "https://youtu.be/VyZKYhM0Kv4"
VIDEO1_START_DEFAULT = 379.0  # 06:19


@dataclass
class VideoInfo:
    path: Path
    width: Optional[int]
    height: Optional[int]
    duration: Optional[float]
    avg_frame_rate: Optional[str]
    r_frame_rate: Optional[str]
    nb_frames: Optional[int]


def run_checked(command: list[str], *, capture: bool = False) -> subprocess.CompletedProcess:
    try:
        return subprocess.run(
            command,
            check=True,
            text=True,
            stdout=subprocess.PIPE if capture else None,
            stderr=subprocess.PIPE if capture else None,
        )
    except FileNotFoundError as exc:
        raise RuntimeError(f"Required executable not found: {command[0]}. Install it and add it to PATH.") from exc
    except subprocess.CalledProcessError as exc:
        detail = (exc.stderr or "").strip()
        if len(detail) > 5000:
            detail = detail[-5000:]
        raise RuntimeError(f"Command failed ({exc.returncode}): {' '.join(command)}\n{detail}") from exc


def ensure_tools() -> None:
    for binary in ("ffmpeg", "ffprobe"):
        if shutil.which(binary) is None:
            raise RuntimeError(f"{binary} was not found on PATH. Install an FFmpeg build that includes {binary}.")


def is_url(value: str) -> bool:
    return value.startswith("https://") or value.startswith("http://")


def download_youtube(url: str, dest_dir: Path, label: str) -> Path:
    """Download a reference video through yt-dlp; intended to run on the user's machine."""
    dest_dir.mkdir(parents=True, exist_ok=True)
    if not shutil.which("yt-dlp"):
        # Support a Python module installation where the executable isn't on PATH.
        try:
            run_checked([sys.executable, "-m", "yt_dlp", "--version"], capture=True)
            command = [sys.executable, "-m", "yt_dlp"]
        except Exception as exc:
            raise RuntimeError(
                "YouTube download needs yt-dlp. Install it with `python -m pip install yt-dlp`, "
                "or download the videos in your browser and pass local filenames with --video1/--video2."
            ) from exc
    else:
        command = ["yt-dlp"]
    output_template = str(dest_dir / f"{label}.%(ext)s")
    run_checked(command + [
        "--no-warnings", "--newline", "--no-playlist", "-f", "bv*+ba/b",
        "--merge-output-format", "mp4", "-o", output_template, url,
    ])
    candidates = sorted(
        (p for p in dest_dir.glob(label + ".*") if p.suffix.lower() not in {".part", ".ytdl", ".json"}),
        key=lambda p: (p.suffix.lower() == ".mp4", p.stat().st_size if p.exists() else 0),
        reverse=True,
    )
    candidates = [p for p in candidates if p.is_file() and p.stat().st_size > 0]
    if not candidates:
        raise RuntimeError(f"yt-dlp returned without a readable video file for {url}")
    return candidates[0]


def probe_video(path: Path) -> VideoInfo:
    result = run_checked([
        "ffprobe", "-v", "error", "-select_streams", "v:0",
        "-show_entries", "stream=width,height,avg_frame_rate,r_frame_rate,nb_frames,duration",
        "-show_entries", "format=duration",
        "-of", "json", str(path),
    ], capture=True)
    data = json.loads(result.stdout)
    streams = data.get("streams") or []
    if not streams:
        raise RuntimeError(f"No video stream found in {path}")
    s = streams[0]
    dur = s.get("duration") or (data.get("format") or {}).get("duration")
    try:
        duration = float(dur) if dur is not None else None
    except (ValueError, TypeError):
        duration = None
    n = s.get("nb_frames")
    try:
        nb_frames = int(n) if n not in (None, "N/A") else None
    except (ValueError, TypeError):
        nb_frames = None
    return VideoInfo(
        path=path,
        width=int(s["width"]) if s.get("width") else None,
        height=int(s["height"]) if s.get("height") else None,
        duration=duration,
        avg_frame_rate=s.get("avg_frame_rate"),
        r_frame_rate=s.get("r_frame_rate"),
        nb_frames=nb_frames,
    )


def timestamp_rows(path: Path, start_seconds: float) -> list[float]:
    """Read actual presentation timestamps for every source video frame."""
    proc = subprocess.Popen(
        ["ffprobe", "-v", "error", "-select_streams", "v:0", "-show_frames",
         "-show_entries", "frame=best_effort_timestamp_time", "-of", "csv=p=0", str(path)],
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
        encoding="utf-8",
        errors="replace",
    )
    values: list[float] = []
    assert proc.stdout is not None
    for line in proc.stdout:
        cell = line.strip().split(",", 1)[0]
        try:
            t = float(cell)
        except (ValueError, TypeError):
            continue
        if t + 1e-6 >= start_seconds:
            values.append(t)
    stderr = proc.stderr.read() if proc.stderr else ""
    code = proc.wait()
    if code != 0:
        raise RuntimeError(f"ffprobe could not read per-frame timestamps for {path}: {stderr[-2000:]}")
    return values


def parse_rate(rate: Optional[str]) -> Optional[float]:
    if not rate or rate in {"0/0", "N/A"}:
        return None
    try:
        a, b = rate.split("/", 1)
        return float(a) / float(b)
    except Exception:
        try:
            return float(rate)
        except Exception:
            return None


def extract_frames(info: VideoInfo, start_seconds: float, target_dir: Path, image_format: str) -> tuple[int, list[float]]:
    target_dir.mkdir(parents=True, exist_ok=True)
    # Clear matching output frames from prior runs so old extra frames can't be mistaken
    # for part of the current extraction.
    for old_frame in list(target_dir.glob("frame_*.png")) + list(target_dir.glob("frame_*.jpg")):
        old_frame.unlink(missing_ok=True)
    extension = "png" if image_format == "png" else "jpg"
    output_pattern = target_dir / f"frame_%08d.{extension}"

    # Output-side -ss accurately discards all frames before the requested timestamp.
    # -fps_mode passthrough avoids intentionally duplicating/dropping frames to force a rate.
    command = [
        "ffmpeg", "-hide_banner", "-loglevel", "error", "-y",
        "-i", str(info.path), "-ss", f"{max(0.0, start_seconds):.6f}",
        "-map", "0:v:0", "-an", "-sn", "-dn",
        "-fps_mode", "passthrough",
    ]
    if image_format == "png":
        command += ["-compression_level", "3"]
    else:
        command += ["-q:v", "2"]
    command += ["-start_number", "1", str(output_pattern)]
    run_checked(command)
    frames = sorted(target_dir.glob(f"frame_*.{extension}"))
    source_timestamps = timestamp_rows(info.path, start_seconds)

    # FFmpeg versions/codecs can differ by a frame at a cut boundary. Preserve all extracted
    # images and make the manifest accurate whenever the source PTS count matches exactly.
    if len(source_timestamps) != len(frames):
        fps = parse_rate(info.avg_frame_rate) or parse_rate(info.r_frame_rate) or 30.0
        timestamps = [start_seconds + i / fps for i in range(len(frames))]
        timing_note = (
            f"Timestamp note: ffprobe counted {len(source_timestamps)} source frames after the cut "
            f"but FFmpeg exported {len(frames)} images; manifest timestamps use nominal {fps:.6f} fps."
        )
    else:
        timestamps = source_timestamps
        timing_note = "Per-frame source presentation timestamps matched exported frames."

    manifest_path = target_dir.parent / "frame_manifest.csv"
    with manifest_path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(["frame_number", "filename", "source_timestamp_seconds", "timestamp_hhmmss_mmm"])
        for i, (frame, ts) in enumerate(zip(frames, timestamps), start=1):
            writer.writerow([i, frame.name, f"{ts:.6f}", format_timestamp(ts)])

    (target_dir.parent / "timestamp_note.txt").write_text(timing_note + "\n", encoding="utf-8")
    return len(frames), timestamps


def format_timestamp(seconds: float) -> str:
    milliseconds = int(round((seconds - math.floor(seconds)) * 1000))
    whole = int(math.floor(seconds))
    hours, rem = divmod(whole, 3600)
    minutes, secs = divmod(rem, 60)
    if milliseconds == 1000:
        secs += 1
        milliseconds = 0
    return f"{hours:02d}:{minutes:02d}:{secs:02d}.{milliseconds:03d}"


def make_contact_sheets(frames_dir: Path, out_dir: Path, sheet_size: int = 30, cols: int = 5, thumb_width: int = 256) -> int:
    try:
        from PIL import Image, ImageDraw, ImageFont
    except ImportError as exc:
        raise RuntimeError("Contact sheets need Pillow. Install with `python -m pip install Pillow`.") from exc

    files = sorted(frames_dir.glob("frame_*.png")) or sorted(frames_dir.glob("frame_*.jpg"))
    if not files:
        raise RuntimeError(f"No extracted frames found under {frames_dir}")
    out_dir.mkdir(parents=True, exist_ok=True)
    for old_sheet in out_dir.glob("contact_sheet_*.jpg"):
        old_sheet.unlink(missing_ok=True)
    rows = math.ceil(sheet_size / cols)
    thumb_height = max(1, int(thumb_width * 9 / 16))
    label_h = 24
    sheets = 0
    for start in range(0, len(files), sheet_size):
        batch = files[start:start + sheet_size]
        sheet = Image.new("RGB", (cols * thumb_width, rows * (thumb_height + label_h)), (18, 20, 30))
        draw = ImageDraw.Draw(sheet)
        for slot, frame_path in enumerate(batch):
            try:
                with Image.open(frame_path) as original:
                    im = original.convert("RGB")
                    im.thumbnail((thumb_width, thumb_height), Image.Resampling.LANCZOS)
                    x = (slot % cols) * thumb_width + (thumb_width - im.width) // 2
                    y = (slot // cols) * (thumb_height + label_h)
                    sheet.paste(im, (x, y))
                y_label = (slot // cols) * (thumb_height + label_h) + thumb_height
                draw.text(((slot % cols) * thumb_width + 5, y_label + 4), frame_path.stem, fill=(230, 230, 230))
            except Exception as exc:
                print(f"Warning: failed thumbnail for {frame_path}: {exc}", file=sys.stderr)
        output_path = out_dir / f"contact_sheet_{sheets + 1:04d}.jpg"
        sheet.save(output_path, quality=92, optimize=True)
        sheets += 1
    return sheets


def process_video(label: str, path: Path, start_seconds: float, output_root: Path, image_format: str, contact_sheet_size: int) -> dict:
    info = probe_video(path)
    if info.duration is not None and start_seconds >= info.duration:
        raise RuntimeError(f"Requested start {start_seconds}s is beyond duration {info.duration:.3f}s for {path}")
    clip_dir = output_root / label
    frames_dir = clip_dir / "frames"
    print(f"[{label}] Source: {path}")
    print(f"[{label}] Size: {info.width}x{info.height}; duration: {info.duration}; avg fps: {info.avg_frame_rate}")
    print(f"[{label}] Extracting every frame from {start_seconds:.3f}s to the end…")
    count, timestamps = extract_frames(info, start_seconds, frames_dir, image_format)
    print(f"[{label}] Exported {count} frames.")
    sheets = make_contact_sheets(frames_dir, clip_dir / "contact_sheets", sheet_size=contact_sheet_size)
    print(f"[{label}] Created {sheets} contact sheets.")
    metadata = {
        "label": label,
        "source_file": str(path.resolve()),
        "width": info.width,
        "height": info.height,
        "duration_seconds": info.duration,
        "avg_frame_rate": info.avg_frame_rate,
        "r_frame_rate": info.r_frame_rate,
        "source_reported_frame_count": info.nb_frames,
        "extraction_start_seconds": start_seconds,
        "extraction_start_display": format_timestamp(start_seconds),
        "exported_frame_count": count,
        "image_format": image_format,
        "contact_sheet_count": sheets,
        "first_exported_timestamp_seconds": timestamps[0] if timestamps else None,
        "last_exported_timestamp_seconds": timestamps[-1] if timestamps else None,
        "all_frames_exported_without_fps_resampling": True,
    }
    (clip_dir / "video_metadata.json").write_text(json.dumps(metadata, indent=2), encoding="utf-8")
    return metadata


def main() -> int:
    parser = argparse.ArgumentParser(description="Extract every frame from the Sift/Rift video references and generate contact sheets.")
    parser.add_argument("--video1", help="Local path to the first video; extraction defaults to 06:19 onward.")
    parser.add_argument("--video2", help="Local path to the second video; extraction defaults to the beginning.")
    parser.add_argument("--fetch-youtube", action="store_true", help="Download the two reference videos with yt-dlp before extraction.")
    parser.add_argument("--download-dir", default="Sift_Video_Downloads", help="Directory for downloaded source videos.")
    parser.add_argument("--output", default="Sift_Reference_Extract", help="Output directory for full frames, CSV manifests, contact sheets and metadata.")
    parser.add_argument("--start-video1", type=float, default=VIDEO1_START_DEFAULT, help="First video's start timestamp in seconds (default 379 = 06:19).")
    parser.add_argument("--start-video2", type=float, default=0.0, help="Second video's start timestamp in seconds (default 0 = beginning).")
    parser.add_argument("--image-format", choices=("png", "jpg"), default="png", help="PNG preserves decoded pixels; JPG saves less disk space.")
    parser.add_argument("--contact-sheet-size", type=int, default=30, help="Frames shown per contact sheet (all frames are still exported separately).")
    args = parser.parse_args()

    if args.contact_sheet_size < 1:
        parser.error("--contact-sheet-size must be at least 1")
    try:
        ensure_tools()
        output_root = Path(args.output).expanduser().resolve()
        output_root.mkdir(parents=True, exist_ok=True)
        if args.fetch_youtube:
            download_root = Path(args.download_dir).expanduser().resolve()
            video1 = download_youtube(VIDEO1_URL, download_root, "sift_dimension_video")
            video2 = download_youtube(VIDEO2_URL, download_root, "minecraft_dungeons_ii_trailer")
        else:
            if not args.video1 or not args.video2:
                parser.error("Pass both --video1 and --video2, or use --fetch-youtube (requires yt-dlp).")
            if is_url(args.video1) or is_url(args.video2):
                raise RuntimeError("Pass local video filenames, or use --fetch-youtube to download the two built-in references.")
            video1, video2 = Path(args.video1).expanduser().resolve(), Path(args.video2).expanduser().resolve()
            for p in (video1, video2):
                if not p.is_file():
                    raise RuntimeError(f"Video file not found: {p}. Upload/copy the MP4 locally or use --fetch-youtube.")

        started = time.time()
        all_metadata = []
        all_metadata.append(process_video("video1_sift_from_0619", video1, args.start_video1, output_root, args.image_format, args.contact_sheet_size))
        all_metadata.append(process_video("video2_full_trailer", video2, args.start_video2, output_root, args.image_format, args.contact_sheet_size))
        report = {
            "title": "Sift/Rift Visual Reference Extraction",
            "created_unix_seconds": time.time(),
            "elapsed_seconds": round(time.time() - started, 3),
            "method": "FFmpeg passthrough frame extraction; no forced output FPS, no intentional frame sampling.",
            "videos": all_metadata,
            "important_limit": "Extracted frames are reference material. They do not contain the original mod's source code or automatically turn themselves into finished Minecraft geometry; assets must be reconstructed from the visual references.",
        }
        (output_root / "extraction_report.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
        print("\nDone. The output contains every exported frame, a CSV timestamp manifest, contact sheets, and metadata.")
        print(f"Output directory: {output_root}")
        print("Next step: review the contact sheets, then model the Rift/Sift structures and implement the visuals in the Fabric project.")
        return 0
    except RuntimeError as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
