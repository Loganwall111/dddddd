# Sift/Rift Video Reference Extraction

This tool extracts every decoded video frame as an individual image and creates contact sheets so the Rift sequence can be studied accurately before the Fabric mod is rebuilt from the references.

**Important distinction:** videos contain rendered picture/sound, not the original Minecraft mod's source code. This script extracts visual frames; they become reference material for rebuilding custom meshes, textures, animation timing, and shader effects.

## Requirements

- Python 3.10 or newer
- FFmpeg and FFprobe installed and on your `PATH`
- Pillow: `python -m pip install Pillow`
- yt-dlp, only if downloading the linked YouTube videos automatically: `python -m pip install yt-dlp`

## Option A — extract from local MP4 files (most reliable)

Download or export the two videos to your computer, then run from this folder:

```bash
python sift_reference_pipeline.py --video1 "C:/Videos/sift_dimension.mp4" --video2 "C:/Videos/dungeons_ii_trailer.mp4"
```

By default, video 1 starts at 379 seconds (06:19) and runs to the end. Video 2 runs from the beginning to the end.

## Option B — let yt-dlp fetch the references

```bash
python -m pip install yt-dlp Pillow
python sift_reference_pipeline.py --fetch-youtube
```

The script uses the links from the project conversation. YouTube access can vary by region, login status, video settings, or local network. If this fails, use Option A.

## Output

- `video1_sift_from_0619/frames/` — every frame exported from 06:19 through the end
- `video2_full_trailer/frames/` — every frame from the second video
- `frame_manifest.csv` in each clip folder — frame number, filename and timestamp
- `contact_sheets/` — smaller overview images for reviewing long sequences; these do **not** replace the full frame sequence
- `video_metadata.json` — dimensions, frame rate, duration, frame count and cut point
- `extraction_report.json` — combined run summary

The default PNG setting preserves each decoded frame losslessly; it may require substantial storage space. To conserve disk space, use `--image-format jpg` (lossy). This setting changes only how extracted frames are stored, not which frames are exported.

## Frame extraction guarantees and caveats

- Uses FFmpeg `-fps_mode passthrough`, not a forced output frame rate, to avoid intentional duplication or dropping during extraction.
- Frames are numbered sequentially. Per-frame presentation timestamps are written into the CSV when the timestamp count matches the exported frame count.
- Some source videos are variable frame rate. The script flags a fallback to nominal-frame-rate timestamps if FFprobe and FFmpeg report different cut-boundary counts; it still preserves all images exported by FFmpeg.
- Full frame extraction is not an automatic model generator. After reviewing the visual sequence, the mod still needs custom geometry, material maps, animation, shader logic, and in-game testing.
