@echo off
setlocal
where java >nul 2>nul || (echo Java is missing. Install JDK 25 and add it to PATH.& exit /b 1)
java -version 2>&1 | findstr /C:"25." >nul || echo NOTE: Minecraft 26.2 needs JDK 25. Verify JAVA_HOME points to JDK 25.
where gradle >nul 2>nul || (echo Gradle is missing. Install Gradle 9.5.1 or import this folder in IntelliJ IDEA/VS Code with the Java and Gradle extensions.& exit /b 1)
gradle build
if errorlevel 1 exit /b %errorlevel%
echo Built JAR(s) are in build\libs
