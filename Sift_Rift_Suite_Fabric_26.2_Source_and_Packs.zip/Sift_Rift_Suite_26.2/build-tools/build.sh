#!/usr/bin/env sh
set -eu
java -version
if ! command -v gradle >/dev/null 2>&1; then echo 'Install Gradle 9.5.1 or import this project in an IDE with Gradle support.' >&2; exit 1; fi
gradle build
